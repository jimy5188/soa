<?php
//该文件是系统自动生成的缓存文件，请勿修改
//创建时间：2017-07-01 22:21:18

if (!defined('IN_TOA')) {exit('Access Denied!');}

$_CACHE['version'] = array (
  'version' => 
  array (
    'copyright' => '欢迎您使用天生创想企业协同办公管理系统，如在使用中有问题请到论坛提问（<a href=\'http://bbs.515158.com/\' target=\'_blank\' style=\'color:red;\'>我要提问</a>）',
  ),
);

?>