<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script type="text/javascript">

function charts(type,date,str){
	
   if(type=='t1'){
   	   if(date!=''){
		   document.getElementById('year').style.color="";
		   document.getElementById('month').style.color="";
		   document.getElementById('day').style.color="";
		   document.getElementById(date).style.color="#FF0000"; 
	   }
	   document.getElementById('date').style.display="block";
   }else{
	   document.getElementById('date').style.display="none";
   }
   if(str!=''){
	   var vstartdate = document.getElementById("vstartdate").value;
	   var venddate = document.getElementById("venddate").value;
	   
   }
   jQuery.ajax({
      type: 'GET',
      url: 'admin.php?ac=charts&fileurl=auto&type='+type+'&date='+date+'&vstartdate='+vstartdate+'&venddate='+venddate+'',
      success: function(data){
		  if(data!=''){
			  $("#chartsv").html(data);

			  //$("#filetitle").html('附件列表');
		  }else{
			  $("#chartsv").html('');
		  }
      }
   });
}
</script>
</head>
<body class="body-wrap" onLoad="charts('t1','','');">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li class="active"><a href="admin.php?ac=charts&fileurl=auto">车辆用车信息统计</a></li>
					<li><a href="admin.php?ac=charts&fileurl=auto&do=service">车辆维护信息</a></li>
					<li><a href="admin.php?ac=charts&fileurl=auto&do=user">司机出车记录统计</a></li>
					
				</ul>
			</div>

<div class="search_area">
        <div class="form-search form-search-top" style="text-align:right;padding-right:50px;">
		
		  <table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <form name="save" id="save" method="post">
            <tr>
              <td align="left" id="date" style="display:none; padding-left:20px;">起止日期：
                <input type="text" name="vstartdate" id="vstartdate" style="width:120px;" onClick="WdatePicker();" readonly="readonly" /> - 
                <input type="text" name="venddate" id="venddate" style="width:120px;" onClick="WdatePicker();" readonly="readonly" />&nbsp;&nbsp;
           <button type="button" onClick="charts('t1','','1');" action="cancel_concern" class="btn btn-danger">查 询</button>
		&nbsp;
			<a href="javascript:;" style="font-size:14px;" id="year" onClick="charts('t1','year','');">年度统计</a>
			<a href="javascript:;" style="font-size:14px;" id="month" onClick="charts('t1','month','');">本月统计</a>
			<a href="javascript:;" style="font-size:14px;" id="day" onClick="charts('t1','day','');">今日数据</a></td>
              <td align="right"><button type="button" onClick="charts('t1','','');" id='t1' class="btn btn-primary">按车牌号</button>
<button type="button" onClick="charts('t2','','');" id='t2' class="btn btn-success">按用车人员</button></td>
            </tr>
			</form>
          </table>
		
	
		  
           
			
			
  </div>
</div>


<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">

<table width="98%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="center" class="Big" style="font-size:12px;" id="chartsv">
	<?php //echo renderChartHTML("template/fusioncharts/".$flashtype.".swf", "", $strXML, "",$fw, $fh, false)?>  
	<!--<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="100%" height="400" id="">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="template/fusioncharts/MSColumn3D.swf"/>		
		<param name="FlashVars" value="&chartWidth=100%&chartHeight=400&debugMode=0&dataXML=<?php echo $strXML;?>&registerWithJS=0" />
		<param name="quality" value="high" />
		<param name="wmode" value="window" />
		<embed src="template/fusioncharts/MSColumn3D.swf" FlashVars="&chartWidth=100%&chartHeight=400&debugMode=0&dataXML=<?php echo $strXML;?>&registerWithJS=0" quality="high" width="100%" height="400" name="" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="window" />
	</object> -->

	</td>
  </tr>
</table>



</div>

</body>
</html>
