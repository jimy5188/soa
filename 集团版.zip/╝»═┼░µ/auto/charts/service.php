<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="admin.php?ac=charts&fileurl=auto">车辆用车信息统计</a></li>
					<li class="active"><a href="admin.php?ac=charts&fileurl=auto&do=service">车辆维护信息</a></li>
					<li><a href="admin.php?ac=charts&fileurl=auto&do=user">司机出车记录统计</a></li>
					
				</ul>
			</div>

<div class="search_area">
        <div class="form-search form-search-top" style="text-align:right;padding-right:50px;">
		
		  <table width="98%" border="0" cellspacing="0" cellpadding="0">
		  <form method="get" action="admin.php" name="form1">
	<input type="hidden" name="ac" value="<?php echo $ac?>" />
	<input type="hidden" name="do" value="service" />
	<input type="hidden" name="fileurl" value="<?php echo $fileurl?>" />
            <tr>
              <td align="left" id="date" style="padding-left:20px;">起止日期：
                <input type="text" name="vstartdate" id="vstartdate" style="width:120px;" onClick="WdatePicker();" readonly="readonly" value="<?php echo $vstartdate;?>" /> - 
                <input type="text" name="venddate" id="venddate" style="width:120px;" onClick="WdatePicker();" value="<?php echo $venddate;?>" readonly="readonly" />&nbsp;&nbsp;
		   
		   <input type="submit" name="Submit" class="btn btn-danger" value="查 询">
		   &nbsp;
			<a href="admin.php?ac=charts&fileurl=auto&do=service&date=year&vstartdate=<?php echo $vstartdate;?>&venddate=<?php echo $vstartdate;?>" style="font-size:14px;<?php if($date=='year'){?>color:#FF0000;<?php }?>">年度统计</a>
			<a href="admin.php?ac=charts&fileurl=auto&do=service&date=month&vstartdate=<?php echo $vstartdate;?>&venddate=<?php echo $vstartdate;?>" style="font-size:14px;<?php if($date=='month'){?>color:#FF0000;<?php }?>">本月统计</a>
			<a href="admin.php?ac=charts&fileurl=auto&do=service&date=day&vstartdate=<?php echo $vstartdate;?>&venddate=<?php echo $vstartdate;?>" style="font-size:14px;<?php if($date=='day'){?>color:#FF0000;<?php }?>">今日数据</a></td>
              <td align="right"></td>
            </tr>
			</form>
          </table>
		
	
		  
           
			
			
  </div>
</div>


<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">

<table width="98%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="center" class="Big" style="font-size:12px;" id="chartsv">
	<?php echo renderChartHTML("template/fusioncharts/".$flashtype.".swf", "", $strXML, "",$fw, $fh, false)?>  
	</td>
  </tr>
</table>



</div>

</body>
</html>
