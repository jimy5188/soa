DROP TABLE IF EXISTS toa_auto;
CREATE TABLE toa_auto (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(64) DEFAULT NULL,
  number varchar(64) DEFAULT NULL,
  startnumber varchar(64) DEFAULT NULL,
  member varchar(64) DEFAULT NULL,
  autotype varchar(64) DEFAULT NULL,
  startdate date DEFAULT NULL,
  price varchar(16) DEFAULT NULL,
  type varchar(2) DEFAULT NULL,
  pic varchar(128) DEFAULT NULL,
  content text DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  date datetime DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS toa_wd_1000;
CREATE TABLE toa_wd_1000 (
  did int(11) NOT NULL AUTO_INCREMENT,
  workid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  fromid varchar(16) DEFAULT NULL,
  typeid varchar(16) DEFAULT NULL,
  type varchar(2) NOT NULL,
  toa_9558_20150107003455 varchar(256) DEFAULT NULL,
  toa_3136_20150107003519 date DEFAULT NULL,
  toa_3770_20150107003629 date DEFAULT NULL,
  toa_8885_20150107003803 date DEFAULT NULL,
  toa_7136_20150107003551 varchar(256) DEFAULT NULL,
  toa_8951_20150107003813 varchar(256) DEFAULT NULL,
  toa_5114_20150107005538 text,
  toa_2163_20150107005643 varchar(256) DEFAULT NULL,
  toa_1057_20150107005653 varchar(256) DEFAULT NULL,
  toa_1813_20150107005707 varchar(256) DEFAULT NULL,
  toa_3187_20150107005718 varchar(256) DEFAULT NULL,
  toa_3694_20150107005756 varchar(256) DEFAULT NULL,
  toa_0154_20150107005726 varchar(256) DEFAULT NULL,
  toa_2262_20150107005744 varchar(256) DEFAULT NULL,
  toa_1231_20150107005737 varchar(256) DEFAULT NULL,
  PRIMARY KEY (did)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1000 ;
DROP TABLE IF EXISTS toa_wd_1011;
CREATE TABLE toa_wd_1011 (
  did int(11) NOT NULL AUTO_INCREMENT,
  workid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  fromid varchar(16) DEFAULT NULL,
  typeid varchar(16) DEFAULT NULL,
  type varchar(2) NOT NULL,
  toa_0332_20150126203429 varchar(256) DEFAULT NULL,
  toa_4574_20150126203524 varchar(256) DEFAULT NULL,
  toa_1856_20150126203447 date DEFAULT NULL,
  toa_3559_20150126203537 varchar(256) DEFAULT NULL,
  toa_1020_20150126203549 varchar(256) DEFAULT NULL,
  toa_0409_20150126203602 varchar(256) DEFAULT NULL,
  toa_0672_20150126203612 text,
  PRIMARY KEY (did)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1000 ;

INSERT INTO toa_workclass_template (tplid, title, typeid, tplkey, tpltype, tpluser, tpladmin, uid, tpladdr, modid, content) VALUES
(1000, '用车申请', '19', '1', '1', '0', '0', '1', 'Tscx191000.php', '2', ''),
(1011, '车辆维护表', '19', '1', '1', '0', '0', '1', 'Tscx191011.php', '2', '');
INSERT INTO toa_menu (menuid, menuname, menuurl, fatherid, menutype, menunum, menukey, keytable) VALUES
(404, '用车管理', 'home.php?mid=404', '0', '0', 6, '0', 'input_auto'),
(405, '用车管理', 'admin.php?ac=list&do=list&fileurl=workclass&modid=2&tplid=1000', '404', '2', 1, '0', 'auto_flow'),
(406, '车辆维护', 'admin.php?ac=list&do=list&fileurl=workclass&modid=2&tplid=1011', '404', '2', 2, '0', 'auto_wh'),
(407, '车辆管理', 'admin.php?ac=list&fileurl=auto', '404', '2', 3, '0', 'auto_list'),
(408, '报表与统计', 'admin.php?ac=charts&fileurl=auto', '404', '0', 4, '0', 'auto_charts'),
(409, '用车系统配置', 'admin.php?ac=tpl&fileurl=workclass&modid=2', '404', '0', 5, '0', 'auto_mana');
INSERT INTO toa_keytable (id, name, inputname, inputvalue, inputchecked, type, number, fatherid) VALUES
(625, '用车管理', 'input_auto', '1', '1', '2', 9, '140'),
(626, '用车管理', 'auto_flow', '1', '1', '2', 1, '625'),
(627, '车辆维护', 'auto_wh', '1', '1', '2', 2, '625'),
(628, '车辆管理', 'auto_list', '1', '1', '2', 3, '625'),
(629, '报表与统计', 'auto_charts', '1', '1', '2', 4, '625'),
(630, '用车系统配置', 'auto_mana', '1', '1', '2', 5, '625');
INSERT INTO toa_workclass_flow (fid, flowname, flownum, flowuser, uid, tplid, typeid, flowkey, flowkey1, flowkey2, flowkey3, flowkey4, flowdate, flowdatetype, flowusertype, formkey, flowkey5, flowkey6, flowkey7, flowkey8) VALUES
(1000, '申请人提交申请', 1, '', '1', '1000', '19', '1', '1', '2', '2', '', '', '', '0', 'a:8:{i:0;s:23:"toa_9558_20150107003455";i:1;s:23:"toa_3136_20150107003519";i:2;s:23:"toa_3770_20150107003629";i:3;s:23:"toa_8885_20150107003803";i:4;s:23:"toa_7136_20150107003551";i:5;s:23:"toa_8951_20150107003813";i:6;s:23:"toa_5114_20150107005538";i:7;s:23:"toa_1057_20150107005653";}', '|||', '1001,', '', '0|0|0|0|'),
(1001, '部门经理审批', 2, '', '1', '1000', '19', '1', '1', '2', '2', '1000,', '30', '0', '0', 'a:0:{}', '0|0|0|0', '1012,', '', '1|0|0|0|'),
(1012, '管理部门审批', 3, '', '1', '1000', '19', '1', '1', '2', '2', '1000,1001,', '30', '0', '0', 'a:0:{}', '0|0|0|0', '1013,', '', '0|1|0|0|'),
(1013, '用车人确认', 4, '', '1', '1000', '19', '1', '1', '2', '2', '', '30', '0', '0', 'a:0:{}', '0|0|0|0', '1014,', '', '1|0|0|0|'),
(1014, '用车人登记用车后情况', 5, '', '1', '1000', '19', '1', '1', '2', '2', '', '30', '0', '0', 'a:6:{i:0;s:23:"toa_1813_20150107005707";i:1;s:23:"toa_3187_20150107005718";i:2;s:23:"toa_3694_20150107005756";i:3;s:23:"toa_0154_20150107005726";i:4;s:23:"toa_2262_20150107005744";i:5;s:23:"toa_1231_20150107005737";}', '0|0|0|0', '1015,', '', '0|0|0|0|'),
(1015, '管理部门审核', 6, '', '1', '1000', '19', '2', '1', '2', '2', '', '30', '0', '0', 'a:0:{}', '0|0|0|0', '', '', '0|0|0|0|'),
(1016, '申请人提交申请', 1, '', '1', '1011', '19', '1', '1', '2', '2', '', '', '', '0', 'a:6:{i:0;s:23:"toa_4574_20150126203524";i:1;s:23:"toa_1856_20150126203447";i:2;s:23:"toa_3559_20150126203537";i:3;s:23:"toa_1020_20150126203549";i:4;s:23:"toa_0409_20150126203602";i:5;s:23:"toa_0672_20150126203612";}', '|||', '1017,', '', '0|0|0|0|'),
(1017, '部门经理审批', 2, '', '1', '1011', '19', '1', '1', '2', '2', '1016,', '30', '0', '0', 'a:0:{}', '0|0|0|0', '1018,', '', '1|1|1|0|'),
(1018, '管理部门审批', 3, '', '1', '1011', '19', '2', '1', '2', '2', '', '30', '0', '0', 'a:0:{}', '0|0|0|0', '', '', '0|0|0|0|');
INSERT INTO toa_workclass_from (fromid, fromname, inputname, inputvalue, inputtype, inputtype1, inputvaluenum, confirmation, uid, tplid, flowid, typeid, formtype, inputnumber, w, h, control, dbtype, magnificent) VALUES
(1000, '申请人', 'toa_9558_20150107003455', '', '5', '1', '', '1', '1', '1000', '', '19', '1', 1, '', '', '1', '1', NULL),
(1001, '申请时间', 'toa_3136_20150107003519', '', '3', '1', '', '1', '1', '1000', '', '19', '1', 2, '', '', '0', '1', NULL),
(1002, '用车部门', 'toa_7136_20150107003551', '', '4', '1', '', '2', '1', '1000', '', '19', '1', 5, '', '', '0', '1', NULL),
(1003, '出车时间', 'toa_3770_20150107003629', '', '3', '1', '', '2', '1', '1000', '', '19', '1', 3, '', '', '1', '1', NULL),
(1004, '收车时间', 'toa_8885_20150107003803', '', '3', '1', '', '2', '1', '1000', '', '19', '1', 4, '', '', '0', '1', NULL),
(1005, '行程', 'toa_8951_20150107003813', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 6, '', '', '0', '1', NULL),
(1006, '申请事由', 'toa_5114_20150107005538', '', '0', '2', '', '2', '1', '1000', '', '19', '1', 7, '', '', '0', '1', NULL),
(1007, '车牌号', 'toa_2163_20150107005643', '', '7', '1', '', '2', '1', '1000', '', '19', '1', 8, '', '', '1', '1', 'toa_auto'),
(1008, '司机', 'toa_1057_20150107005653', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 9, '', '', '1', '1', NULL),
(1009, '出车前公里数', 'toa_1813_20150107005707', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 10, '', '', '0', '1', NULL),
(1010, '收车公里数', 'toa_3187_20150107005718', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 11, '', '', '0', '1', NULL),
(1011, '里程数', 'toa_0154_20150107005726', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 13, '', '', '1', '1', NULL),
(1012, '加油金额', 'toa_1231_20150107005737', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 15, '', '', '1', '1', NULL),
(1013, '加油量', 'toa_2262_20150107005744', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 14, '', '', '1', '1', NULL),
(1014, '出车费用', 'toa_3694_20150107005756', '', '0', '1', '', '2', '1', '1000', '', '19', '1', 12, '', '', '1', '1', NULL),
(1097, '车牌号', 'toa_0332_20150126203429', '', '7', '1', '', '2', '1', '1011', NULL, '19', NULL, 1, '', '', '1', '1', 'toa_auto'),
(1098, '维护日期', 'toa_1856_20150126203447', '', '3', '1', '', '2', '1', '1011', NULL, '19', NULL, 3, '', '', '1', '1', NULL),
(1099, '维护类型', 'toa_4574_20150126203524', '', '0', '3', '维修|\n加油|\n洗车|\n年检|\n其他', '2', '1', '1011', NULL, '19', NULL, 2, '', '', '0', '1', NULL),
(1100, '维护原因', 'toa_3559_20150126203537', '', '0', '1', '', '2', '1', '1011', NULL, '19', NULL, 4, '', '', '0', '1', NULL),
(1101, '经办人', 'toa_1020_20150126203549', '', '5', '1', '', '2', '1', '1011', NULL, '19', NULL, 5, '', '', '0', '1', NULL),
(1102, '维护费用', 'toa_0409_20150126203602', '', '0', '1', '', '2', '1', '1011', NULL, '19', NULL, 6, '', '', '1', '1', NULL),
(1103, '备注', 'toa_0672_20150126203612', '', '0', '2', '', '2', '1', '1011', NULL, '19', NULL, 7, '', '', '0', '1', NULL);