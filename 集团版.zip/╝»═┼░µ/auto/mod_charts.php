<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("auto_charts");
require(TOA_ROOT.'include/function_charts.php');
empty($do) && $do = 'list';
//Column3D,Line,Pie3D,Area2D,Bar2D,Doughnut2D
$fw='100%';
$fh='400';
if ($do == 'list') {
	$flashtype='MSColumn3D';
	if(getGP('type','G')=='t1'){
		//获取数据
		$sql = "SELECT number FROM ".DB_TABLEPRE.DB_JT."auto order by id desc";
		$auto = $db->fetch_all($sql);
		//XML开始
		$strXML = "<chart caption='车辆用车信息统计[按车牌号]' numberPrefix='' formatNumberScale='1' rotateValues='1' placeValuesInside='1' decimals='2'>";
			//统计头
		$strXML .= "<categories>";
		foreach ($auto as $row) {
			$strXML .= "<category name='".$row['number']."' />";
		}
		$strXML .= "</categories>";
		$name='出车费用,里程数,加油量,加油金额';
		$value='toa_3694_20150107005756,toa_0154_20150107005726,toa_2262_20150107005744,toa_1231_20150107005737';
		$name=explode(',',$name); 
		$value=explode(',',$value);
		$date = getGP('date','G');
		$vstartdate = getGP('vstartdate','G');
		$venddate = getGP('venddate','G');
		$wheresql='';
		if($date=='year') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)."";
		}elseif($date=='month') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)." AND month(toa_3770_20150107003629)= ".get_date('m',PHP_TIME)."";
		}elseif($date=='day') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)." AND month(toa_3770_20150107003629)= ".get_date('m',PHP_TIME)." AND day(toa_3770_20150107003629)= ".get_date('d',PHP_TIME)."";
		}
		if ($vstartdate!='undefined' && $venddate!='undefined') {
			$wheresql .= " AND (toa_3770_20150107003629>='".$vstartdate."' and toa_3770_20150107003629<='".$venddate."')";
		}
		for($i=0;$i<sizeof($name);$i++){ 
			$strXML .= "<dataset seriesName='".$name[$i]."'>";
			foreach ($auto as $row) {
				$sql="SELECT sum(".$value[$i].") AS numkeys FROM ".DB_TABLEPRE.DB_JT."wd_1000  WHERE toa_2163_20150107005643='".$row['number']."' ".$wheresql." order by did desc";
				//echo $sql."<br>";
				$numkeys = $db->result($sql);
				if(trim($numkeys)==''){
					$numkeys=0;
				}
				$strXML .= "<set value='".sprintf("%01.2f",$numkeys)."' />";
			}
			$strXML .= "</dataset>";
		}
		$strXML .= "</chart>";
		echo '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'.$fw.'" height="'.$fh.'" id="">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="template/fusioncharts/'.$flashtype.'.swf"/>		
		<param name="FlashVars" value="&chartWidth='.$fw.'&chartHeight='.$fh.'&debugMode=0&dataXML='.$strXML.'&registerWithJS=0" />
		<param name="quality" value="high" />
		<param name="wmode" value="window" />
		<embed src="template/fusioncharts/MSColumn3D.swf" FlashVars="&chartWidth='.$fw.'&chartHeight='.$fh.'&debugMode=0&dataXML='.$strXML.'&registerWithJS=0" quality="high" width="'.$fw.'" height="'.$fh.'" name="" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="window" />
	</object>';
		//echo $strXML;
		exit;
		
	}elseif(getGP('type','G')=='t2'){
		//获取数据
		$query = $db->query("SELECT toa_9558_20150107003455 FROM ".DB_TABLEPRE.DB_JT."wd_1000 order by did desc");
		$uname='';
		while ($row = $db->fetch_array($query)) {
			$uname.="'".$row['toa_9558_20150107003455']."',";
		}
		$sql = "SELECT b.name FROM ".DB_TABLEPRE.DB_JT."user a,".DB_TABLEPRE.DB_JT."user_view b where a.id=b.uid and b.name in(".substr($uname, 0, -1).") order by numbers asc";
		$user = $db->fetch_all($sql);
		//XML开始
		$strXML = "<chart caption='车辆用车信息统计[按使用人]' numberPrefix='' formatNumberScale='1' rotateValues='1' placeValuesInside='1' decimals='2'>";
			//统计头
		$strXML .= "<categories>";
		foreach ($user as $row) {
			$strXML .= "<category name='".$row['name']."' />";
		}
		$strXML .= "</categories>";
		$name='出车费用,里程数,加油量,加油金额';
		$value='toa_3694_20150107005756,toa_0154_20150107005726,toa_2262_20150107005744,toa_1231_20150107005737';
		$name=explode(',',$name); 
		$value=explode(',',$value);
		for($i=0;$i<sizeof($name);$i++){ 
			$strXML .= "<dataset seriesName='".$name[$i]."'>";
			foreach ($user as $row) {
				$sql="SELECT sum(".$value[$i].") AS numkeys FROM ".DB_TABLEPRE.DB_JT."wd_1000  WHERE toa_9558_20150107003455='".$row['name']."' order by did desc";
				//echo $sql."<br>";
				$numkeys = $db->result($sql);
				if(trim($numkeys)==''){
					$numkeys=0;
				}
				$strXML .= "<set value='".sprintf("%01.2f",$numkeys)."' />";
			}
			$strXML .= "</dataset>";
		}
		$strXML .= "</chart>";
		echo '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" width="'.$fw.'" height="'.$fh.'" id="">
		<param name="allowScriptAccess" value="always" />
		<param name="movie" value="template/fusioncharts/'.$flashtype.'.swf"/>		
		<param name="FlashVars" value="&chartWidth='.$fw.'&chartHeight='.$fh.'&debugMode=0&dataXML='.$strXML.'&registerWithJS=0" />
		<param name="quality" value="high" />
		<param name="wmode" value="window" />
		<embed src="template/fusioncharts/MSColumn3D.swf" FlashVars="&chartWidth='.$fw.'&chartHeight='.$fh.'&debugMode=0&dataXML='.$strXML.'&registerWithJS=0" quality="high" width="'.$fw.'" height="'.$fh.'" name="" allowScriptAccess="always" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" wmode="window" />
	</object>';
		//echo $strXML;
		exit;
	}
	include_once('charts/list.php');

}elseif($do == 'service') {
		$flashtype='Line';
		$date = getGP('date','G');
		$vstartdate = getGP('vstartdate','G');
		$venddate = getGP('venddate','G');
		$wheresql='';
		if($date=='year') {
			$wheresql .= " AND year(toa_1856_20150126203447)= ".get_date('Y',PHP_TIME)."";
		}elseif($date=='month') {
			$wheresql .= " AND year(toa_1856_20150126203447)= ".get_date('Y',PHP_TIME)." AND month(toa_1856_20150126203447)= ".get_date('m',PHP_TIME)."";
		}elseif($date=='day') {
			$wheresql .= " AND year(toa_1856_20150126203447)= ".get_date('Y',PHP_TIME)." AND month(toa_1856_20150126203447)= ".get_date('m',PHP_TIME)." AND day(toa_1856_20150126203447)= ".get_date('d',PHP_TIME)."";
		}
		if ($vstartdate!='' && $venddate!='') {
			$wheresql .= " AND (toa_1856_20150126203447>='".$vstartdate."' and toa_1856_20150126203447<='".$venddate."')";
		}
		$strtype  = "<chart caption='' xAxisName='维护费用' yAxisName='车辆维护信息统计' showValues='0' formatNumberScale='0' showBorder='1'>";
		$sql = $db->query("SELECT number FROM ".DB_TABLEPRE.DB_JT."auto order by id desc");
		while ($row = $db->fetch_array($sql)) {
			$numkeys = $db->result("SELECT sum(toa_0409_20150126203602) AS numkeys FROM ".DB_TABLEPRE.DB_JT."wd_1011  WHERE toa_0332_20150126203429='".$row['number']."' ".$wheresql." order by did desc");
			if(trim($numkeys)==''){
				$numkeys=0;
			}
			$strtype .= "<set label='".$row['number']."' value='".sprintf("%01.2f",$numkeys)."' />";
		}
		$strtype .= "</chart>";
		$strXML= $strtype;
		include_once('charts/service.php');
	
}elseif($do == 'user') {
		$flashtype='MSColumn3D';
		$date = getGP('date','G');
		$vstartdate = getGP('vstartdate','G');
		$venddate = getGP('venddate','G');
		$wheresql='';
		if($date=='year') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)."";
		}elseif($date=='month') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)." AND month(toa_3770_20150107003629)= ".get_date('m',PHP_TIME)."";
		}elseif($date=='day') {
			$wheresql .= " AND year(toa_3770_20150107003629)= ".get_date('Y',PHP_TIME)." AND month(toa_3770_20150107003629)= ".get_date('m',PHP_TIME)." AND day(toa_3770_20150107003629)= ".get_date('d',PHP_TIME)."";
		}
		if ($vstartdate!='' && $venddate!='') {
			$wheresql .= " AND (toa_3770_20150107003629>='".$vstartdate."' and toa_3770_20150107003629<='".$venddate."')";
		}
		//获取数据
		$query = $db->query("SELECT toa_1057_20150107005653 FROM ".DB_TABLEPRE.DB_JT."wd_1000 order by did desc");
		$arrcid = array();
		while ($row = $db->fetch_array($query)) {
			$arrcid[]="'".$row['toa_1057_20150107005653']."',";
		}
		$arrcid1=array_unique($arrcid);//去掉重复
		//XML开始
		$strXML = "<chart caption='司机出车记录统计' numberPrefix='' formatNumberScale='1' rotateValues='1' placeValuesInside='1' decimals='2'>";
			//统计头
		$strXML .= "<categories>";
		for($i=0;$i<count($arrcid1);$i++){
			$strXML .= "<category name='".str_replace("'","",str_replace(',','',$arrcid1[$i]))."' />";
		}
		$strXML .= "</categories>";
		$name='出车费用,里程数,加油量,加油金额';
		$value='toa_3694_20150107005756,toa_0154_20150107005726,toa_2262_20150107005744,toa_1231_20150107005737';
		$name=explode(',',$name); 
		$value=explode(',',$value);
		for($i=0;$i<sizeof($name);$i++){ 
			$strXML .= "<dataset seriesName='".$name[$i]."'>";
			for($j=0;$j<count($arrcid1);$j++){
				$str=str_replace("'","",str_replace(',','',$arrcid1[$i]));
				$sql="SELECT sum(".$value[$i].") AS numkeys FROM ".DB_TABLEPRE.DB_JT."wd_1000  WHERE toa_1057_20150107005653 LIKE '%".$str."%' ".$wheresql." order by did desc";
				//echo $sql."<br>";
				$numkeys = $db->result($sql);
				if(trim($numkeys)==''){
					$numkeys=0;
				}
				$strXML .= "<set value='".sprintf("%01.2f",$numkeys)."' />";
			}
			$strXML .= "</dataset>";
		}
		$strXML .= "</chart>";
		include_once('charts/user.php');
	
}
?>