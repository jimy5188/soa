<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="template/default/js/LodopFuncs.js"></script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">车辆管理</a></li>
					<li  class="active" ><a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=add&id=<?php echo $id?>"><?php echo $_title['name'];?>车辆</a></li>
				
				</ul>
				
			</div>

<div class="search_area">
        <div class="form-search form-search-top" style="text-align:right;padding-right:100px;">
         <button type="button" onClick="prn1_print();" action="cancel_concern" class="btn btn-danger">打印</button>
		   <button type="button" onClick="prn1_preview();" action="cancel_concern" class="btn btn-success">打印预览</button>
        </div>
</div>


<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">
<style type="text/css">
body {
	text-align: center;
	background-color: #F9F8F8;
}
.text_table{
	background-color: #FFFFFF;
	
}
.table_bg{
	border-collapse: 1px;
    border-spacing: 1px;
	background-color:#DDDED5;
}
.table_bg1{
	border-collapse: 0px;
    border-spacing: 0px;
	border-left:1px solid #DDDED5;
	border-right:1px solid #DDDED5;
}
.title{
	font-family: "微软雅黑", "宋体";
	font-size: 32px;
	color: #069DD5;
	line-height: 60px;
	letter-spacing: 2px;
}
.text_td {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 35px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
}
.text_td_1 {
	width:110px;
	background-color:#F7F8EE;
}
.text_value {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 25px;
	height:35px;
	color: #069DD5;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#FFFFFF;
	text-align:left;
}
.text_title {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:40px;
	color: #68584e;
	padding-left: 20px;
	background-color:#E8E8E3;
	text-align:left;
}
.text_no {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#F7F8EE;
}
.ninput{width:260px;height:22px;line-height:22px;font-size:14px;margin-top:6px;}
.ndate{width:180px;height:22px;line-height:22px;font-size:14px;margin-top:6px;}
</style>

<table width="1002" border="0" align="center" class="table_bg" style="border:1px solid #069DD5; margin-top:15px;">
  <tr><td class="text_td text_td_1">车辆型号</td><td class="text_value"><?php echo $row['title'];?>
  </td><td class="text_td text_td_1">车牌号</td><td class="text_value"><?php echo $row['number'];?></td></tr>
  
  <tr><td class="text_td text_td_1">发动机号</td><td class="text_value"><?php echo $row['startnumber'];?>
  </td><td class="text_td text_td_1">司机</td><td class="text_value"><?php echo $row['member'];?></td></tr>
  <tr><td class="text_td text_td_1">车辆类型</td><td class="text_value"><?php echo $row['autotype'];?>
  </td><td class="text_td text_td_1">购买日期</td><td class="text_value"><?php echo $row['startdate'];?></td></tr>
  <tr><td class="text_td text_td_1">购买价格</td><td class="text_value"><?php echo $row['price'];?>
  </td><td class="text_td text_td_1">车辆状态</td><td class="text_value">
  <?php
		if($row['type']=='1'){
			echo "<font color=#006600>可用</font>";
		}elseif($row['type']=='2'){
			echo "损耗";
		}elseif($row['type']=='3'){
			echo "维修中";
		}elseif($row['type']=='4'){
			echo "报废";
		}
	  ?>
  </td></tr>
  <tr><td class="text_td text_td_1">车辆图片</td><td colspan="3" class="text_value">
  <?php if($row['pic']!=''){?>
  <img src="<?php echo $row['pic'];?>">
  <?php }?>
  </td>
  </tr>
  

  </table>


<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">备注</span>
			</div>
<table class="TableBlock" width="90%" style="margin-bottom:10px">      	
    <tr class="TableData">
        <td align="left" style="padding-left:40px;"><?php echo $row['content'];?>        </td>
    </tr>
</table>			
</div>



</div>
<div  id='form1'  style=" display:none;">
<style type="text/css">
body {
	text-align: center;
	background-color: #F9F8F8;
}
.text_table{
	background-color: #FFFFFF;
	
}
.table_bg{
	border-collapse: 1px;
    border-spacing: 1px;
	background-color:#DDDED5;
}
.table_bg1{
	border-collapse: 0px;
    border-spacing: 0px;
	border-left:1px solid #DDDED5;
	border-right:1px solid #DDDED5;
}
.title{
	font-family: "微软雅黑", "宋体";
	font-size: 32px;
	color: #069DD5;
	line-height: 60px;
	letter-spacing: 2px;
}
.text_td {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 35px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
}
.text_td_1 {
	width:110px;
	background-color:#F7F8EE;
}
.text_value {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 25px;
	height:35px;
	color: #069DD5;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#FFFFFF;
	text-align:left;
}
.text_title {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:40px;
	color: #68584e;
	padding-left: 20px;
	background-color:#E8E8E3;
	text-align:left;
}
.text_no {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#F7F8EE;
}
</style>
<table width="750" border="0" align="center" cellpadding="0" cellspacing="0" class="text_table">
  <tr>
    <td height="15" colspan="2" bgcolor="#069DD5"></td>
  </tr>
  <tr>
    <td height="60" colspan="2" align="center" class="title"><?php echo $row['number'];?>车辆信息</td>
  </tr>
  <tr>
    <td height="30" align="left" class="text_td">发布人:<?php echo get_realname($row['uid'])?></td>
    <td height="30" align="right"  class="text_td">发布日期:<?php echo $row['date'];?></td>
  </tr>
  <tr>
    <td height="3" colspan="2" bgcolor="#069DD5"></td>
  </tr>
</table>
<table width="752" border="0" align="center" class="table_bg" >
  <tr><td class="text_td text_td_1">车辆型号</td><td class="text_value"><?php echo $row['title'];?>
  </td><td class="text_td text_td_1">车牌号</td><td class="text_value"><?php echo $row['number'];?></td></tr>
  
  <tr><td class="text_td text_td_1">发动机号</td><td class="text_value"><?php echo $row['startnumber'];?>
  </td><td class="text_td text_td_1">司机</td><td class="text_value"><?php echo $row['member'];?></td></tr>
  <tr><td class="text_td text_td_1">车辆类型</td><td class="text_value"><?php echo $row['autotype'];?>
  </td><td class="text_td text_td_1">购买日期</td><td class="text_value"><?php echo $row['startdate'];?></td></tr>
  <tr><td class="text_td text_td_1">购买价格</td><td class="text_value"><?php echo $row['price'];?>
  </td><td class="text_td text_td_1">车辆状态</td><td class="text_value">
  <?php
		if($row['type']=='1'){
			echo "<font color=#006600>可用</font>";
		}elseif($row['type']=='2'){
			echo "损耗";
		}elseif($row['type']=='3'){
			echo "维修中";
		}elseif($row['type']=='4'){
			echo "报废";
		}
	  ?>
  </td></tr>
  <tr><td class="text_td text_td_1">车辆图片</td><td colspan="3" class="text_value">
  <?php if($row['pic']!=''){?>
  <img src="<?php echo $row['pic'];?>">
  <?php }?>
  </td>
  </tr>
  
  <tr><td class="text_td text_td_1">备注</td><td colspan="3" class="text_value">
<?php echo $row['content'];?>
  </td>
  </tr>
  </table>


</div>
<script language="javascript" type="text/javascript">   
     var LODOP; //声明为全局变量 
     function prn1_preview() {    
         CreateOneFormPage();    
         LODOP.PREVIEW();    
     };
     function prn1_print() {        
         CreateOneFormPage();
         LODOP.PRINT();    
     };
         function CreateOneFormPage(){
         LODOP=getLodop(); 
         var strStyleCSS="<link href='template/default/content/css/style2015.css' type='text/css' rel='stylesheet'>";
         var strFormHtml=strStyleCSS+"<body>"+document.getElementById("form1").innerHTML+"</body>";
         LODOP.PRINT_INIT("打印流程");
         LODOP.ADD_PRINT_HTM(0,0,"100%","100%",strFormHtml);
		 //LODOP.ADD_PRINT_HTM(88,200,350,600,document.getElementById("form1").innerHTML);
     };
 </script>
</body>
</html>
