<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">车辆管理</a></li>
					<li  class="active" ><a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=add&id=<?php echo $id?>"><?php echo $_title['name'];?>车辆</a></li>
				
				</ul>
				
			</div>
<script Language="JavaScript"> 
function CheckForm()
{
   if(document.save.title.value=="")
   { alert("车辆型号不能为空！");
     document.save.title.focus();
     return (false);
   }
   if(document.save.number.value=="")
   { alert("车牌号不能为空！");
     document.save.number.focus();
     return (false);
   }
   
   return true;
}
function sendForm()
{
   if(CheckForm())
      document.save.submit();
}
</script>
<form name="save" id="form1" method="post" action="?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=add">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="id" value="<?php echo $row['id']?>" />
<div class="search_area">
        <div class="form-search form-search-top" style="text-align:right;padding-right:100px;">
                      
          
           <input type="button" value="保存数据" class="btn btn-danger" onClick="sendForm();"> 
			<input type="button" value="重置表单" class="btn btn-info" onClick="document.getElementById('form1').reset()"/>
        </div>
</div>


<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">
<style type="text/css">
body {
	text-align: center;
	background-color: #F9F8F8;
}
.text_table{
	background-color: #FFFFFF;
	
}
.table_bg{
	border-collapse: 1px;
    border-spacing: 1px;
	background-color:#DDDED5;
}
.table_bg1{
	border-collapse: 0px;
    border-spacing: 0px;
	border-left:1px solid #DDDED5;
	border-right:1px solid #DDDED5;
}
.title{
	font-family: "微软雅黑", "宋体";
	font-size: 32px;
	color: #069DD5;
	line-height: 60px;
	letter-spacing: 2px;
}
.text_td {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 35px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
}
.text_td_1 {
	width:110px;
	background-color:#F7F8EE;
}
.text_value {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 14px;
	line-height: 25px;
	height:35px;
	color: #069DD5;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#FFFFFF;
	text-align:left;
}
.text_title {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:40px;
	color: #68584e;
	padding-left: 20px;
	background-color:#E8E8E3;
	text-align:left;
}
.text_no {
	font-family: Arial, "微软雅黑", "宋体";
	font-size: 16px;
	line-height: 25px;
	height:35px;
	color: #68584e;
	padding-right: 6px;
	padding-left: 6px;
	background-color:#F7F8EE;
}
.ninput{width:260px;height:22px;line-height:22px;font-size:14px;margin-top:6px;}
.ndate{width:180px;height:22px;line-height:22px;font-size:14px;margin-top:6px;}
</style>

<table width="1002" border="0" align="center" class="table_bg" style="border:1px solid #069DD5; margin-top:15px;">
  <tr><td class="text_td text_td_1">车辆型号<? get_helps()?></td><td class="text_value"><input class="BigInput ninput" type="text" value="<?php echo $row['title'];?>" name="title" />
  </td><td class="text_td text_td_1">车牌号<? get_helps()?></td><td class="text_value"><input class="BigInput ninput" type="text" value="<?php echo $row['number'];?>" name="number" /></td></tr>
  
  <tr><td class="text_td text_td_1">发动机号</td><td class="text_value"><input class="BigInput ninput" type="text" value="<?php echo $row['startnumber'];?>" name="startnumber" />
  </td><td class="text_td text_td_1">司机</td><td class="text_value"><input class="BigInput ninput" type="text" value="<?php echo $row['member'];?>" name="member" /></td></tr>
  <tr><td class="text_td text_td_1">车辆类型</td><td class="text_value"><input class="BigInput ninput" type="text" value="<?php echo $row['autotype'];?>" name="autotype" />
  </td><td class="text_td text_td_1">购买日期</td><td class="text_value"><input class="BigInput ndate" type="text" value="<?php echo $row['startdate'];?>" name="startdate" onClick="WdatePicker();"  /></td></tr>
  <tr><td class="text_td text_td_1">购买价格</td><td class="text_value"><input class="BigInput ndate" type="text" value="<?php echo $row['price'];?>" name="price" />
  </td><td class="text_td text_td_1">车辆状态</td><td class="text_value">
  <input name="type" type="radio" value="1" <?php if($row['type']==1){?> checked<?php }?>/>可用
  <input name="type" type="radio" value="2" <?php if($row['type']==2){?> checked<?php }?>/>损耗
  <input name="type" type="radio" value="3" <?php if($row['type']==3){?> checked<?php }?>/>维修中
  <input name="type" type="radio" value="4" <?php if($row['type']==4){?> checked<?php }?>/>报废
  
  </td></tr>
  <tr><td class="text_td text_td_1">车辆图片</td><td colspan="3" class="text_value"><?php echo public_upload('pic',$row['pic'])?>
  </td>
  </tr>
  
  
  </table>


<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">备注</span>
			</div>
<table class="TableBlock" width="90%" style="margin-bottom:10px">      	
    <tr class="TableData">
        <td style="padding-left:40px;">
<textarea id="content" cols="20" rows="2" class="ckeditor"  name="content"><?php echo $row['content'];?></textarea>
        </td>
    </tr>
</table>			
</div>



</div>

</form>
</body>
</html>
