<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("apps_");
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if(getGP('tplid','G')!=''){
	$tplid=getGP('tplid','G');
}else{
	$tplid=getGP('tplid','P');
}
$appid=getGP('appid','P','int');
empty($do) && $do = 'list';
if ($do == 'list') {
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
	//更新表单数据
	if(getGP('_flownum','P','int')==1){
		apps_update();
	}
	if($tpl['tplkey']!=4 && $tpl['tplkey']!=5){
		appsform_update();
	}
	//更新签批内容
	$perid=getGP('perid','P','int');
	$flowid=getGP('flowid','P','int');
	$content=getGP('content','P');
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'";
	$row = $db->fetch_one_array($sql);
	//获取当前流程
	$sql = "SELECT a.perid,a.name,a.uid,a.pertype,a.appkey,a.appkey1,a.countersign,a.entrust,
	        b.flowname,b.flownum,b.fid,b.flowkey,b.flowkey4,b.flowkey5,b.flowkey6 
			FROM ".DB_TABLEPRE.DB_JT."app_personnel a,
			".DB_TABLEPRE.DB_JT."app_flow b  WHERE a.flowid=b.fid and 
			a.appid = '".$appid."' and (a.pertype=0 or a.pertype=4) 
			and a.perid=".$perid." and a.flowid=".$flowid." order by a.perid desc";
	$per = $db->fetch_one_array($sql);
	//检测条件流
	$flowkey5=apps_whereflow($per['flowkey5'],$appid);
	//获取有效步骤
	$nextflow = array();
	$_nextflow2016=apps_nextflow($tplid,$typeid,$appid,$per['flownum']);
	$nextflow2016=explode(',',$_nextflow2016);
	for($i=0;$i<sizeof($nextflow2016);$i++){
		if($nextflow2016[$i]){
			$nextflow[]=$nextflow2016[$i];
		}
	}
	if($per['flowkey6']!=''){
		//过滤条件流
		$sql1 = "SELECT fid,flowkey5 FROM ".DB_TABLEPRE.DB_JT."app_flow   
			    WHERE fid in(".substr($per['flowkey6'], 0, -1).") order by flownum asc";
		$result1 = $db->query($sql1);
		while ($per1 = $db->fetch_array($result1)) {
			$flowkey51=apps_whereflow($per1['flowkey5'],$appid);
			if($flowkey51!=1){
				$nextflow[]=$per1['fid'];
			}
		}
	}
	//var_dump ($nextflow);
	$nextflow=array_unique($nextflow);
	$psntype=getGP('psntype','G');
	//检测会签审批
	if($psntype=='countersign'){
		include_once('template/personnel_countersign.php');
		exit;
	}
	//检测多人审批
	if($psntype=='appkey'){
		$sqllog = "SELECT lid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log  WHERE perid='".$per['perid']."' and uid!='".$_USER->id."' and pertype=0";
		$per_log = $db->fetch_one_array($sqllog);
		if($per_log['lid']!=''){
			if($per['appkey1']==1){
				include_once('template/personnel_appkey1.php');
			}else{
				include_once('template/personnel_appkey2.php');
			}
		}else{
			include_once('template/personnel_appkey2.php');
		}
		exit;
	}
	include_once('template/personnel.php');

}elseif ($do == 'personnel') {
	$title=getGP('title','P');
	$appid=getGP('appid','P','int');
	$tplid=getGP('tplid','P','int');
	$tpltype=getGP('tpltype','P','int');
	$perid=getGP('perid','P','int');
	$flowid=getGP('flowid','P','int');
	$content=getGP('content','P');
	$views=getGP('view','P');
	//委办人员，主办人员提交通道
	if($views=='personnel'){
		$nextflowid=getGP('nextflowid','P','int');
		$pertype=getGP('pertype','P','int');
		$user=getGP('user','P');
		$userid=getGP('userid','P');
		if($nextflowid!=''){
			$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow 
				   WHERE fid = ".$nextflowid."";
			$flow = $db->fetch_one_array($sql);
			
			//处理流程丢失的问题
			$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel 
			          WHERE perid = '".$perid."' and (pertype='0' or pertype='4')";
			$newflow = $db->fetch_one_array($newsql);
			//获取委托数据
			$entrustsql = "SELECT user,period,startdata,enddate FROM 
			          ".DB_TABLEPRE.DB_JT."app_entrust 
			          WHERE tplid = '".$tplid."' and uid = '".$userid."'";
			$entrust = $db->fetch_one_array($entrustsql);
			if(trim($newflow['perid'])!=''){
				$personnel1 = array(
					'pertype' =>$pertype,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel',$personnel1, array('perid' => $perid));
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
				//创建下一步审批人员
				if($flow['flowdatetype']==1){
					$flowdate=get_date('Y-m-d H:i:s',PHP_TIME+$flow['flowdate']*60);
				}
				if($user!='' && $pertype!=2){
					$personnel=array();
					$personnel['name']=$user;
					$personnel['uid']=$userid;
					$personnel['pertype']=0;
					$personnel['designationdate']=get_date('Y-m-d H:i:s',PHP_TIME);
					$personnel['appid']=$appid;
					$personnel['flowid']=$flow['fid'];
					$personnel['appkey']=$flow['flowkey2'];
					$personnel['appkey1']=$flow['flowkey3'];
					$personnel['tplid']=$tplid;
					$personnel['flowdatetype']=$flow['flowdatetype'];
					$personnel['flowdate']=$flow['flowdate'];
					$personnel['flowkey8']=$flow['flowkey8'];
					$personnel['usernum']=','.$user.',';
					if($entrust['period']==1){
						$personnel['entrust']=$entrust['user'];
						$entrustuser=$entrust['user'];
					}else{
						$ed=get_date('Y-m-d H:i:s',PHP_TIME);
						if($entrust['startdata']<=$ed && $entrust['enddate']>=$ed){
							$personnel['entrust']=$entrust['user'];
							$entrustuser=$entrust['user'];
						}
					}
					insert_db(DB_JT.'app_personnel',$personnel);
					$pid=$db->insert_id();
					if($flow['flowkey2']==1){
						$staff=explode(',',$user);
						$staffid=explode(',',$userid);
						for($i=0;$i<sizeof($staffid);$i++){
							$personnel_log = array(
								'name' => $staff[$i],
								'uid' =>$staffid[$i],
								'pertype' =>0,
								'type' =>0,
								'perid' =>$pid,
								'appid' =>$appid,
								'tplid' =>$tplid
								);
							insert_db(DB_JT.'app_personnel_log',$personnel_log);
						}
					}	
				}
			}
		}else{
			//处理流程丢失的问题
			$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel 
			          WHERE perid = '".$perid."' and (pertype='0' or pertype='4')";
			$newflow = $db->fetch_one_array($newsql);
			if(trim($newflow['perid'])!=''){
				if($pertype==2){
					$pertypes=2;
				}else{
					$pertypes=5;
				}
				$personnel1 = array(
					'pertype' =>$pertypes,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel',$personnel1, array('perid' => $perid));
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
			}
		}
	//----------------------------------------------------------------------------------
	//多人审批通道
	}elseif($views=='appkey1'){
		$pertype=getGP('pertype','P','int');
		if($perid!=''){
			//处理流程丢失的问题
			$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log 
			          WHERE perid = '".$perid."' and  appid = '".$appid."' and 
					  pertype='0' and uid='".$_USER->id."' and type=0";
			$newflow = $db->fetch_one_array($newsql);
			if(trim($newflow['perid'])!=''){
				if($pertype==2){
					$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel  
							    SET pertype='".$pertype."',
								approvaldate='".get_date('Y-m-d H:i:s',PHP_TIME)."'
								,lnstructions='".$content."' WHERE perid='".$perid."'");
				}else{
					$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel  
							    SET pertype='4' WHERE perid='".$perid."'");
				}
				$personnel1 = array(
					'pertype' =>$pertype,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel_log',$personnel1, array('perid' => $newflow['perid'],'uid' => $_USER->id));
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
			}
		}
	}elseif($views=='appkey2'){
		$nextflowid=getGP('nextflowid','P','int');
		$pertype=getGP('pertype','P','int');
		$user=getGP('user','P');
		$userid=getGP('userid','P');
		if($nextflowid!=''){
			$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow 
				   WHERE fid = ".$nextflowid."";
			$flow = $db->fetch_one_array($sql);
			//处理流程丢失的问题
			$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log 
			          WHERE perid = '".$perid."' and  appid = '".$appid."' and 
					  pertype='0' and uid='".$_USER->id."' and type=0";
			$newflow = $db->fetch_one_array($newsql);
			//获取委托数据
			$entrustsql = "SELECT user,period,startdata,enddate FROM 
			          ".DB_TABLEPRE.DB_JT."app_entrust 
			          WHERE tplid = '".$tplid."' and uid = '".$userid."'";
			$entrust = $db->fetch_one_array($entrustsql);
			if(trim($newflow['perid'])!=''){
				$personnel1 = array(
					'pertype' =>$pertype,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel',$personnel1, array('perid' => $perid));
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
				$personnel2 = array(
					'pertype' =>$pertype,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel_log',$personnel2, array('perid' => $newflow['perid'],'uid' => $_USER->id));
				//创建下一步审批人员
				if($flow['flowdatetype']==1){
					$flowdate=get_date('Y-m-d H:i:s',PHP_TIME+$flow['flowdate']*60);
				}
				if($user!='' && $pertype!=2){
					$personnel=array();
					$personnel['name']=$user;
					$personnel['uid']=$userid;
					$personnel['pertype']=0;
					$personnel['designationdate']=get_date('Y-m-d H:i:s',PHP_TIME);
					$personnel['appid']=$appid;
					$personnel['flowid']=$flow['fid'];
					$personnel['appkey']=$flow['flowkey2'];
					$personnel['appkey1']=$flow['flowkey3'];
					$personnel['tplid']=$tplid;
					$personnel['flowdatetype']=$flow['flowdatetype'];
					$personnel['flowdate']=$flow['flowdate'];
					$personnel['flowkey8']=$flow['flowkey8'];
					$personnel['usernum']=','.$user.',';
					if($entrust['period']==1){
						$personnel['entrust']=$entrust['user'];
						$entrustuser=$entrust['user'];
					}else{
						$ed=get_date('Y-m-d H:i:s',PHP_TIME);
						if($entrust['startdata']<=$ed && $entrust['enddate']>=$ed){
							$personnel['entrust']=$entrust['user'];
							$entrustuser=$entrust['user'];
						}
					}
					insert_db(DB_JT.'app_personnel',$personnel);
					$pid=$db->insert_id();
					if($flow['flowkey2']==1){
						$staff=explode(',',$user);
						$staffid=explode(',',$userid);
						for($i=0;$i<sizeof($staffid);$i++){
							$personnel_log = array(
								'name' => $staff[$i],
								'uid' =>$staffid[$i],
								'pertype' =>0,
								'type' =>0,
								'perid' =>$pid,
								'appid' =>$appid,
								'tplid' =>$tplid
								);
							insert_db(DB_JT.'app_personnel_log',$personnel_log);
						}
					}	
				}
			}
		}else{
				//处理流程丢失的问题
				$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log 
			          WHERE perid = '".$perid."' and  appid = '".$appid."' and 
					  pertype='0' and uid='".$_USER->id."'";
				$newflow = $db->fetch_one_array($newsql);
				if(trim($newflow['perid'])!=''){
					if($pertype==2){
						$pertypes=2;
					}else{
						$pertypes=5;
					}
					$personnel1 = array(
						'pertype' =>$pertypes,
						'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
						'lnstructions' =>$content
						);
					update_db(DB_JT.'app_personnel',$personnel1, array('perid' => $perid));
					$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
							   userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
							   WHERE perid=".$perid." and appid = '".$appid."' ");
					flowuserdel($perid,$appid);
					$personnel2 = array(
						'pertype' =>$pertype,
						'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
						'lnstructions' =>$content
						);
					update_db(DB_JT.'app_personnel_log',$personnel2, array('perid' => $newflow['perid'],'uid' => $_USER->id));
				}
		}
	//----------------------------------------------------------------------------------
	//会签人员通道
	}elseif($views=='countersign'){
		$pertype=getGP('pertype','P','int');
		if($perid!=''){
			//处理流程丢失的问题
			$newsql = "SELECT perid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log 
			          WHERE perid = '".$perid."' and  appid = '".$appid."' and 
					  pertype='0' and uid='".$_USER->id."' and type=1";
			$newflow = $db->fetch_one_array($newsql);
			if(trim($newflow['perid'])!=''){
				$personnel1 = array(
					'pertype' =>$pertype,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel_log',$personnel1, array('perid' => $newflow['perid'],'uid' => $_USER->id));
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel  
							    SET pertype='4' WHERE perid='".$perid."'");
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
			}
		}
	//----------------------------------------------------------------------------------	
	//流程回退通道
	}elseif($views=='returns'){
			$returnfid=getGP('returnfid','P','int');
			$returnpid=getGP('returnpid','P','int');
			$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow 
				   WHERE fid = ".$returnfid."";
			$flow = $db->fetch_one_array($sql);
			$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel 
				   WHERE perid = ".$returnpid." and flowid = ".$returnfid."";
			$per = $db->fetch_one_array($sql);
			//处理流程丢失的问题
			$newsql = "SELECT perid,appkey FROM ".DB_TABLEPRE.DB_JT."app_personnel 
			          WHERE perid = '".$perid."' and (pertype='0' or pertype='4')";
			$newflow = $db->fetch_one_array($newsql);
			if(trim($newflow['perid'])!=''){
				$personnel1 = array(
					'pertype' =>3,
					'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
					'lnstructions' =>$content
					);
				update_db(DB_JT.'app_personnel',$personnel1, array('perid' => $perid));
				//处理多人审批
				if(trim($newflow['appkey'])==1){
					$personnel2 = array(
						'pertype' =>1,
						'approvaldate' =>get_date('Y-m-d H:i:s',PHP_TIME),
						'lnstructions' =>$content
						);
					update_db(DB_JT.'app_personnel_log',$personnel2, array('perid' => $newflow['perid'],'uid' => $_USER->id));
				}
				$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set 
				           userend=CONCAT_WS('',userend,'".get_realname($_USER->id).",') 
						   WHERE perid=".$perid." and appid = '".$appid."' ");
				flowuserdel($perid,$appid);
				if($per['flowdatetype']==1){
					$flowdate=get_date('Y-m-d H:i:s',PHP_TIME+$flow['flowdate']*60);
				}
				$usernum=','.$per['name'].',';
				if($per['entrust']!=''){
					$usernum.=get_realname($per['entrust']).',';
				}
				if($per['countersign']!=''){
					$usernum.=$per['countersign'];
				}
				//创建下一步审批人员
				if($per['perid']!=''){
					$personnel=array();
					$personnel['name']=$per['name'];
					$personnel['uid']=$per['uid'];
					$personnel['designationdate']=get_date('Y-m-d H:i:s',PHP_TIME);
					$personnel['pertype']=0;
					$personnel['appid']=$per['appid'];
					$personnel['tplid']=$per['tplid'];
					$personnel['flowid']=$per['flowid'];
					$personnel['appkey']=$per['appkey'];
					$personnel['appkey1']=$per['appkey1'];
					$personnel['flowdatetype']=$per['flowdatetype'];
					$personnel['flowdate']=$flowdate;
					$personnel['flowkey8']=$per['flowkey8'];
					$personnel['countersign']=$per['countersign'];
					$personnel['entrust']=$per['entrust'];
					$personnel['usernum']=$usernum;
					insert_db(DB_JT.'app_personnel',$personnel);
					$pid=$db->insert_id();
					if($per['appkey']==1){
						$staff=explode(',',$per['name']);
						$staffid=explode(',',$per['uid']);
						for($i=0;$i<sizeof($staffid);$i++){
							$personnel_log = array(
								'name' => $staff[$i],
								'uid' =>$staffid[$i],
								'pertype' =>0,
								'type' =>0,
								'perid' =>$pid,
								'appid' =>$appid,
								'tplid' =>$tplid
								);
							insert_db(DB_JT.'app_personnel_log',$personnel_log);
						}
					}
				}
			}
	}
	//----------------------------------------------------------------------------------
	//处理所有提醒，根据前台适配
		//消息提醒
		$sms_content=getGP('sms_content','P');
		$sms_box=getGP('sms_box','P','int');
		$sms_phone=getGP('sms_phone','P','int');
		$sms_mail=getGP('sms_mail','P','int');
		//发起人
		$sms_user=getGP('sms_user','P','int');
		if($sms_user!=''){
			$sms_user=public_value('uid',DB_JT.'apps','id='.$appid);
			$phone=public_value('phone','user_view','uid='.$sms_user);
			sms_box_add($sms_content,get_realname($sms_user),$phone,'',$sms_box,$sms_phone,'');
		}
		//当前步骤办理人员
		$sms_mana=getGP('sms_mana','P','int');
		if($sms_mana!=''){
			$persal = "SELECT name,countersign,entrust FROM 
			          ".DB_TABLEPRE.DB_JT."app_personnel WHERE perid = '".$perid."'";
			$persms = $db->fetch_one_array($persal);
			$sms_user=$persms['name'].','.$persms['countersign'];
			$sms_user.=','.get_realname($persms['entrust']);
			sms_box_add($sms_content,trim($sms_user),get_realphone($sms_user),'',$sms_box,$sms_phone,'');
		}
		//下一步办理人员
		$sms_next=getGP('sms_next','P','int');
		if($sms_next!=''){
			$sms_user=$user.','.get_realname($entrustuser);
			sms_box_add($sms_content,trim($sms_user),get_realphone($sms_user),'',$sms_box,$sms_phone,'');
		}
		//退回步骤办理人员
		$return_user=getGP('return_user','P','int');
		if($return_user!=''){
			sms_box_add($sms_content,trim($usernum),get_realphone($usernum),'',$sms_box,$sms_phone,'');
		}
		$content=serialize($personnel1.$personnel);
		$title='公文办理';
		get_logadd($id,$content,$title,14,$_USER->id);
		show_msg('公文己成功办理！', 'admin.php?ac=list&fileurl=apps&do=listkey&date='.get_date('YmdHis',PHP_TIME));
}elseif ($do == 'return') {
	//更新签批内容
	$perid=getGP('perid','P','int');
	$flowid=getGP('flowid','P','int');
	$content=getGP('content','P');
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'";
	$row = $db->fetch_one_array($sql);
	//获取当前流程
	$sql = "SELECT a.perid,a.name,a.uid,a.pertype,a.appkey,a.appkey1,a.countersign,a.entrust,
	        b.flowname,b.flownum,b.fid,b.flowkey,b.flowkey4,b.flowkey5,b.flowkey6 
			FROM ".DB_TABLEPRE.DB_JT."app_personnel a,
			".DB_TABLEPRE.DB_JT."app_flow b  WHERE a.flowid=b.fid and 
			a.appid = '".$appid."' and (a.pertype=0 or a.pertype=4) 
			and a.perid=".$perid." and a.flowid=".$flowid." order by a.perid desc";
	$per = $db->fetch_one_array($sql);
	$sqlnext = "SELECT fid,flownum,flowname FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE fid in(".substr($per['flowkey4'], 0, -1).") order by fid asc";
	$result = $db->fetch_all($sqlnext);
	$nextflow=explode(',',substr($per['flowkey4'], 0, -1));
	include_once('template/personnel_return.php');
}elseif ($do == 'returnflow') {
	$fid=getGP('fid','G','int');
	$appid=getGP('appid','G','int');
	if($fid!=''){
		$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel where flowid='".$fid."' and appid='".$appid."' order by perid desc";
		$flow = $db->fetch_one_array($sql);
		echo '<input type="hidden" name="returnfid" value="'.$flow['flowid'].'" />';
		echo '<input type="hidden" name="returnpid" value="'.$flow['perid'].'" />';
		echo '<div class="panel-collapse collapse in">';
		echo '<span class="badge badge-important btn-small">主办人员：</span>'; 
		echo $flow['name'].'<br>';
		if($flow['entrust']!=''){
			echo '<span class="badge badge-success btn-small">委办人员：</span>'; 
			echo get_realname($flow['entrust']);
		}
		echo '<br>';
		if($flow['countersign']!=''){
			echo '<span class="badge badge-warning btn-small">会签人员：</span>'; 
			echo $flow['countersign'];
		}
		echo '</div>';
		
	}
}elseif ($do == 'flow') {
	$fid=getGP('fid','G','int');
	$uid=getGP('uid','G','int');
	if($fid!=''){
		$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow where fid='".$fid."'";
		$flow = $db->fetch_one_array($sql);
		if($flow['flowkey7']==0){
			$flowuser1=apps_newuser($flow['flowusertype'],$flow['flowuser']);
		}else{
			$flowuser1=apps_automaticuser($flow['flowusertype'],$flow['flowuser'],$flow['flowkey7'],$uid);
		}
		echo '<input type="hidden" name="nextflowid" value="'.$flow['fid'].'" />';
		echo '<input type="hidden" name="nextappkey" value="'.$flow['flowkey2'].'" />';
		echo '<input type="hidden" name="nextappkey1" value="'.$flow['flowkey3'].'" />';
		echo '<input type="hidden" name="nextflowdatetype" value="'.$flow['flowdatetype'].'"/>';
		echo '<input type="hidden" name="nextflowdate" value="'.$flow['flowdate'].'" />';
		
		if($flow['flowkey1']==1){
			if($flow['flowkey2']==1){
				get_pubuser(2,"user",$flowuser1,"+选择审批人员",40,4);
			}else{
				$flowuser=explode(',',$flowuser1);
				get_pubuser(1,"user",$flowuser[0],"+选择审批人员",160,20);
			}
		}elseif($flow['flowkey1']==2){
			if($flow['flowkey2']==1){
				get_pubuser(2,"user",$flowuser1,"+选择审批人员",40,4,$flowuser1,1);
			}else{
				$flowuser=explode(',',$flowuser1);
				get_pubuser(1,"user",$flowuser[0],"+选择审批人员",120,20,$flowuser1);
			}
		}elseif($flow['flowkey1']==3){
			if($flow['flowkey2']==1){
				get_pubuser(2,"user",$flowuser1,"",40,4);
			}else{
				$flowuser=explode(',',$flowuser1);
				get_pubuser(1,"user",$flowuser[0],"",120,20);
			}
		}
		//echo $flowuser1;
	}
}elseif ($do == 'read') {
	if(getGP('view','P')!=''){
		$appid=getGP('appid','P','int');
		$tplid=getGP('tplid','P','int');
		$tpltype=getGP('tpltype','P','int');
		$uid=$_USER->id;
		$date=get_date('Y-m-d H:i:s',PHP_TIME);
		$readuid=explode(',',getGP('readid','P'));
		for($i=0;$i<sizeof($readuid);$i++){
			if($readuid[$i]!=''){
				$read = array();
				$read['appid']=$appid;
				$read['tplid']=$tplid;
				$read['tpltype']=$tpltype;
				$read['uid']=$uid;
				$read['date']=$date;
				$read['readuid']=$readuid[$i];
				insert_db(DB_JT.'app_read',$read);
				//$pid=$db->insert_id();
			}
		}
		//通知审批人员
		if(getGP('sms_info_box_read','P')!=''){
			$content1='您有一个公文流程需要阅读,请点击进入公文阅读里进行查看!';
			SMS_ADD_POST(getGP('read','P'),$content1,0,0,$_USER->id);
		}
		//手机短信
		if(getGP('sms_phone_box_read','P')!=''){
			$content2='您有一个公文流程需要阅读,请登录OA进行查看!';
			PHONE_ADD_POST(getGP('readphone','P'),$content2,getGP('read','P'),0,0,$_USER->id);
		}
		show_msg('公文己成功传阅致阅读人！', '?ac=workflow&fileurl='.$fileurl.'&tpltype='.$tpltype.'&tplid='.$tplid.'&do=read&info=1');
	}else{
		$appid=getGP('appid','G','int');
		$tplid=getGP('tplid','G','int');
		$tpltype=getGP('tpltype','G','int');
		$title=getGP('title','G');
		if(getGP('info','G','int')==1){
			echo '<script language="JavaScript">window.close()</script>';
		}
		include_once('template/personnel_read.php');
	}
}elseif ($do == 'delivery') {
	if(getGP('view','P')!=''){
		$title=getGP('title','P');
		$dstartid=getGP('dstartid','P');
		$dreadid=getGP('dreadid','P');
		$appendix=getGP('appendix','P');
		$content=getGP('content','P');
		$startdate=get_date('Y-m-d H:i:s',PHP_TIME);
		$dreadid=explode(',',$dreadid);
		for($i=0;$i<sizeof($dreadid);$i++){
			if($dreadid[$i]!=''){
				$delivery = array();
				$delivery['title']=$title;
				$delivery['dstart']=$dstartid;
				$delivery['dread']=$dreadid[$i];
				$delivery['appendix']=$appendix;
				$delivery['content']=$content;
				$delivery['startdate']=$startdate;
				$delivery['dtype']=0;
				insert_db(DB_JT.'app_delivery',$delivery);
				//$pid=$db->insert_id();
			}
		}
		show_msg('公文己成功分发到指定的单位！', '?ac=workflow&fileurl='.$fileurl.'&tpltype='.$tpltype.'&tplid='.$tplid.'&do=delivery&info=1');
	}else{
		$appid=getGP('appid','G','int');
		$tplid=getGP('tplid','G','int');
		$app = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'  ");
		$title=$app['title'];
		$content='data/word/wordflow/apps'.$appid.'.doc';
		$filename='';
		$fileurls='';
		$sqlappendix = "SELECT fileaddr,filename FROM ".DB_TABLEPRE.DB_JT."fileoffice where number='".$appid."' and filetype='2' and officetype='1'  order by id asc";
		$result = $db->fetch_all($sqlappendix);
		foreach ($result as $appendix) {
			$filename.=$appendix['filename'].'[toa]';
			$fileurls.=$appendix['fileaddr'].'[toa]';
		}
		$appendix=substr($filename, 0, -5).'{toa}'.substr($fileurls, 0, -5);
		if(getGP('info','G','int')==1){
			echo '<script language="JavaScript">window.close()</script>';
		}
		include_once('template/personnel_delivery.php');
	}
}
?>