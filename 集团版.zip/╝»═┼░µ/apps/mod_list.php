<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("apps_");
empty($do) && $do = 'list';
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if(getGP('tplid','G')!=''){
	$tplid=getGP('tplid','G');
}else{
	$tplid=getGP('tplid','P');
}
if ($do == 'list') {
	//列表信息 
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($number = getGP('number','G')) {
		$wheresql .= " AND number='".$number."'";
		$url .= '&number='.rawurlencode($number);
	}
	if ($tpltype!='') {
		$wheresql .= " AND tpltype='".$tpltype."'";
	}
	$vstartdate = getGP('vstartdate','G');
	$venddate = getGP('venddate','G');
	if ($vstartdate!='' && $venddate!='') {
		$wheresql .= " AND (date>='".$vstartdate."' and date<='".$venddate."')";
		$url .= '&vstartdate='.$vstartdate.'&venddate='.$venddate;
	}
	//权限判断
	$un = getGP('un','G');
	$ui = getGP('ui','G');
	if(!is_superadmin() && $ui==''){
		$wheresql .= " and uid='".$_USER->id."'";
	}
	if ($ui!='') {
		$wheresql .= " and uid in(".$ui.")";
		$url .= '&ui='.$ui.'&un='.$un;
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps WHERE 1 $wheresql  order by id desc");
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."apps WHERE 1 $wheresql  order by id desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/list.php');

}elseif ($do == 'mana') {
	//列表信息 
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'&do=mana';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND a.title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($number = getGP('number','G')) {
		$wheresql .= " AND a.number='".$number."'";
		$url .= '&number='.rawurlencode($number);
	}
	if ($tpltype!='') {
		$wheresql .= " AND a.tpltype='".$tpltype."'";
	}
	$vstartdate = getGP('vstartdate','G');
	$venddate = getGP('venddate','G');
	if ($vstartdate!='' && $venddate!='') {
		$wheresql .= " AND (a.date>='".$vstartdate."' and a.date<='".$venddate."')";
		$url .= '&vstartdate='.$vstartdate.'&venddate='.$venddate;
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_type b WHERE 1 ".$wheresql." and a.tplid=b.tplid and b.tpladmin like '%".get_realname($_USER->id)."%' order by a.id desc");
		$sql = "SELECT a.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_type b WHERE 1 ".$wheresql." and a.tplid=b.tplid and b.tpladmin like '%".get_realname($_USER->id)."%' order by a.id desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/mana.php');

}elseif ($do == 'listkey') {
	//列表信息 
	$type=getGP('type','G','int');
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&type='.$type.'&do=listkey';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND a.title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($number = getGP('number','G')) {
		$wheresql .= " AND a.number='".$number."'";
		$url .= '&number='.rawurlencode($number);
	}
	$vstartdate = getGP('vstartdate','G');
	$venddate = getGP('venddate','G');
	if ($vstartdate!='' && $venddate!='') {
		$wheresql .= " AND (a.date>='".$vstartdate."' and a.date<='".$venddate."')";
		$url .= '&vstartdate='.$vstartdate.'&venddate='.$venddate;
	}
	if($type==''){
		$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and  a.id=b.appid and (b.pertype=0 or b.pertype=4) and b.usernum like '%".get_realname($_USER->id)."%' and a.type!=1 order by b.perid desc");
		$sql = "SELECT a.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and  a.id=b.appid and (b.pertype=0 or b.pertype=4) and b.usernum like '%".get_realname($_USER->id)."%' and a.type!=1 order by b.perid desc LIMIT $offset, $pagesize";
	}elseif($type==2){
		$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.pertype!=0 and b.userend like '%".get_realname($_USER->id)."%' order by b.perid desc");
		$sql = "SELECT a.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.pertype!=0 and b.userend like '%".get_realname($_USER->id)."%' order by b.perid desc LIMIT $offset, $pagesize";
	}elseif($type==4){
		$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.hang=1 and (b.name like '%".get_realname($_USER->id)."%' or b.entrust ='".trim($_USER->id)."') order by b.perid desc");
		$sql = "SELECT a.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.hang=1 and (b.name like '%".get_realname($_USER->id)."%' or b.entrust ='".trim($_USER->id)."') order by b.perid desc LIMIT $offset, $pagesize";
	}elseif($type==5){
		$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.entrust!='' and b.name like '%".get_realname($_USER->id)."%' order by b.perid desc");
		$sql = "SELECT a.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE 1 $wheresql and a.id=b.appid and b.entrust!='' and b.name like '%".get_realname($_USER->id)."%' order by b.perid desc LIMIT $offset, $pagesize";
		
	}
	$result = $db->fetch_all($sql);
	include_once('template/listkey.php');

}elseif ($do == 'flow') {
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel where appid='".getGP('appid','G','int')."'  order by perid asc";
	$result = $db->fetch_all($sql);
	include_once('template/flow.php');
}elseif ($do == 'workkey') {
	$db->query("update ".DB_TABLEPRE.DB_JT."apps set type=1 where id = '".getGP('appid','G','int')."'");
	$content=getGP('appid','G');
	$title='撤消';
	get_logadd($id,$content,$title,14,$_USER->id);
	echo getGP('appid','G','int');
	exit;
	//show_msg(work_modid().'己成功撤消！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&modid='.$modid.'&tplid='.getGP('tplid','G').'');

}elseif ($do == 'view') {
	$appid=getGP('appid','G','int');
	if($appid!=''){
		$work = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'  ");
		$readnum = $db->result("SELECT COUNT(*) AS readnum FROM ".DB_TABLEPRE.DB_JT."app_read WHERE appid='".$appid."' order by rid desc");
		$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$work['tplid']."'  ");
		$addr = fopen('apps/tpl/'.str_replace('.php','_view.php',$tpl['tpladdr']), "r") or die("无法读取文件!");
		$tpladdr= fread($addr,filesize('apps/tpl/'.$tpl['tpladdr']));
		fclose($addr); 
		//获取数据
		$tpladdr=apps_viewdb($work['tplid'],$work['tpltype'],$appid,$tpladdr);
		//获取表单信息
		$file = $db->fetch_one_array("SELECT fileid FROM ".DB_TABLEPRE.DB_JT."fileoffice  WHERE number = 'apps".$appid."' and officetype='1' and filetype='1'");
		if($file['fileid']==''){
			$file['fileid']='51515800000';
		}
		$openaddr='';
		$tpladdrs= str_replace('.php','.doc',$tpl['tpladdr']);
		$fileaddr='data/word/wordflow/';
		include_once('template/view.php');
	}
}elseif ($do == 'viewexcel') {
	$appid=getGP('appid','G','int');
	if($appid!=''){
		$work = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'  ");
		$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$work['tplid']."'  ");
		$addr = fopen('apps/tpl/'.str_replace('.php','_view.php',$tpl['tpladdr']), "r") or die("无法读取文件!");
		$tpladdr= fread($addr,filesize('apps/tpl/'.$tpl['tpladdr']));
		fclose($addr); 
		//获取数据
		$tpladdr=apps_viewdb($work['tplid'],$work['tpltype'],$appid,$tpladdr);
		if(getGP('types','G')=='word'){
			$filepath="data/word/apps/toa_".$appid."_".get_date('YmdHis',PHP_TIME).".doc";
			$fileContent = getWordDocument($tpladdr,$_CONFIG->config_data('web'));
			$fp = fopen($filepath, 'w');
			fwrite($fp, $fileContent);
			fclose($fp);
			
		}elseif(getGP('types','G')=='excel'){
			$filepath="data/excel/apps/toa_".$appid."_01".get_date('YmdHis',PHP_TIME).".xls";
			include_once('template/view_excel.php');
		}
		echo $filepath;
		exit;
	}
}elseif ($do == 'update') {
	get_key("apps_del");
	$idarr = getGP('id','G');
	$ids=explode(',',$idarr);
	for($i=0;$i<sizeof($ids);$i++){
		$tpl = $db->fetch_one_array("SELECT tplid FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$ids[$i]."'  ");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."apps WHERE id = '".$ids[$i]."' ");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_personnel where appid = '".$ids[$i]."' ");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_personnel_log WHERE appid = '".$ids[$i]."' ");
		if($tpl['tplid']!=''){
			$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."apps_".$tpl['tplid']." WHERE appid = '".$ids[$i]."' ");
		}
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."fileoffice WHERE officetype=1 and number = '".$ids[$i]."' ");
		
	}
	$content=serialize($idarr);
	$title='删除公文';
	get_logadd($id,$content,$title,14,$_USER->id);
	echo $idarr;
	//show_msg(work_modid().'删除成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&modid='.$modid.'&tplid='.$tpl['tplid'].'&type='.$_GET['type']);

}elseif ($do == 'excel') {
		get_key("apps_excel");
		$datename="apps_".get_date('YmdHis',PHP_TIME);
		$outputFileName = 'data/excel/'.$datename.'.xls';
		$wheresql = '';
		if ($title = getGP('title','P')) {
			$wheresql .= " AND a.title LIKE '%$title%' ";
		}
		if ($number = getGP('number','P')) {
			$wheresql .= " AND a.number='".$number."'";
		}
		if ($tpltype = getGP('tpltype','P')) {
			$wheresql .= " AND a.tpltype='".$tpltype."'";
		}
		$vstartdate = getGP('vstartdate','P');
		$venddate = getGP('venddate','P');
		if ($vstartdate!='' && $venddate!='') {
			$wheresql .= " AND (a.date>='".$vstartdate."' and a.date<='".$venddate."')";
		}
	
		$content = array();
		$archive=array("编号","类型","公文类别","名称","发起人","发起时间");
		$content[] = $archive;
		$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."apps a WHERE 1 $wheresql  ORDER BY a.id desc";
		$result = $db->query($sql);
		while ($row = $db->fetch_array($result)) {
			if($row[tpltype]==1){
				$tpltype='收文';
			}else{
				$tpltype='发文';
			}
			$archive = array(
				"".$row[number]."",
				"".$tpltype."",
				"".public_value('title',DB_JT.'app_type','tplid='.$row[tplid])."",
				"".$row[title]."",
				"".get_realname($row['uid'])."",
				"".str_replace("-",".",$row[date]).""
			);
			$content[] = $archive;
		}
	$excel = new ExcelWriter($outputFileName);
	if($excel==false) 
		echo $excel->error; 
	foreach($content as $v){
		$excel->writeLine($v);
	}
	$excel->sendfile($outputFileName);
}elseif ($do == 'worksms') {
	if(getGP('view','G')!=''){
		$content=unescape(getGP('box_content_user','G'));
		$user=unescape(getGP('user','G'));
		$phone=get_realphone($user);
		$sms_box=getGP('sms_box_user','G','int');
		$sms_phone=getGP('sms_phone_user','G','int');
		sms_box_add($content,$user,$phone,'',$sms_box,$sms_phone,'');
		echo 'true';
		exit;
	}else{
		$user='';
		$perid=getGP('perid','G','int');
		$appid=getGP('appid','G','int');
		$title=public_value('title',DB_JT.'apps','id='.$appid);
		$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE appid = '".$appid."'   and perid='".$perid."'  order by perid desc";
		$per = $db->fetch_one_array($sql);
		if($per['entrust']!=''){
			$user.=get_realname($per['entrust']).',';
		}else{
			$user.=trim($per['name']).',';
		}
		if($per['countersign']!=''){
			$user.=trim($per['countersign']).',';
		}
		echo '<div class="control-group ">';
		echo '<label class="control-label required" for="AttachmentItem_file_name"';
		echo '>流程办理人员 <span class="required">*</span></label>';
		echo '<div class="controls">';
		echo '<textarea name="user" readonly style="width:350px;height=60px;">'.substr($user, 0, -1).'</textarea>';
		echo '</div></div>';
		echo get_newsmsbox('办理人员','user',get_realname($_USER->id)."提醒您尽快办理一下流程(".$title.")");
	}
	
}
?>