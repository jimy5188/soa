<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<title>Office 515158 2011 OA办公系统</title>
<script type="text/javascript">
function CheckForm(){
   if(document.save.title.value==""){ 
     alert("公文名称不能为空！");
     document.save.title.focus();
     return (false);
   }
   if(document.save.dstart.value==""){ 
     alert("发文单位不能为空！");
     document.save.dstart.focus();
     return (false);
   }
   if(document.save.dread.value==""){ 
     alert("收文单位不能为空！");
     document.save.dread.focus();
     return (false);
   }
   return true;
}
function sendForm(){
   if(CheckForm()){
      document.save.submit();
   }
}
function refreshParentss(){
   window.close();  
}
</script>
</head>
<body>
<div class="search_area">
        <table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<?php echo $title;?>
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<button type="button" onClick="sendForm();" action="cancel_concern" class="btn btn-danger">确认分发</button>
 <button id="do_search" type="button" onClick="refreshParentss();" class="btn btn-primary">关闭</button>
	</td>
  </tr>
</table>
</div>
<form name="save" method="post" action="admin.php?ac=workflow&do=delivery&fileurl=<?php echo $fileurl?>">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="appendix" value="<?php echo $appendix;?>" />
	<input type="hidden" name="content" value="<?php echo $content;?>" />
<table class="TableList" border="0" width="90%" align="center" style="border-bottom:#4686c6 solid 0px; margin-top:20px;">

	<tr>
      <td nowrap class="TableContent" width="20%"> 公文名称：</td>
      <td class="TableData"><input type="text" name="title" class="BigInput" size="20" value="<?php echo $title;?>" style="width:368px;" /></td>
    </tr>
	
	<tr>
      <td nowrap class="TableContent" width="20%">发文单位：</td>
      <td class="TableData"><?php
	  get_depabox(1,"dstart",get_realdepaname(public_value('departmentid','user','id='.$_USER->id)),"+选择发文单位",300,20)
	  ?></td>
    </tr>

	<tr>
      <td nowrap class="TableContent" width="20%"> 收文单位：</td>
      <td class="TableData">
      <?php //get_pubuser(2,"dread",'',"+选择收文单位","300' style='width:600px;",8);?>
	  <?php
	  get_depabox(2,"dread",'',"+选择收文单位","60' style='width:500px;",6)
	  ?>	   </td>
    </tr>
	</table>
	

</form>
</body>
</html>
