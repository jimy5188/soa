<!DOCTYPE HTML>
<html>
	<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<title>Office 515158 2011 OA办公系统</title>
<style type="text/css">
@charset "utf-8";
/*reset*/
html,body,div,dl,dt,dd,ul,ol,li,h1,h2,h3,h4,h5,h6,pre,form,fieldset,input,textarea,p,label,blockquote,button,span{padding:0;margin:0;}
html{background:url(../images/v3/bg.png) repeat-x center bottom #efefef;}
body{font:12px/22px "宋体";color:#000;-webkit-text-size-adjust:none;padding-bottom:100px;min-width:98%;}
table{border-collapse:collapse;border-spacing:0;}
fieldset,img{border:none;}
address,caption,cite,code,dfn,th,var,em{font-weight:normal;font-style:normal;}
ol,ul{list-style:none;}
caption,th{text-align:left;}
h1,h2,h3,h4,h5,h6{font-weight:normal;font-size:100%;}
input{vertical-align:middle}
.iDialogLayout{position:fixed;_position:absolute;left:0;top:0;width:100%;height:100%;background:#000;background:-webkit-radial-gradient(center,rgba(0,0,0,0.3),rgba(0,0,0,1) 80%);background:-moz-radial-gradient(center,rgba(0,0,0,0.3),rgba(0,0,0,1) 80%);background:-o-radial-gradient(center,rgba(0,0,0,0.3),rgba(0,0,0,1) 80%);background:radial-gradient(center,rgba(0,0,0,0.3),rgba(0,0,0,1) 80%);opacity:0.6;filter:alpha(opacity=30);}
.iOpacityZero{opacity:0;filter:alpha(opacity=0);}

/* IE6下背景蒙层 */
.iFrameGround{
	position:absolute;
	left:0;
	top:0;
	width:100%;
	height:100%;
	filter:alpha(opacity=0);
}

/*
 * 对话框最外层包装元素
 * 大尺寸对话框请慎重设置 position:fixed; 否则内容超过一屏时，超出的内容将永远无法看见
 * 具体项目根据实际需求可以修改，脚本中已经对此做出智能判断（但不修复IE6的bug）
 */
.iDialog{position:fixed;_position:absolute;font:14px/1.75 Arial, sans-serif, 宋体;color:#2b2b2b;text-align:left;}

/* 透明边框 */
.iDialogWrapTable{
	border-spacing: 0;
	border-collapse: collapse;
	width:100%;
}
.autoWidthDialog .iDialogWrapTable{ width:auto; }


/*
 * 内置样式
 */
.iFrameDialog .iDialogMain{ padding:0; overflow:hidden }

/*link*/
a{text-decoration:none;}
a:link{color:#146C91;}
a:visited{color:#146C91}
a:hover{color:#c9171e;text-decoration:underline;}
a:active,a:focus{color:#146C91;}
a.grayLink {color:#666}
a.grayLink:hover {color:#666;}
/*clear*/
.clearfix{*zoom:1;}
.clearfix:after{content:'\20';display:block;height:0;clear:both;}
.clear{clear:both}
/*common*/
.input {height:18px;line-height:18px;padding:6px 5px;width:240px;border:#cecece 1px solid;background:#fff}
h2,h3{font-size:14px;font-weight:900;color:#333}
.inputPlaceholder {display:block;width:234px;height:32px;line-height:32px;color:#b2b2b2;position:absolute;padding:0 5px;font-family:"宋体";cursor:text;}
.fl{float:left;}
.fr{float:right;}
.tc {text-align:center}
.tr {text-align:right}
.space {padding:0 5px}
.pr{position:relative;}
.f12{font-size:12px}
.f14{font-size:14px}
.f16{font-size:16px}
.f18{font-size:18px}
.fMs{font-family:"微软雅黑"}
.fw{font-weight:bold}
.c_666 {color:#666}
.c_gray {color:#999}
.c_red {color:#bf2531}
.c_blue{color:#1e50a2}
.c_orange {color:#fc4907}
.c_green {color:#36b965}
.p10 {padding:10px}
.pt10 {padding-top:10px}
.pt20 {padding-top:20px}
.pl30 {padding-left:30px}
.mt10 {margin-top:10px}
.w60 {width:60px}
.w110 {width:110px}
.db {display:block}
.lh22 {line-height:22px}
.noBorder {border:none 0 !important;}
.c_333{color:#333;}
.c_DFE1E1{color:#DFE1E1}
.c_EF7000{color:#EF7000;}
.fs20{font-size:20px}
.disNone{display:none}



/* main */
.wrap {width:100%;margin:0 auto;}
.secMenu {width:200px;float:left;margin:0 -1px 0 -199px;*margin:0 -4px 0 -196px;zoom:1;display:inline}
.indexContent,.mainContent {padding-left:200px;width:83%;margin:0 auto;background:#f8f8f8;box-shadow:0 0 5px rgba(0,0,0,0.2);*border:#cecece 1px solid;overflow:hidden;border-radius:3px}
.mainContent{padding:10px;width:970px;}
.secMenuBox {width:200px;height:823px;position:relative;overflow:hidden;zoom:1;float:left;}
.secMenuTit {font-size:16px;height:40px;line-height:40px;padding:22px 0 0 25px;font-weight:bold;color:#333}
.secMenuBox ul{width:189px;padding-left:11px;*width:186px;}
.secMenuBox ul li{position:relative;}
.secMenuBox a{display:block;padding:10px 0 11px 11px;_padding:17px 0 5px 11px;height:28px;line-height:28px;color:#666 !important;font-size:14px;border-radius:3px 0 0 3px;}
.secMenuBox a:hover {background:#d8dbdf;text-decoration:none}
.secMenuBox a b{display:inline-block;margin-right:5px;vertical-align:middle;}
.titIcon {width:0;height:0;font-size:0px;line-height:0;border-width:5px;border-color:#f8f8f8 #f8f8f8 #f8f8f8 #969696;border-style:solid;}
.secMenuBox .active a,.secMenuBox .active a:hover{background:#fff !important;color:#333 !important;cursor:default;position:relative;z-index:2;; box-shadow:0 0 10px rgba(0,0,0,0.2);*border:#cecece 1px solid;*border-right:0 none;*padding:9px 0 10px 10px;_padding:15px 0 4px 10px;}
.secContent{float:left; margin:auto;background:#fff;width:97%;padding-left:23px;min-height:823px;_height:823px;box-shadow:0 0 10px rgba(0,0,0,0.2);border-left:#cecece 1px solid;float:left;}
.secMenuBox a:hover .titIcon{border-color:#D8DBDF #D8DBDF #D8DBDF #969696;}
.secMenuBox .active .titIcon,.secMenuBox .active a:hover .titIcon{border-color:#fff #fff #fff #969696}
.tabTitle{font-size:22px; font-family:"微软雅黑";height:48px;line-height:48px; font-weight:normal;border-bottom:#888 2px solid;}
.garyLine{height:1px;line-height:1px;font-size:1px;border-top:1px solid #DCDCDC}

.newWrap {width:100%;margin:0 auto;position:relative;top:-55px;_width:100%;}
/*按钮*/
.btn1Box{padding-left:6px; background:url(template/default/content/images/icon.png?20130318);display:inline-block;height:40px;line-height:40px; cursor:pointer; margin-right:10px;vertical-align:middle;}
.btn1{padding-right:27px;padding-left:27px;height:38px;height:38px;display:inline-block;border:none; background:url(template/default/content/images/icon.png?20130318) right 0;cursor:pointer;position:relative;color:#1B6F9D;color:#fff;font-size:16px;font-weight:bold; overflow:visible;vertical-align:top}
.btn1 em{ position:absolute;top:11px;top:1px\9;color:#fff;font-size:16px;font-weight:bold;text-align:center;display:none}
.btn1Box:hover{background-position:0 -45px;}
.btn1:link,.btn1:visited{color:#fff; text-decoration:none}
.btn1Box .btn1:hover{background-position:right -45px;}
.btn1Disbled,.btn1Disbled:hover{background-position:0 -91px;}
.btn1Disbled .btn1,.btn1Disbled .btn1:hover{background-position:right -91px;color:#3F3F3F;_color:#fff;}
</style>
<script type="text/javascript">
function notk_word(fileType,filenumber,FileId,title)
{
   mytop=(screen.availHeight-600)/2;
   myleft=(screen.availWidth-1002)/2;
   window.open("ntko/show.php?fileType="+fileType+"&FileId="+FileId+"&title="+title+"&filenumber="+filenumber+"&officetype=50&uid=<?php echo $_USER->id?>&Fileurl=apps/tpl/&date=<?php echo get_date('Y-m-d H:i:s',PHP_TIME)?>","","height=600,width=1002,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
   //window.location.reload();
} 

</script>
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
</head>	
<body>
<!--主体 开始-->
<div class="newWrap">
	<div class="indexContent clearfix">
    	
		
<div class="secMenu" style="margin-top:50px;">        	
    <div class="secMenuBox" id="secMenuBox">
    <div class="secMenuTit"></div>
    <ul class="appShow">
		<li <?php if($tpltype==''){?>class="active"<?php }?>><a href="admin.php?ac=add&fileurl=apps"><b class="titIcon"></b>所有公文</a></li>
    	<li <?php if($tpltype==1){?>class="active"<?php }?>><a href="admin.php?ac=add&fileurl=apps&tpltype=1"><b class="titIcon"></b>公文收文</a></li>
    	<li <?php if($tpltype==2){?>class="active"<?php }?>><a href="admin.php?ac=add&fileurl=apps&tpltype=2"><b class="titIcon"></b>公文发文</a></li>
    	
    </ul>
    </div>
</div>

        <div class="secContent" style="padding-top:80px;">
        
     
       <h2 class="tabTitle">新建流程列表</h2>
      <div  style="height:20px;">
    
        
      </div>
	  <table width="97%" border="0" align="center" cellspacing="0" class="TableBlock" style="float:left;">
	<tr>
      <td nowrap class="TableHeader" align="center" width="50">No.</td>
      <td class="TableHeader">流程名称</td>
      <td width="120" align="center" class="TableHeader">流程步骤</td>
      <td width="120" align="center" class="TableHeader">流程表单</td>
      <td width="180" align="center" class="TableHeader">操作</td>
    </tr>
<?
global $db;
if($tpltype!=''){
	$wh=" and tpltype='".$tpltype."'";
}
//$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type where  tplkey!='2' and (tpluser like'%".get_realname($_USER->id)."%' or tpluser='0') $wh ORDER BY tplid Asc");
$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type where  tplkey!='2' $wh ORDER BY tplid Asc");
while ($trow = $db->fetch_array($query)) {
if($trow['tpluser']!='' && $trow['tpluser']!='0'){
	if($trow['tplusertype']=='2'){
		$html=',';
		$tpluser=explode(',',$trow['tpluser']);
		for($i=0;$i<sizeof($tpluser);$i++){
			if(trim($tpluser[$i])){
				$sqluser = "SELECT b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and  a.positionid like '%,".trim($tpluser[$i]).",%'  ORDER BY b.uid desc";
				//$rowuser1 = $db->fetch_one_array($sqluser);
				$rowuserresult = $db->fetch_all($sqluser);
				foreach ($rowuserresult as $rowuser1) {
					if($rowuser1['name']!=''){
						$html.=$rowuser1['name'].',';
					}
				}
			}
			//if($rowuser1['name']!=''){
			//	$html.=$rowuser1['name'].',';
			//}
		}
		$tpluser1=$html;
	}elseif($trow['tplusertype']=='3'){
		$html=',';
		$tpluser=explode(',',$trow['tpluser']);
		for($i=0;$i<sizeof($tpluser);$i++){
			if(trim($tpluser[$i])){
				$sqluser = "SELECT b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and  a.departmentid like '%,".trim($tpluser[$i]).",%'  ORDER BY b.uid desc";
				//$rowuser1 = $db->fetch_one_array($sqluser);
				$rowuserresult = $db->fetch_all($sqluser);
				foreach ($rowuserresult as $rowuser1) {
					if($rowuser1['name']!=''){
						$html.=$rowuser1['name'].',';
					}
				}
			}
			//if($rowuser1['name']!=''){
			//	$html.=$rowuser1['name'].',';
			//}
		}
		$tpluser1=$html;
		//echo $html;
	}else{
		$tpluser1=','.$trow['tpluser'].',';
	}
}else{
	$tpluser1='0';
}
if(sizeof(explode(get_realname($_USER->id),$tpluser1))>1 || $tpluser1=='0'){
$urls='"admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$trow[tpltype].'&tplid='.$trow[tplid].'""';
if(file_exists("apps/tpl/".$trow[tpladdr])==''){
	$urls='"#"';
}
$ico='app'.$trow['tpltype'];
?>
	<tr>
<td align="center" class="TableData"><?php echo $trow['tplid']?></td>
 <td valign="middle" class="TableData" style="padding-left:10px;">
 <img src="template/default/content/images/<?php echo $ico;?>.png" width="16" height="16"> <a href="javascript:;" onClick="window.open ('admin.php?ac=flow&fileurl=apps&tplid=<?php echo $trow['tplid']?>&tpltype=<?php echo $tpltype;?>&do=pic', 'newwindow<?php echo $trow['tplid']?>', 'height=620, width=800, top=6, right=0, toolbar=no, menubar=no, scrollbars=yes, resizable=yes,location=no, status=no')"  style="font-size:14px;"><?php echo $trow['title']?></a></td>
	  
      <td align="center" class="TableData"><a href="javascript:;" onClick="window.open ('admin.php?ac=flow&fileurl=apps&tplid=<?php echo $trow['tplid']?>&tpltype=<?php echo $trow['tpltype']?>&do=pic', 'newwindow<?php echo $trow['tplid']?>', 'height=620, width=800, top=6, right=0, toolbar=no, menubar=no, scrollbars=yes, resizable=yes,location=no, status=no')" >查看流程图</a></td>
      <td align="center" class="TableData">
	  <a href="admin.php?ac=add&fileurl=apps&do=tplshow&tplid=<?php echo $trow['tplid']?>&tpltype=<?php echo $trow['tpltype']?>" target="_blank">流程表单</a>
	  </td>

      <td align="center" class="TableData">
	<span class="btn1Box">
           <a class="btn1" href=<?php echo $urls?>>新建流程<em>新建流程</em></a>
          </span>
	  </td>
    </tr>
	
<?php }
} ?>	

	<tr>
<td class="TableData" colspan="5"><div class="tipText6">温馨提示：还没有配置公文类别，请到公文设置里进行添加。</div></td>
 
    </tr>

  </table>
	
		
		
		

      </div>
      
      
    </div>
   
  </div>
</div>



</body>
</html>
