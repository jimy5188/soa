<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
		
        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap-modal.css" />
		        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap.css"> 
				<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>bootstrap/css/bootstrap-datetimepicker.css"> 
        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/base.css">
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/style.css">
		<script type="text/javascript" src="<?php echo style2015;?>content/js/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modal.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modalmanager.js"></script>
		<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
   </head>
	<body >
	<div class="tabbable work-nav"> <!-- Only required for left/right tabs -->
				<ul id="myTab" class="nav nav-tabs">
					<li class="active">
<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>" >公文委托信息</a></li>
				<li>
<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&do=entrustuser" >被委托信息</a></li>
				</ul>
			</div>
<div class="search_area">
    <form method="get" action="admin.php" name="searchs" class="form-horizontal">
	<input type="hidden" name="ac" value="entrust" />
		<input type="hidden" name="do" value="list" />
		<input type="hidden" name="fileurl" value="apps" />
        <div class="form-search form-search-top" style="text-align:left;padding-left:20px;">
			<?php echo get_keyuser($ui,$un);?>
            <div class="adv-select-label">公文类别：</div>
             <select name="tplid">
			 <option value="0" selected>全部公文类别</option>
			 <?php
			 $query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type where  tplkey!='2'  ORDER BY tplid Asc");
			while ($trow = $db->fetch_array($query)){
			?> 
             <option value="<?php echo $trow['tplid'];?>" <?php if($tplid==$trow['tplid']){?> selected<?php }?>><?php echo $trow['title'];?></option>
			 <?php }?>
             </select>
			<div class="adv-select-label">被委托人：</div>
			<?php get_pubuser(1,"users",get_realname($usersid),"+选择",120,20);?>
            <button id="do_search" type="button" style="margin-left:10px;" onClick="document:searchs.submit();" class="btn btn-primary">查 询</button>
           <!-- <button  onClick="formview()" type="button" class="btn">切换更多查询</button> -->
        </div>
       
    </form>
</div>


	
	
		
	<div class="content" >
		<div style="padding-top:5px;">
			<!--文件夹开始-->
			<div  id="entrust" style="height:445px;min-width:600px !important;" class="modal hide fade">
				<div class="modal-header">
					<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
					<h4>添加公文委托规则（提前委托）</h4>
				</div>
				<div class="modal-body" style="overflow: visible !important;position: relative !important; height:295px;">
					<div class="modal-body" style="position:absolute; height:265px;overflow:auto; " id="modal-bodys">
						
					 </div>
					
				</div>
				<div class="modal-footer" style="text-align:right">
    <button onClick="entrustadd();" class="btn btn-danger" type="button">保存数据</button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button data-dismiss="modal" class="btn" id="yw12" name="yt10" type="button">取消</button></div>
			</div>
			<!--文件夹结束-->
			
			<div id="folder-grid" class="grid-view">
				<div class="toolbar"  style="margin-left:10px;">
						<a action-type="entrust" style="margin-right:5px;" class="btn btn-primary">
							新建委托人
						</a>
						
						<a class="btn btn-danger" onClick="DeleteFile('admin.php?ac=entrust&fileurl=apps&do=update');" style="margin-right:5px;">
							批量删除
						</a>
				</div>
				<div style="float:right; text-align:right; margin-right:20px;">
							<?php echo newshowpage($num,$pagesize,$page,$url);?>
						</div>
				<table class="items table table-striped" style="margin-bottom:0px;">
					<thead>
						<tr>
							<th style="width:10px" id="folder-grid_c0">
							<input type="checkbox" value="1"  onClick="check_all(this);" class="icon-checkbox-unchecked" /> 
							</th>
							<th style="width:100%;" id="folder-grid_c1">类别名称</th>
							<th style="width: 120px;" id="folder-grid_c6">委托人</th>
							<th style="width: 120px;" id="folder-grid_c7">被委托人</th>
							<th style="width: 90px;" >有效期</th>
							<th style="width: 120px;text-align:center;" id="folder-grid_c8">操作</th>
						</tr>
					</thead>
					</table>
					<div style="position:absolute; height:64%; width:100%;overflow:auto; ">
					<table class="items table table-striped" style="margin-top:0px;">
				    <tbody>
					<?php 
					foreach ($result as $row) {
					?>
						<tr class="odd">
						<td class="notopen" style="width:10px">
						<input value="<?php echo $row['id'];?>" id="folder-grid" type="checkbox" name="ids[]" />
						</td>
						<td class="ellipsis" style="width:100%;">
						<?php 
						if($row['tplid']!=0){
							echo public_value('title',DB_JT.'app_type','tplid='.$row['tplid']);
						}else{
							echo '全部类别';
						}?>
						</td>
						
						<td style="width:120px;">
						<?php echo get_realname($row['uid'])?></td>
						<td style="width:120px;"><?php echo get_realname($row['user'])?></td>
						<td style="width:90px;">
						<?php
							if($row['period']==1){
								echo '一直有效';
							}else{
								if($row['enddate']<=get_date('Y-m-d H:i:s',PHP_TIME)){
									echo '己过期';
								}else{
									echo '有效';
								}
							}
						?>
						
						</td>
						
						<td style="width: 120px;text-align:center;"  class="notopen">
						<a class="icon-pencil td-link-icon"  style="cursor:pointer; margin-top:3px;" rel="tooltip" onClick="UpdateFile(<?php echo $row['id'];?>);" tabindex="-1" href="javascript:;">编辑</a>
						<a class="download td-link-icon icon-download-2" style=" margin-top:3px;" href="javascript:;" onClick="DeleteForm(<?php echo $row['id'];?>,'admin.php?ac=entrust&fileurl=apps&do=update');">删除</a></td>
						</tr>
						<?php }?>
						
					</tbody>
					
				</table>
			</div>
				
			</div>
		</div>
	</div>
			<script>
				$(document).ready(function() {
					initRight();
					//$("#message-info").hide();
				});
				initRight = function() {
					$("[action-type='entrust']").live('click',function(event) {
						$("#entrust").modal({
							"backdrop": "static",
							"show": true
						});
						entrustui();
					}
					),
					$("#period").live('click',function(event) {
						var chk_value =[]; 
						$('input[name="period"]:checked').each(function(){ 
							chk_value.push($(this).val()); 
						}); 
						if(chk_value==1){
							$("#startdatas").hide();
							$("#enddates").hide();
						}else{
							$("#startdatas").fadeIn("slow");
							$("#enddates").fadeIn("slow");
						}
					}
					);
					
				}
				function UpdateFile(id) {
					$("#entrust").modal({
						"backdrop": "static",
						"show": true
					});
					entrustui(id);
				}
				function tplmenu(tplid,tplidname){
					$("#tplidname").text(tplidname);
					$("#tplid").val(tplid);
				}

			</script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/appsflow.js"></script>
	<div  id="MsgShow" style="height:200px;min-width:500px !important;" class="modal hide fade">
		<div class="modal-header">
			<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
			<h4>消息提示</h4>
		</div>
		<div class="modal-body" id="MsgShowContent" style="font-size:22px; text-align:center; line-height:60px;color:#009933;"></div>
	</div>
	</body>
</html>