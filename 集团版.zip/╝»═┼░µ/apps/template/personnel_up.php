<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="template/default/js/jquery.min.js"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<title>Office 515158 2011 OA办公系统</title>
 
</head>
<body class="bodycolor">
<table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td class="Big"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3"> <?php echo $row['title']?></span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:12px; float:right; margin-right:20px;">
	<a href="admin.php?ac=add&fileurl=<?php echo $fileurl;?>&appid=<?php echo $appid;?>&tplid=<?php echo $tplid;?>&perid=<?php echo $perid;?>&flowid=<?php echo $flowid;?>" style="font-size:12px;"><< 返回上一步</a>
    </td>
  </tr>
</table>

<script Language="JavaScript">
 
function ckeditor(){
	var val = CKEDITOR.instances.content.getData();
	if (val.length == 0){
		alert("退回意见不能为空！");
		document.save.content.focus();
		return (false);
	}else{
		return true;
	}
}
function sendForm()
{
   if(ckeditor())
      document.save.submit();
}
user_show();
function user_show(flowid)
{
   jQuery.ajax({
      type: 'GET',
      url: 'admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&do=upajax&appid=<?php echo $appid;?>&flowkey4=<?php echo substr($per['flowkey4'], 0, -1);?>&flowid='+flowid+'&'+new Date(),
      success: function(data){
		  if(data!=''){
			  $("#ajaxuser").html(data);
			  //alert(data);
		  }
      }
   });
   //window.setTimeout(filenumber_show,120*10);
}
</script>
	<form name="save" method="post" action="admin.php?ac=workflow&do=personnel&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $tpltype?>&tplid=<?php echo $tplid?>">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="title" value="<?php echo $row['title']?>" />
	<input type="hidden" name="appid" value="<?php echo $row['id']?>" />
	<input type="hidden" name="oldappkey" value="<?php echo $per['appkey']?>" />
	<input type="hidden" name="oldappkey1" value="<?php echo $per['appkey1']?>" />
	<input type="hidden" name="perid" value="<?php echo $per['perid']?>" />
	<input type="hidden" name="oldappflow" value="<?php echo $per['flowid']?>" />
	<input type="hidden" name="pkey" value="3" />
	<input type="hidden" name="views" value="3" />
<table class="TableBlock" border="0" width="70%" align="center">
	<tr>
      <td nowrap class="TableHeader" colspan="2"><b>&nbsp;请选择退回步骤： </b></td>
    </tr>
	<tbody id="ajaxuser">
	</tbody>
	</table>
	<table class="TableBlock" border="0" width="70%" align="center" style="margin-top:10px;">
	<tr>
      <td nowrap class="TableHeader" colspan="2"><b>&nbsp;退回意见： </b></td>
    </tr>
	<tr>
	<td class="TableData"><textarea id="content" cols="20" rows="2" class="ckeditor"  name="content"></textarea></td>
	</tr>
	<tr align="center" class="TableControl">
      <td nowrap height="35">
<input type="button" name="Submit" value="确 定" class="BigButtonBHover" onclick="sendForm();"> 	  </td>
    </tr>
</table>

</form>

</body>
</html>
