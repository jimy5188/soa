<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrapapps.min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap-modal.css" />
		        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap.css"> 
				<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>bootstrap/css/bootstrap-datetimepicker.css"> 
        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/base.css">
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/style2015.css">
		<script type="text/javascript" src="<?php echo style2015;?>content/js/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modal.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modalmanager.js"></script>
		<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript">
	function active(type){
		if(type!=''){
			document.getElementById('from').className = '';
			document.getElementById('attchment').className = '';
			document.getElementById('remark').className = '';
			document.getElementById('flow').className = '';
			document.getElementById(type).className = 'active'; 
		}
	}
	function notk_word(){
	   mytop=(screen.availHeight-600)/2;
	   myleft=(screen.availWidth-1002)/2;
	   window.open("ntko/service.php?fileType=word&FileId=<?php echo $file['fileid'];?>&filenumber=<?php echo 'apps'.DB_JT.$appid;?>&officetype=1&uid=<?php echo $_USER->id?>&Fileurl=<?php echo $fileaddr;?>&openurl=<?php echo $openaddr;?>&tpladdr=<?php echo 'apps'.DB_JT.$appid;?>.doc&title=<?php echo $work['title'];?>&date=<?php echo get_date('Y-m-d H:i:s',PHP_TIME)?>","","height=600,width=1002,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
	}
</script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav">
				<ul id="myTab" class="nav nav-tabs">
					<li class="active" id="from"><a href="#form" onClick="active('from');">公文表单</a></li>
					<li><a href="javascript:;"  onClick="notk_word();">正文版式</a></li>
					<li id="attchment"><a href="#content-attchment" onClick="active('attchment');">流程附件</a></li>
					<li id="remark"><a href="#content-remark" onClick="active('remark');">流程签批</a></li>
					<li id="flow"><a href="#content-flow"  onClick="active('flow');">办理进度</a></li>
				</ul>
</div>
<script type="text/javascript">
function CheckForm(){
   if(document.save.number.value=="")
   { alert("编号不能为空！");
     document.save.number.focus();
     return (false);
   }
   if(document.save.title.value=="")
   { alert("公文名称不能为空！");
     document.save.title.focus();
     return (false);
   }
<?
global $db;
$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from where tplid='".$tplid."' and inputtype!='7' and inputtype1!='3' and inputtype1!='4' ORDER BY fromid Asc");
$formkey=$flows['formkey'];
	while ($row = $db->fetch_array($query)) {
	if(sizeof(explode('"'.$row['inputname'].'"',$formkey))>1){
		if($row["confirmation"]=='1'){
?>

if(document.save.<?php echo $row["inputname"]?>.value=="")
   { alert("<?php echo $row["fromname"]?>不能为空！");
     document.save.<?php echo $row["inputname"]?>.focus();
     return (false);
   }
   
<?php
	}
  }
}
?>
   return true;
}
function ckeditor(){
	var val = CKEDITOR.instances.content.getData();
	if (val.length == 0){
		_MsgShow("流程签批不能为空！");
		return (false);
	}else{
		return true;
	}
}
function _A(){
   if(CheckForm()){
      document.save.submit();
   }
}
function _B(type){
	<?php if($flows['flownum']==1){?>
	if(CheckForm()){
	<?php }else{?>
   if(CheckForm() && ckeditor()){
   <?php }?>
	  document.getElementById("save").action = '?ac=workflow&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>&psntype='+type;
	  document.getElementById("save").submit();
   }
}
function _C(type){
	document.getElementById("save").action = '?ac=workflow&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&do=return&tpltype=<?php echo $tpltype?>';
	document.getElementById("save").submit();
}
filenumber_show();
function filenumber_show()
{
   jQuery.ajax({
      type: 'GET',
      url: 'admin.php?ac=file&fileurl=public&do=newfile&filenumber=<?php echo $appid;?>&officetype=1&'+new Date(),
      success: function(data){
		  if(data!=''){
			  $("#filevalue").html(data);
			  $("#filetitle").html('附件列表');
		  }else{
			  $("#filevalue").html('');
		  }
      }
   });
   window.setTimeout(filenumber_show,120*10);
}
function delfiles(id)
{
   if(window.confirm('删除后不可恢复，你确认要删除吗？')){
   	
	   jQuery.ajax({
		  type: 'GET',
		  url: 'admin.php?ac=file&fileurl=public&do=del&id='+id+'',
		  success: function(data){
			  if(data!=''){
				  filenumber_show();
			  }
		  }
	   });
   }
}
function read(){
   mytop=(screen.availHeight-600)/2;
   myleft=(screen.availWidth-1002)/2;
   window.open("?ac=workflow&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $work['tpltype']?>&tplid=<?php echo $tplid?>&appid=<?php echo $appid?>&do=read&title=<?php echo $work['title'];?>","","height=500,width=800,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
}
function delivery(){
   mytop=(screen.availHeight-600)/2;
   myleft=(screen.availWidth-1002)/2;
   window.open("?ac=workflow&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $work['tpltype']?>&tplid=<?php echo $tplid?>&appid=<?php echo $appid?>&do=delivery","","height=500,width=800,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
}
function file_add(type){
	//alert($("#form").html());
	//alert($("#content-flow").html());
	var _filecontent=$("#form").html()+$("#content-flow").html();
	//alert(_filecontent);
	$("#filecontent").val(_filecontent);
	var $form = $('#fileadd');
	var url = '?ac=<?php echo $ac?>&do=fileadd&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>';
	$.post(url, $form.serialize(), function(data){
	if(data==1){
		alert('归档成功,数据己存储于档案管理系统中！');
	}else{
		alert('请不要重复归档！');
	}
	});
	 
}
function viewexcel(type){
   jQuery.ajax({
      type: 'GET',
      url: 'admin.php?ac=list&do=viewexcel&fileurl=apps&types='+type+'&appid=<?php echo $appid;?>&'+new Date(),
      success: function(data){
		  if(data!=''){
			  //$("#excelvalue").html(data);str.split(","); 
			  if(type=='excel'){
				  var vdata=data.split("{toa}"); 
				  window.location.href='down.php?urls='+vdata[0];
				  //window.location.href='down.php?urls='+vdata[1];
			  }else{
			  	  //alert(data);
				  window.location.href='down.php?urls='+data;
			  }
		  }
      }
   });
}
</script>
<form name="fileadd" id="fileadd" method="post" action="?ac=<?php echo $ac?>&do=fileadd&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>">
<input type="hidden" name="filetype" value="<?php echo $tpltype;?>" />
<input type="hidden" name="filenumber" value="<?php echo $work['number'];?>" />
<input type="hidden" name="filename" value="<?php echo $work['title'];?>" />
<input type="hidden" name="fileappendix" value="<?php echo $fileaddr.'apps'.DB_JT.$appid.'.doc';?>" />
<input type="hidden" name="filecontent" id="filecontent" value="" />
</form>
<form name="save" id="save" method="post" action="?ac=<?php echo $ac?>&do=add&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>">
<input type="hidden" name="_tplid" value="<?php echo $tplid;?>" />
<input type="hidden" name="appid" value="<?php echo $appid;?>" />
<input type="hidden" name="perid" value="<?php echo $flow['perid'];?>" />
<input type="hidden" name="flowid" value="<?php echo $flow['flowid'];?>" />
<input type="hidden" name="_flownum" value="<?php echo $flow['flownum'];?>" />
<div class="search_area">
        <div class="form-search form-search-top" style="text-align:left;padding-left:10px;">
                       No： <input name="number" type="text" class="BigInput" id="number" style="width: 100px;" value="<?php echo $work['number'];?>" maxlength="100" />
	名称：<input type="text" name="title" class="BigInput" style="width:300px;" size="20" value="<?php echo $work['title'];?>" />
           <button type="button" onClick="_A();" style="margin-left:30px;margin-right:15px;" class="btn btn-danger">保存</button>
		   <?php
			if($flows['flowtype']==1){
			
			?>
			<button id="do_search" type="button" onClick="read();" class="btn btn-warning">文件传阅</button>
			<?php
			}elseif($flows['flowtype']==2){
			?>
			<button id="do_search" type="button" onClick="delivery();" class="btn btn-warning">文件分发</button>
			<?php
			}elseif($flows['flowtype']==3){
			?>
			<button id="do_search" type="button" onClick="window.location.href='down.php?urls=<?php echo $fileaddr.'apps'.DB_JT.$appid.'.doc';?>';" class="btn btn-info">下载正文</button>
			<button id="do_search" type="button" onClick="viewexcel('word');" class="btn btn-info">导出表单</button>
			<button id="do_search" type="button" onClick="file_add('word');" class="btn btn-warning">电子归档</button>
			<?php }?>
		   <?php 
		   $flowkey8=explode('|',$flows['flowkey8']);
		   if($flow['countersign']!=''){
				$sqllog = "SELECT lid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log  WHERE perid='".$flow['perid']."' and uid!='".$_USER->id."' and pertype=0 and type=1";
				$per_log = $db->fetch_one_array($sqllog);
				if($per_log['lid']!=''){
					$lid=$per_log['lid'];
				}
		   }
		   //流程委托
		   if($flowkey8[1]==1 && $flow['appkey']=='2' && $flow['uid']==$_USER->id){
			   if($flow['entrust']==''){
				   echo '<button type="button" onClick="_D(1);" class="btn btn-info">委托</button>';
				   echo chr(13).chr(10);
			   }else{
				   echo '<button type="button" title="当前被委托人：'.get_realname($flow[entrust]).'" onClick="_DT('.$flow['perid'].','.$appid.');" class="btn btn-info">取消委托</button>';
				   echo chr(13).chr(10);
			   }
		  }
		  //流程挂起（只有单向审批时可以挂起）
		  if($flowkey8[2]==1 && $flow['appkey']==2 && ($flow['uid']==$_USER->id || $flow['entrust']==$_USER->id)){
			  if($flow['hang']==1){
				  echo'<button type="button" title="当前挂起结束时间：'.$flow[hangdate].'" onClick="_ET('.$flow['perid'].','.$appid.');" class="btn btn-info">取消挂起</button>';
				  echo chr(13).chr(10);
			  }else{
				  echo'<button type="button" onClick="_E(1);" class="btn btn-info">挂起</button>';
				  echo chr(13).chr(10);
			  }   
		  }
		  //会签（只有单向审批时可以会签）
		  if($flowkey8[0]==1 && $flow['appkey']==2 && ($flow['uid']==$_USER->id || $flow['entrust']==$_USER->id)){
		  	  if($flow['countersign']!=''){
				  echo '<button type="button" onClick="_F(1);" class="btn btn-info">管理会签人</button>';
			  }else{
				  echo '<button type="button" onClick="_F(1);" class="btn btn-info">增加会签人</button>';
			  }
			  echo chr(13).chr(10);
		  }
		  if($flow['hang']!=1){
		  	  if($flow['appkey']==2){
				  if($flow['entrust']!='' && $flow['entrust']==$_USER->id){
				       if($lid==''){
						   _B('personnel');
					   }
				  }elseif($flow['countersign']!='' && sizeof(explode(','.get_realname($_USER->id).',',$flow['countersign']))>1){
					  _B('countersign');
				  }elseif($flow['entrust']=='' && $flow['uid']==$_USER->id){
				  	  if($lid==''){
						  _B('personnel');
					  }
				  }
				  if($flow['entrust']!='' && $flow['entrust']==$_USER->id){
				  	  if($lid==''){
						  _BT($flows['flowkey4']);
					  }
				  }elseif($flow['entrust']=='' && $flow['uid']==$_USER->id){
				  	  if($lid==''){
						  _BT($flows['flowkey4']);
					  }
				  }
			  }else{
				  _B('appkey');
				  _BT($flows['flowkey4']);
			  } 
			  //退回流程
			  
		  }
		  ?>
			<button type="button" style="margin-left:15px;" onClick="window.location.href='admin.php?ac=list&fileurl=apps&tpltype=<?php echo $tpltype;?>'" class="btn">返回</button>
        </div>
</div>


<div style="position:absolute; left:0px;overflow:auto;height:82%;width:100%;padding-top:10px;">
<div  id='form' style="width: 1002px;margin: 10px auto; background-color:#FFFFFF;">
<?php echo $tpladdr;?>
</div>

<div id="attchment">
<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">流程附件管理</span>
			</div>
<table class="TableList small" align="center" width="100%">
		<tr class="TableLine1" style="line-height:30px;">
			<td colspan='4' align="left" style="padding-left:40px;background:#fdfaf3;" id="filetitle">还没有附件！</td>
		</tr>
<tbody id="filevalue">

</tbody>	
				</table>
<table class="TableBlock no-top-border" align="center" width="100%" height="45">
      
    <tr height="35">
	  <td nowrap class="TableContent" width="70" align="center" style="background:#fdfaf3;">
	  <input type="hidden" name="annexurlid" id="annexurlid" oninput="filenumber_show();"  onpropertychange="filenumber_show();" />
		<button type="button" onClick="window.open ('admin.php?ac=uploadadd&fileurl=public&name=annexurlid&filenumber=<?php echo $appid;?>&officetype=1', 'newwindow', 'height=200, width=480, top=0, left=0, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no')" action="cancel_concern" class="btn btn-primary">上传附件</button>    </td>
      <td class="TableData">
       

      </td>
            <td nowrap class="TableContent" width="90" align="center" >
    	 </td>
      <td class="TableData">
         
	  </td>
	       </tr>

</table>
	</div>
</div>
<div id="remark">
<div class="content-remark" id="content-remark">
			<div class="remark-block">
				<span class="remark-title">流程签批意见</span>
			</div>
			

<table class="TableBlock" width="90%" style="margin-bottom:10px">      	
    <tr class="TableData">
        <td style="padding-left:40px;">
<textarea id="content" cols="20" rows="2" class="ckeditor"  name="content"></textarea>
        </td>
    </tr>
    
    <!--<tr class="TableData">
	    <td align="left" style="padding-left:40px; height:45px;">
		  <button type="button" onClick="updateform(1);" action="cancel_concern" class="btn btn-danger">手写签名</button> <button type="button" onClick="updateform(1);" action="cancel_concern" class="btn btn-danger">电子印章</button>  
		</td>
	</tr> -->
</table>			
		</div>
	</div>



<div id="content-flow">
<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">流程办理进度</span>
			</div>

<?php
$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel 
        where appid='".$appid."'  order by perid asc";
$result = $db->fetch_all($sql);
$i=0;
foreach ($result as $rows) {
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  
	        WHERE fid = '".$rows['flowid']."'";
	$flow2 = $db->fetch_one_array($sql);
	$i++;
	echo '<table class="TableList small" align="center" width="100%"';
	if($i>1){
		echo ' style=" border-top:0px;"';
	}
	echo '>';
	echo '<tr class="TableLine1" style="line-height:30px;">';
	echo '<td colspan="4" align="left" style="padding-left:20px;background:#fdfaf3;">';
	echo '第<b style="font-size:16px;">'.$i.'</b>步:'.$flow2['flowname'].'';
	echo ' (主办：'.$rows['name'];
	if($rows['entrust']!=''){
		echo '；委办：'.get_realname($rows['entrust']);
	}
	if($rows['countersign']!=''){
		echo '；会签：'.trim($rows['countersign']);
	}
	echo ') ';
	if($rows['hang']!=''){
		echo '<font color=red>[流程被挂起]</font>';
	}elseif($rows['pertype']==3){
		echo '<font color=red>[退回]</font>';
	}else{
		if($rows['pertype']==0){
			echo '<font color=red>[流程办理中]</font>';
		}elseif($rows['pertype']==4){
			echo '<font color=red>[等待办理中]</font>';
		}
	}
	echo '</td></tr>';
	if($rows['pertype']!=0){
		//处理多人审批
		if($rows['appkey']==2){
			echo '<tr class="TableData" style="line-height:30px;">';
			echo '<td style="padding-left:20px;" align="left">'.$rows['lnstructions'].'</td>';
			echo '<td align="center" style="width:80px;">';
			echo apps_pertype($rows['pertype']).'</td>';
			echo '<td align="center" style="width:80px;">';
			if($rows['entrust']!=''){
				//echo get_realname($rows['entrust']);
				echo participationwork(get_realname($rows['entrust']),$rows['entrust']);
			}else{
				echo participationwork($rows['name'],$rows['uid']);
			}
			echo '</td>';
			echo '<td align="center" style="width:120px;">';
			echo $rows['approvaldate'].'</td></tr>';
			if($rows['countersign']!=''){
				$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
									 where perid='".$rows['perid']."' and type=1
									  ORDER BY lid Asc");
				while ($log = $db->fetch_array($query)) {
					echo '<tr class="TableData" style="line-height:30px;">';
					echo '<td style="padding-left:20px;" align="left">';
					echo $log['lnstructions'].'</td>';
					echo '<td align="center" style="width:80px;">';
					echo apps_pertype_log($log['pertype']).'</td>';
					echo '<td align="center" style="width:80px;">'.participationwork($log['name'],$log['uid']).'</td>';
					echo '<td align="center" style="width:120px;">';
					echo $log['approvaldate'].'</td></tr>';
				}
			}
		}else{
			$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
			                     where perid='".$rows['perid']."' ORDER BY lid Asc");
			while ($log = $db->fetch_array($query)) {
				echo '<tr class="TableData" style="line-height:30px;">';
				echo '<td style="padding-left:20px;" align="left">';
				echo $log['lnstructions'].'</td>';
				echo '<td align="center" style="width:80px;">';
				echo apps_pertype_log($log['pertype']).'</td>';
				echo '<td align="center" style="width:80px;">'.participationwork($log['name'],$log['uid']).'</td>';
				echo '<td align="center" style="width:120px;">';
				echo $log['approvaldate'].'</td></tr>';
			}
		}
	}
	echo '</table>';
}
?>					

	</div>
</div>







</div>




</form>


<div id="MsgShow" style="height:200px;min-width:500px !important;" class="modal hide fade">
		<div class="modal-header">
			<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
			<h4>消息提示</h4>
		</div>
		<div class="modal-body" id="MsgShowContent" style="font-size:22px; text-align:center; line-height:60px;color:#009933;"></div>
</div>

<div id="_D" style="height:345px;min-width:600px !important;" class="modal hide fade">
	<div class="modal-header" style="text-align:left;">
		<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
	<h4>流程委托</h4>
	</div>
	<div class="modal-body" style="overflow: visible !important;position: relative !important; height:195px; text-align:left;">
		<div class="alert alert-success" id="d_msg"></div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">将流程为</label>
			<div class="controls" style="font-size:18px; color:#009900;">
				<?php echo $work['title'];?>	
			</div>
		</div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">委托给</label>
			<div class="controls">
				<?php echo get_pubuser(1,"entrust",'',"+选择人员",120,20);?>	
			</div>
		</div>
	</div>
	<div class="modal-footer" style="text-align:right">
		<button onClick="_D(2);" class="btn btn-primary" type="button">确 定</button>
		<button data-dismiss="modal" class="btn" style="margin-left:20px;" type="button">取消</button>
	</div>
</div>
<div id="_E" style="height:295px;min-width:600px !important;" class="modal hide fade">
	<div class="modal-header" style="text-align:left;">
		<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
	<h4>流程挂起</h4>
	</div>
	<div class="modal-body" style="overflow: visible !important;position: relative !important; height:145px; text-align:left;">
		<div class="alert alert-success" id="e_msg"></div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">流程名称：</label>
			<div class="controls" style="font-size:18px; color:#009900;">
				<?php echo $work['title'];?>	
			</div>
		</div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">挂起结束时间：</label>
			<div class="controls">
				<?php 
				echo '<input name="hangdate" size="16" type="text" value="" ';
				echo 'readonly onFocus="';
				echo "WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})";
				echo '" class="span3" >';
				?>	
			</div>
		</div>
	</div>
	<div class="modal-footer" style="text-align:right">
		<button onClick="_E(2);" class="btn btn-primary" type="button">确 定</button>
		<button data-dismiss="modal" class="btn" style="margin-left:20px;" type="button">取消</button>
	</div>
</div>
<div id="_F" style="height:445px;min-width:600px !important;" class="modal hide fade">
	<div class="modal-header" style="text-align:left;">
		<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
	<h4>增加会签人员</h4>
	</div>
	<div class="modal-body" style="overflow: visible !important;position: relative !important; height:295px; text-align:left;">
		<div class="alert alert-success" id="f_msg"></div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">会签人员：</label>
			<div class="controls" style="font-size:18px; color:#009900;">
				<?php echo get_pubuser(2,"countersign",'',"+选择人员",200,3);?>	
			</div>
		</div>
		<div class="control-group ">
			<label class="control-label required" for="AttachmentItem_file_name">己有会签人员：</label>
			<div class="controls">
				<div class="table-responsive" style="position:absolute; height:160px;overflow:auto;">
				   <table class="table">
					  <tbody>
					  <?php
					  
					  $ctnsql="SELECT uid,name,lnstructions,pertype FROM ".DB_TABLEPRE.DB_JT."app_personnel_log where perid='".$flow['perid']."' and appid='".$appid."' and type='1' ORDER BY lid Asc";
					  $querys = $db->query($ctnsql);
					  while ($ctn = $db->fetch_array($querys)) {
					  ?>
						 <tr>
							<td><?php echo $ctn['name'];?></td>
							<td>[<?php echo apps_pertype_log($ctn['pertype'])?>]<?php echo $ctn['lnstructions'];?></td>
						 </tr>
					   <?php }?>  
					  </tbody>
				   </table>
				</div>  	
			</div>
		</div>
	</div>
	<div class="modal-footer" style="text-align:right">
		<button onClick="_F(2);" class="btn btn-primary" type="button">确 定</button>
		<button data-dismiss="modal" class="btn" style="margin-left:20px;" type="button">取消</button>
	</div>
</div>
<script type="text/javascript" src="<?php echo style2015;?>content/js/appsflow.js"></script>
</body>
</html>
