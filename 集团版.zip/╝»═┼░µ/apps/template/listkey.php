<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
		<title>Office 515158.com OA办公系统</title>
        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap.min.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap-modal.css" />
		        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/bootstrap.css"> 
				<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>bootstrap/css/bootstrap-datetimepicker.css"> 
        <link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/base.css">
		<link rel="stylesheet" type="text/css" href="<?php echo style2015;?>content/css/style.css">
		<script type="text/javascript" src="<?php echo style2015;?>content/js/jquery.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modal.js"></script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/bootstrap-modalmanager.js"></script>
		<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
   </head>
	<body >
	<div class="tabbable work-nav"> <!-- Only required for left/right tabs -->
				<ul id="myTab" class="nav nav-tabs">
					<li <?php if($type==''){?>class="active"<?php }?>>
						<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&tplid=<?php echo $tplid;?>&do=listkey">待办公文</a>
					</li>
					<li <?php if($type==2){?>class="active"<?php }?>>
						<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&type=2&tplid=<?php echo $tplid;?>&do=listkey">办结公文</a>
					</li>
					<li <?php if($type==4){?>class="active"<?php }?>>
						<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&type=4&tplid=<?php echo $tplid;?>&do=listkey">挂起公文</a>
					</li>
					<li <?php if($type==5){?>class="active"<?php }?>>
					<a href="admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&type=5&tplid=<?php echo $tplid;?>&do=listkey">委办公文</a>
					</li>
				</ul>
			</div>
<div class="search_area">
    
			
	<form method="get" action="admin.php" name="save">
	<input type="hidden" name="ac" value="<?php echo $ac?>" />
		<input type="hidden" name="do" value="listkey" />
		<input type="hidden" name="fileurl" value="<?php echo $fileurl?>" />
		<input type="hidden" name="tpltype" value="<?php echo $tpltype?>" />
        <div class="form-search form-search-top" style="text-align:left;padding-left:100px;">
		<?php echo get_keyuser($ui,$un);?>
 <div class="adv-select-label">No.：</div>
<input type="text"  name="number" style="width:100px;" size="20" class="span3" value="<?php echo urldecode($number)?>">  
<div class="adv-select-label">名称：</div>
<input type="text"  name="title" style="width:200px;" size="20" class="span3" value="<?php echo urldecode($title)?>"> 
<div class="adv-select-label">起止日期：</div>
<input type="text" value="<?php echo $vstartdate?>"  style="width:80px;" readonly="readonly"  onClick="WdatePicker();" name='vstartdate' > - <input type="text" value="<?php echo $venddate?>"  style="width:80px;" readonly="readonly"  onClick="WdatePicker();" name='venddate' >
            
           
            <button id="do_search" type="button" onClick="sendForm();" class="btn btn-primary">查 询</button>
       
        </div>
       
    </form>
</div>


	
	
		
	<div class="content" >
		<div style="padding-top:5px;">
			
			
			<div id="folder-grid" class="grid-view">

				<div style="float:right; text-align:right; margin-right:20px;">
							<?php echo newshowpage($num,$pagesize,$page,$url);?>
						</div>
				<table class="items table table-striped" style="margin-bottom:0px;">
					<thead>
						<tr>
							<th style="width:10px" id="folder-grid_c0">
							<input type="checkbox" value="1"  onClick="check_all(this);" class="icon-checkbox-unchecked" /> 
							</th>
							<th style="width: 130px;" >No.</th>
							<th style="width:100%;">名称</th>
							<th style="width: 90px;">发起人</th>
							<th style="width: 100px;">发起时间</th>
							<th style="width: 160px;">办理步骤</th>
				
							<th style="width: 130px;text-align:center;">操作</th>
						</tr>
					</thead>
					</table>
					<div style="position:absolute; height:64%; width:100%;overflow:auto; ">
					<table class="items table table-striped" style="margin-top:0px;">
				    <tbody>
					<?php
					foreach ($result as $row) {
					$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE appid = '".$row['id']."'  and (pertype=0 or pertype=2 or pertype=4 or pertype=5)  order by perid desc";
					$per = $db->fetch_one_array($sql);
					?>
						<tr class="odd">
						<td class="notopen" style="width:10px">
						<?php
						if(!is_superadmin()){
							if($type==3){
								if($per['pertype']==0 || $per['pertype']==2 || $row['type']==1){
									echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox" />';
								}else{
									echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox" disabled="disabled" />';
								}
							}elseif($type==''){
								if($row['uid']==$_USER->id && ($per['pertype']==0 || $per['pertype']==2 || $row['type']==1)){
									echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox" />';
								}else{
									echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox" disabled="disabled" />';
								}
							}else{
								echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox"  disabled="disabled"/>';
							}
						}else{
							echo '<input type="checkbox" name="ids[]" value="'.$row['id'].'" class="checkbox" />';
						}
						?>
						</td>
						<td class="ellipsis" style="width:130px;">
						<?php echo $row['number']?>
						</td>
						
						<td style="width:100%;">
						<a href="admin.php?ac=<?php echo $ac?>&do=view&fileurl=<?php echo $fileurl?>&appid=<?php echo $row['id']?>&tpltype=<?php echo $tpltype?>"><?php echo $row['title']?></a></td>
						<td style="width:90px;"><?php echo get_realname($row['uid'])?></td>
						<td style="width:100px;"><?php echo str_replace(' ','<br>',$row['date']);?></td>
						<td style="width:160px;">
						<?php
						  if($per['pertype']==5){
							  echo '<font color=red>流程结束</font>';
						  }elseif($per['pertype']==2){
							  echo '<font color=red>流程被拒绝</font>';
						  }else{
							  $sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '".$per['flowid']."' order by fid desc";
							  $flow = $db->fetch_one_array($sql);
							  if($flow['flownum']!=''){
								  echo '<b>第<span style="font-size:18px; font-weight:bold; color:#FF0000;">'.$flow['flownum'].'</span>步：'.$flow['flowname'].'</b><br>';
								  echo '主办人：'.$per['name'];
							  }
						  }
						  ?>
						</td>
						
						<td style="width: 120px; text-align:center; vertical-align:middle;"  class="notopen">
						<?php 
						if($row['type']==1){
							echo '流程被撤消';
							echo '<br>';
						}else{
							if($type=='' || $type==1){
								$userurl=0;
								$perlnum = $db->result("SELECT COUNT(*) AS perlnum FROM ".DB_TABLEPRE.DB_JT."app_personnel where perid='".$per['perid']."' and usernum like '%".get_realname($_USER->id)."%' and (pertype=0 or pertype=4)");
								if($perlnum>0){
									echo '<a style="cursor:pointer;';
									echo ' margin-top:3px;color:#FF0000;" href="';
									echo 'admin.php?ac=add&fileurl='.$fileurl.'&appid='.$row['id'];
									echo '&tplid='.$row['tplid'];
									echo '&perid='.$per['perid'].'&flowid='.$per['flowid'];
									echo '&tpltype='.$row['tpltype'].'">办理</a>';
									echo chr(13).chr(10);
									$userurl++;
								}
							}
						}
						?>
						
						<a href="javascript:;" onClick="ListWrokFlow(<?php echo $row['id']?>,<?php echo $row['tplid']?>);" style=" margin-top:3px;">记录</a>
						<a style=" margin-top:3px;" href="admin.php?ac=<?php echo $ac?>&do=view&fileurl=<?php echo $fileurl?>&appid=<?php echo $row['id']?>&tpltype=<?php echo $row['tpltype']?>">查看</a>
						</td>
						</tr>
						<?php }?>
						
					</tbody>
					
				</table>
			</div>
				
			</div>
		</div>
	</div>
			<script>
				$(document).ready(function() {
					initRight();
				});
				initRight = function() {
					
				}
				function sendForm(){
				   document.save.submit();
				}
				function Listworkkey(id) {
					if(window.confirm('确定要撤消流程吗？撤消后将不可还原！')){
						jQuery.ajax({
							type: 'GET',
							url: 'admin.php?ac=<?php echo $ac;?>&do=workkey&fileurl=<?php echo $fileurl;?>&appid='+id+'&tpltype=<?php echo $tpltype;?>&tplid=<?php echo $tplid;?>',
							success: function(data){
								if(data!=''){
									location.reload(true);
								}
							}
						});
					}
				}
				function ListWrokFlow(appid,tplid){
					window.open ('admin.php?ac=list&fileurl=apps&do=flow&appid='+appid+'&tpltype=<?php echo $tpltype;?>&tplid='+tplid+'&webdata=<?php echo get_date('YmdHis',PHP_TIME);?>', 'newwindow'+appid, 'height=550, width=550, top=6, right=0, toolbar=no, menubar=no, scrollbars=yes, resizable=no,location=no, status=no')
				}
				function ListWorkSms(type,appid,perid){
					if(type==1){
						_DIV("#_SMS");
						$("#sms_msg").hide();
						jQuery.ajax({
							type: 'GET',
							url: 'admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&do=worksms&perid='+perid+'&appid='+appid+'&webdata=<?php echo get_date('YmdHis',PHP_TIME);?>',
							success: function(data){
								if(data!=''){
									//alert(data);
									$('#listworksms').html(data);
								}
							}
						});
					}else{
						var urladd='admin.php?ac=<?php echo $ac;?>&fileurl=<?php echo $fileurl;?>&do=worksms&view=starte';
						urladd+="&user="+escape($('textarea[name="user"]').val());
						urladd+='&box_content_user='+escape($("#box_content_user").val())+'&sms_box_user='+checked_view("sms_box_user")+'&sms_phone_user='+checked_view("sms_phone_user")+'&date='+new Date();
					jQuery.ajax({
							type: 'GET',
							url: urladd,
							success: function(data){
								if(data!=''){
									//alert(data);
									$('#_SMS').modal("hide");
								}
							}
						});	
					}
				}
			</script>
		<script type="text/javascript" src="<?php echo style2015;?>content/js/appsflow.js"></script>
	<div  id="MsgShow" style="height:200px;min-width:500px !important;" class="modal hide fade">
		<div class="modal-header">
			<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
			<h4>消息提示</h4>
		</div>
		<div class="modal-body" id="MsgShowContent" style="font-size:22px; text-align:center; line-height:60px;color:#009933;"></div>
	</div>
	<div id="_SMS" style="height:345px;min-width:600px !important;" class="modal hide fade">
	<div class="modal-header" style="text-align:left;">
		<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
	<h4>流程催办</h4>
	</div>
	<div class="modal-body" style="overflow: visible !important;position: relative !important; height:195px; text-align:left;">
		<div class="alert alert-success" id="sms_msg"></div>
		<div id="listworksms"></div>
	</div>
	<div class="modal-footer" style="text-align:right">
		<button onClick="ListWorkSms(2);" class="btn btn-primary" type="button">确 定</button>
		<button data-dismiss="modal" class="btn" style="margin-left:20px;" type="button">取消</button>
	</div>
</div>
	
	<form name="excel" method="post" action="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">
		<input type="hidden" name="title" value="<?php echo $title?>" />
		<input type="hidden" name="number" value="<?php echo $number?>" />
		<input type="hidden" name="tpltype" value="<?php echo $tpltype?>" />
		<input type="hidden" name="tplid" value="<?php echo $tplid?>" />
		<input type="hidden" name="vstartdate" value="<?php echo $vstartdate?>" />
		<input type="hidden" name="venddate" value="<?php echo $venddate?>" />
		<input type="hidden" name="un" value="<?php echo $un?>" />
		<input type="hidden" name="ui" value="<?php echo $ui?>" />
		<input type="hidden" name="do" value="excel" />
	</form>
	</body>
</html>