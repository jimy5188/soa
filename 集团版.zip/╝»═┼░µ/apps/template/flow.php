<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="template/default/js/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="template/default/content/js/common.js"></script>
<title>Office 515158 2011 OA办公系统</title>
</head>
<body class="bodycolor">
<table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td class="Big" style="font-size:12px;"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">公文办理进度</span>
    </td>
  </tr>
</table>

<?php
//$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."workclass_personnel 
//        where workid='".$workid."'  order by perid asc";
//$result = $db->fetch_all($sql);
$i=0;
foreach ($result as $rows) {
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  
	        WHERE fid = '".$rows['flowid']."'";
	$flow = $db->fetch_one_array($sql);
	$i++;
	echo '<table class="TableBlock" border="0" width="95%" align="center" style="margin-bottom:20px;"';
	if($i>1){
		echo ' style=" border-top:0px;"';
	}
	echo '>';
	echo '<tr class="TableLine1" style="line-height:30px;">';
	echo '<td colspan="4" align="left" style="padding-left:20px;background:#fdfaf3;">';
	echo '第<b style="font-size:16px;">'.$i.'</b>步:'.$flow['flowname'].'';
	echo ' (主办：'.$rows['name'];
	if($rows['entrust']!=''){
		echo '；委办：'.get_realname($rows['entrust']);
	}
	if($rows['countersign']!=''){
		echo '；会签：'.trim($rows['countersign']);
	}
	echo ') ';
	if($rows['hang']!=''){
		echo '<font color=red>[流程被挂起]</font>';
	}elseif($rows['pertype']==3){
		echo '<font color=red>[退回]</font>';
	}else{
		if($rows['pertype']==0){
			echo '<font color=red>[流程办理中]</font>';
		}elseif($rows['pertype']==4){
			echo '<font color=red>[等待办理中]</font>';
		}
	}
	echo '</td></tr>';
	if($rows['pertype']!=0){
		//处理多人审批
		if($rows['appkey']==2){
			echo '<tr class="TableData" style="line-height:30px;">';
			echo '<td style="padding-left:20px;" align="left">'.$rows['lnstructions'].'</td>';
			echo '<td align="center" style="width:80px;">';
			echo apps_pertype($rows['pertype']).'</td>';
			echo '<td align="center" style="width:80px;">';
			if($rows['entrust']!=''){
				//echo get_realname($rows['entrust']);
				echo participationwork(get_realname($rows['entrust']),$rows['entrust']);
			}else{
				echo participationwork($rows['name'],$rows['uid']);
			}
			echo '</td>';
			echo '<td align="center" style="width:120px;">';
			echo $rows['approvaldate'].'</td></tr>';
			if($rows['countersign']!=''){
				$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
									 where perid='".$rows['perid']."' and type=1
									  ORDER BY lid Asc");
				while ($log = $db->fetch_array($query)) {
					echo '<tr class="TableData" style="line-height:30px;">';
					echo '<td style="padding-left:20px;" align="left">';
					echo $log['lnstructions'].'</td>';
					echo '<td align="center" style="width:80px;">';
					echo apps_pertype_log($log['pertype']).'</td>';
					echo '<td align="center" style="width:80px;">'.participationwork($log['name'],$log['uid']).'</td>';
					echo '<td align="center" style="width:120px;">';
					echo $log['approvaldate'].'</td></tr>';
				}
			}
		}else{
			$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
			                     where perid='".$rows['perid']."' ORDER BY lid Asc");
			while ($log = $db->fetch_array($query)) {
				echo '<tr class="TableData" style="line-height:30px;">';
				echo '<td style="padding-left:20px;" align="left">';
				echo $log['lnstructions'].'</td>';
				echo '<td align="center" style="width:80px;">';
				echo apps_pertype_log($log['pertype']).'</td>';
				echo '<td align="center" style="width:80px;">'.participationwork($log['name'],$log['uid']).'</td>';
				echo '<td align="center" style="width:120px;">';
				echo $log['approvaldate'].'</td></tr>';
			}
		}
	}
	echo '</table>';
}
?>	

</body>
</html>
