<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<title>Office 515158 2011 OA办公系统</title>
<script type="text/javascript">
function CheckForm(){
   if(document.save.read.value==""){ 
     alert("阅读人员不能为空！");
     document.save.read.focus();
     return (false);
   }
   return true;
}
function sendForm(){
   if(CheckForm()){
      document.save.submit();
   }
}
function refreshParentss(){
   window.close();  
}
</script>
</head>
<body>
<div class="search_area">
        <table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<?php echo $title;?>
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<button type="button" onClick="sendForm();" action="cancel_concern" class="btn btn-danger">确认传阅</button>
 <button id="do_search" type="button" onClick="refreshParentss();" class="btn btn-primary">关闭</button>
	</td>
  </tr>
</table>
</div>
<form name="save" method="post" action="admin.php?ac=workflow&do=read&fileurl=<?php echo $fileurl?>">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="tpltype" value="<?php echo $tpltype;?>" />
	<input type="hidden" name="tplid" value="<?php echo $tplid;?>" />
	<input type="hidden" name="appid" value="<?php echo $appid;?>" />
<div class="content-remark" id="content-remark" style="width:700px;">
			<div class="remark-block">
				<span class="remark-title">选择文件传阅人员</span>
			</div>
			

<table class="TableBlock"  style="margin-bottom:10px">      	
    <tr class="TableData">
        <td style="padding-left:40px;">
	<?php get_pubuser(2,"read",'',"+选择阅读人员","300' style='width:600px;",8);?> 
	<br><?php get_smsbox("阅读人员","read");?>
	</td>
    </tr>
</table>			
	  </div>
</form>
</body>
</html>
