<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->

 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript">
	function active(type){
		if(type!=''){
			document.getElementById('from').className = '';
			document.getElementById('attchment').className = '';
			document.getElementById('flow').className = '';
			document.getElementById(type).className = 'active'; 
		}
	}
filenumber_show();
function filenumber_show()
{
   jQuery.ajax({
      type: 'GET',
      url: 'admin.php?ac=file&fileurl=public&do=newfile&filenumber=<?php echo $work['id'];?>&officetype=1&view=1&'+new Date(),
      success: function(data){
		  if(data!=''){
			  $("#filevalue").html(data);
			  $("#filetitle").html('附件列表');
		  }
      }
   });
}

function notk_word(){
   mytop=(screen.availHeight-600)/2;
   myleft=(screen.availWidth-1002)/2;
   window.open("ntko/views.php?fileType=word&FileId=<?php echo $file['fileid'];?>&filenumber=<?php echo 'apps'.DB_JT.$appid;?>&officetype=1&uid=<?php echo $_USER->id?>&Fileurl=<?php echo $fileaddr;?>&openurl=<?php echo $openaddr;?>&tpladdr=<?php echo 'apps'.DB_JT.$appid;?>.doc&title=<?php echo $work['title'];?>&date=<?php echo get_date('Y-m-d H:i:s',PHP_TIME)?>","","height=600,width=1002,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
}
function ckeditor(){
	var val = CKEDITOR.instances.content.getData();
	if (val.length == 0){
		alert("阅读意见不能为空！");
		document.save.content.focus();
		return (false);
	}else{
		return true;
	}
}
function sendForm(){
   if(ckeditor()){
      document.save.submit();
   }
}
</script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li class="active" id="from"><a href="#form" onClick="active('from');">表单</a></li>
					<li><a href="javascript:;"  onClick="notk_word();">正文版式</a></li>
					<li id="attchment"><a href="#content-attchment" onClick="active('attchment');">附件</a></li>
					<li id="flow"><a href="#content-flow"  onClick="active('flow');">流程记录</a></li>
					
				</ul>
				
			</div>


<div class="search_area" style="height:30px;">
        <div class="form-search form-search-top" style="text-align:left;padding-left:10px;">
     <span style="font-size:16px;color: #68584e; margin-top:20px;"> No： <?php echo $work['number'];?>
	流程名称：<?php echo $work['title'];?>
	</span>
	<span style="float:right; padding-right:120px;">
           <?php if($work['content']==''){?><button type="button" onClick="sendForm();" action="cancel_concern" class="btn btn-danger">保存意见</button><?php }?>
			</span>
        </div>
		
		
</div>


<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;" >
<?php if($work['content']==''){?>

<form name="save" id="save" method="post" action="admin.php?ac=<?php echo $ac;?>&do=viewsave&fileurl=<?php echo $fileurl;?>&appid=<?php echo $work['id'];?>&tpltype=<?php echo $work['tpltype'];?>&tplid=<?php echo $work['tplid'];?>&rid=<?php echo getGP('rid','G','int');?>">

<div class="content-remark" id="content-remark">
			<div class="remark-block">
				<span class="remark-title">公文阅读意见</span>
			</div>
			

<table class="TableBlock" width="90%" style="margin-bottom:10px">      	
    <tr class="TableData">
        <td style="padding-left:40px;">
<textarea id="content" cols="20" rows="2" class="ckeditor"  name="content"></textarea>
        </td>
    </tr>
</table>			
	  </div>

</form>
<?php }else{?>
<div class="content-remark" id="content-remark">
			<div class="remark-block">
				<span class="remark-title">我发表的意见</span>
			</div>
			

<table class="TableBlock" width="90%" style="margin-bottom:10px">      	
    <tr class="TableData">
        <td align="left" style="padding-left:40px;">
<?php echo $work['content'];?>        </td>
    </tr>
</table>			
	  </div>
<?php }?>
<div  id='form'>
<table border="0" align="center" cellpadding="0" cellspacing="0" style="background-color:#FFFFFF; width:1000px;">
  <tr>
    <td style="padding-bottom:10px;"><?php echo $tpladdr;?></td>
  </tr>
</table>
</div>



<div id="attchment">
<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">流程附件管理</span>
			</div>


<table class="TableList small" align="center" width="100%">
		<tr class="TableLine1" style="line-height:30px;">
			<td colspan='4' align="left" style="padding-left:40px;background:#fdfaf3;" id="filetitle">还没有附件！</td>
		</tr>
<tbody id="filevalue">

</tbody>	
				</table>

	</div>
</div>

<div id="content-flow">
<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">流程办理进度</span>
			</div>

<?php
$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel 
        where appid='".$appid."'  order by perid asc";
$result = $db->fetch_all($sql);
$i=0;
foreach ($result as $rows) {
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  
	        WHERE fid = '".$rows['flowid']."'";
	$flow2 = $db->fetch_one_array($sql);
	$i++;
	echo '<table class="TableList small" align="center" width="100%"';
	if($i>1){
		echo ' style=" border-top:0px;"';
	}
	echo '>';
	echo '<tr class="TableLine1" style="line-height:30px;">';
	echo '<td colspan="4" align="left" style="padding-left:20px;background:#fdfaf3;">';
	echo '第<b style="font-size:16px;">'.$i.'</b>步:'.$flow2['flowname'].'';
	echo ' (主办：'.$rows['name'];
	if($rows['entrust']!=''){
		echo '；委办：'.get_realname($rows['entrust']);
	}
	if($rows['countersign']!=''){
		echo '；会签：'.trim($rows['countersign']);
	}
	echo ') ';
	if($rows['hang']!=''){
		echo '<font color=red>[流程被挂起]</font>';
	}elseif($rows['pertype']==3){
		echo '<font color=red>[退回]</font>';
	}else{
		if($rows['pertype']==0){
			echo '<font color=red>[流程办理中]</font>';
		}elseif($rows['pertype']==4){
			echo '<font color=red>[等待办理中]</font>';
		}
	}
	echo '</td></tr>';
	if($rows['pertype']!=0){
		//处理多人审批
		if($rows['appkey']==2){
			echo '<tr class="TableData" style="line-height:30px;">';
			echo '<td style="padding-left:20px;" align="left">'.$rows['lnstructions'].'</td>';
			echo '<td align="center" style="width:80px;">';
			echo apps_pertype($rows['pertype']).'</td>';
			echo '<td align="center" style="width:80px;">';
			if($rows['entrust']!=''){
				echo get_realname($rows['entrust']);
			}else{
				echo $rows['name'];
			}
			echo '</td>';
			echo '<td align="center" style="width:120px;">';
			echo $rows['approvaldate'].'</td></tr>';
			if($rows['countersign']!=''){
				$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
									 where perid='".$rows['perid']."' and type=1
									  ORDER BY lid Asc");
				while ($log = $db->fetch_array($query)) {
					echo '<tr class="TableData" style="line-height:30px;">';
					echo '<td style="padding-left:20px;" align="left">';
					echo $log['lnstructions'].'</td>';
					echo '<td align="center" style="width:80px;">';
					echo apps_pertype_log($log['pertype']).'</td>';
					echo '<td align="center" style="width:80px;">'.$log['name'].'</td>';
					echo '<td align="center" style="width:120px;">';
					echo $log['approvaldate'].'</td></tr>';
				}
			}
		}else{
			$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_personnel_log
			                     where perid='".$rows['perid']."' ORDER BY lid Asc");
			while ($log = $db->fetch_array($query)) {
				echo '<tr class="TableData" style="line-height:30px;">';
				echo '<td style="padding-left:20px;" align="left">';
				echo $log['lnstructions'].'</td>';
				echo '<td align="center" style="width:80px;">';
				echo apps_pertype_log($log['pertype']).'</td>';
				echo '<td align="center" style="width:80px;">'.$log['name'].'</td>';
				echo '<td align="center" style="width:120px;">';
				echo $log['approvaldate'].'</td></tr>';
			}
		}
	}
	echo '</table>';
}
?>					

	</div>
</div>


</div>



</body>
</html>
