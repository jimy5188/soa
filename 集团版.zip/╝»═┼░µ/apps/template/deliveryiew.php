<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->

 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2015.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
<script type="text/javascript">
function notk_word(){
   mytop=(screen.availHeight-600)/2;
   myleft=(screen.availWidth-1002)/2;
   window.open("ntko/fileviews.php?fileType=word&fileaddr=<?php echo $row['content'];?>&title=<?php echo $row['title'];?>","","height=600,width=1002,status=0,toolbar=no,menubar=no,location=no,scrollbars=yes,top="+mytop+",left="+myleft+",resizable=yes");
}
</script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="javascript:;"  onClick="notk_word();">正文查看</a></li>
					<li class="active"><a href="#content-attchment" onClick="active('attchment');">附件</a></li>
					
				</ul>
				
			</div>


<div class="search_area" style="height:30px;">
        <div class="form-search form-search-top" style="text-align:left;padding-left:10px;">
     <span style="font-size:16px;color: #68584e; margin-top:20px;"> 公文名称： <?php echo $row['title'];?>
	发文单位：<?php echo get_realdepaname($row['dstart']);?>
	</span>
	<span style="float:right; padding-right:120px;">
           <button type="button" onClick="window.location.href='down.php?urls=<?php echo $row['content'];?>';" action="cancel_concern" class="btn btn-danger">下载正文</button>
			</span>
        </div>
		
		
</div>


<div id="attchment">
<div class="content-attchment" id="content-attchment">
			<div class="attchment-title-block">
				<span class="attchment-public">附件管理</span>
			</div>


<table class="TableList small" align="center" width="100%">

<tbody>
<?php
	$appendix=explode('{toa}',$row['appendix']); 
	$filename=explode('[toa]',$appendix[0]);
	$fileaddr=explode('[toa]',$appendix[1]);
	for($i=0;$i<sizeof($filename);$i++){
		if($filename[$i]!=''){
			$extention=preg_replace('/.*\.(.*[^\.].*)*/iU','\\1',$filename[$i]);
			echo '<tr class="TableData" style="line-height:30px;">';
			echo '<td style="padding-left:35px;" align="left">';
			echo '<span class="attach_link attach_link_block" style="white-space: inherit;">';
			if(strtolower($extention)=='doc' || strtolower($extention)=='docx'){
				echo '<img src="template/default/images/doc.gif" align="absmiddle"> ';
				$add='<a href="ntko/fileviews.php?fileType=word&fileaddr='.$fileaddr[$i].'&title='.$filename[$i].'" target="_blank">打开</a> ';
			}elseif(strtolower($extention)=='xls' || strtolower($extention)=='xlsx'){
				echo '<img src="template/default/images/xls.gif" align="absmiddle"> ';
				$add='<a href="ntko/fileviews.php?fileType=excel&fileaddr='.$fileaddr[$i].'&title='.$filename[$i].'" target="_blank">打开</a> ';
			}elseif(strtolower($extention)=='ppt'){
				echo '<img src="template/default/images/ppt.gif" align="absmiddle"> ';
				$add='<a href="ntko/fileviews.php?fileType=ppt&fileaddr='.$fileaddr[$i].'&title='.$filename[$i].'" target="_blank">打开</a> ';
			}elseif(strtolower($extention)=='pdf' || strtolower($extention)=='tif'){
				echo '<img src="template/default/images/pdf.gif" align="absmiddle"> ';
				$add='<a href="ntko/fileviews.php?fileType=pdf&fileaddr='.$fileaddr[$i].'&title='.$filename[$i].'" target="_blank">打开</a> ';
			}elseif($extention=='jpg' || $extention=='gif' || $extention=='png' || $extention=='bmp'){
				echo '<img src="template/default/images/thumb.gif" align="absmiddle"> ';
				$add='<a href="ntko/pic.php?fileaddr='.$fileaddr[$i].'&title='.$filename[$i].'" target="_blank">查看</a> ';
			}else{
				echo '<img src="template/default/images/page.gif" align="absmiddle"> ';
				$add='';
			}
			echo '<a class="attach_name" href="down.php?urls='.$fileaddr[$i].'">'.$filename[$i].'</a>';
			echo '</span>';
			echo '<div class="attach_div"><a href="down.php?urls='.$fileaddr[$i].'">下载</a> ';
			//echo '<a href="javascript:;" data-group="4dad7796">播放</a> ';
			echo $add;
			//echo '<a href="javascript:;" onClick="#">转存</a> ';
			echo '</div></td>';
			echo '<td align="center">'.sprintf("%.2f", (filesize($fileaddr[$i])*0.001)).'KB</td>';
			echo '</tr>';
		}
	}
?>
</tbody>	
				</table>

	</div>
</div>


</body>
</html>
