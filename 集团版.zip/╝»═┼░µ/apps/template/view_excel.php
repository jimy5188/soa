<?php
$html='
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">

<head>
<meta http-equiv=Content-Type content="text/html; charset=utf-8">
<meta name=ProgId content=Excel.Sheet>
<meta name=Generator content="Microsoft Excel 11">
<!--[if gte mso 9]><xml>
 <o:DocumentProperties>
  <o:Created>1996-12-17T01:32:42Z</o:Created>
  <o:LastSaved>2015-01-27T05:47:18Z</o:LastSaved>
  <o:Version>11.5606</o:Version>
 </o:DocumentProperties>
 <o:OfficeDocumentSettings>
  <o:RemovePersonalInformation/>
 </o:OfficeDocumentSettings>
</xml><![endif]-->
<style>
<!--table
	{mso-displayed-decimal-separator:"\.";
	mso-displayed-thousand-separator:"\,";}
@page
	{margin:1.0in .75in 1.0in .75in;
	mso-header-margin:.5in;
	mso-footer-margin:.5in;}
tr
	{mso-height-source:auto;
	mso-ruby-visibility:none;}
col
	{mso-width-source:auto;
	mso-ruby-visibility:none;}
br
	{mso-data-placement:same-cell;}
.style0
	{mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	white-space:nowrap;
	mso-rotate:0;
	mso-background-source:auto;
	mso-pattern:auto;
	color:windowtext;
	font-size:12.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:宋体;
	mso-generic-font-family:auto;
	mso-font-charset:134;
	border:none;
	mso-protection:locked visible;
	mso-style-name:常规;
	mso-style-id:0;}
td
	{mso-style-parent:style0;
	padding-top:1px;
	padding-right:1px;
	padding-left:1px;
	mso-ignore:padding;
	color:windowtext;
	font-size:12.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:宋体;
	mso-generic-font-family:auto;
	mso-font-charset:134;
	mso-number-format:General;
	text-align:general;
	vertical-align:bottom;
	border:none;
	mso-background-source:auto;
	mso-pattern:auto;
	mso-protection:locked visible;
	white-space:nowrap;
	mso-rotate:0;}
.xl24
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:center;
	vertical-align:middle;
	border:.5pt solid windowtext;
	white-space:normal;}
.xl25
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;
	padding-left:54px;
	mso-char-indent-count:2;}
.xl26
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;
	padding-left:54px;
	mso-char-indent-count:2;}
.xl27
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;
	padding-left:54px;
	mso-char-indent-count:2;}
.xl28
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border:.5pt solid windowtext;
	white-space:normal;}
.xl29
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:.5pt solid windowtext;
	white-space:normal;}
.xl30
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:none;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl31
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	border-top:.5pt solid windowtext;
	border-right:.5pt solid windowtext;
	border-bottom:.5pt solid windowtext;
	border-left:none;
	white-space:normal;}
.xl32
	{mso-style-parent:style0;
	font-size:20.0pt;
	font-weight:700;
	text-align:center;
	vertical-align:middle;
	white-space:normal;}
.xl33
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:left;
	vertical-align:middle;
	white-space:normal;
	padding-left:54px;
	mso-char-indent-count:2;}
.xl34
	{mso-style-parent:style0;
	font-size:14.0pt;
	text-align:right;
	vertical-align:middle;
	white-space:normal;
	padding-right:54px;
	mso-char-indent-count:2;}
ruby
	{ruby-align:left;}
rt
	{color:windowtext;
	font-size:9.0pt;
	font-weight:400;
	font-style:normal;
	text-decoration:none;
	font-family:宋体;
	mso-generic-font-family:auto;
	mso-font-charset:134;
	mso-char-type:none;
	display:none;}
-->
</style>
<!--[if gte mso 9]><xml>
 <x:ExcelWorkbook>
  <x:ExcelWorksheets>
   <x:ExcelWorksheet>
    <x:Name>Sheet1</x:Name>
    <x:WorksheetOptions>
     <x:DefaultRowHeight>285</x:DefaultRowHeight>
     <x:Print>
      <x:ValidPrinterInfo/>
      <x:PaperSizeIndex>9</x:PaperSizeIndex>
      <x:VerticalResolution>0</x:VerticalResolution>
     </x:Print>
     <x:CodeName>Sheet1</x:CodeName>
     <x:Selected/>
     <x:Panes>
      <x:Pane>
       <x:Number>3</x:Number>
       <x:ActiveRow>7</x:ActiveRow>
       <x:ActiveCol>1</x:ActiveCol>
       <x:RangeSelection>$B$8:$D$8</x:RangeSelection>
      </x:Pane>
     </x:Panes>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
   <x:ExcelWorksheet>
    <x:Name>Sheet2</x:Name>
    <x:WorksheetOptions>
     <x:DefaultRowHeight>285</x:DefaultRowHeight>
     <x:CodeName>Sheet2</x:CodeName>
     <x:Panes>
      <x:Pane>
       <x:Number>3</x:Number>
       <x:ActiveRow>12</x:ActiveRow>
       <x:ActiveCol>7</x:ActiveCol>
      </x:Pane>
     </x:Panes>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
   <x:ExcelWorksheet>
    <x:Name>Sheet3</x:Name>
    <x:WorksheetOptions>
     <x:DefaultRowHeight>285</x:DefaultRowHeight>
     <x:CodeName>Sheet3</x:CodeName>
     <x:ProtectContents>False</x:ProtectContents>
     <x:ProtectObjects>False</x:ProtectObjects>
     <x:ProtectScenarios>False</x:ProtectScenarios>
    </x:WorksheetOptions>
   </x:ExcelWorksheet>
  </x:ExcelWorksheets>
  <x:WindowHeight>4530</x:WindowHeight>
  <x:WindowWidth>8505</x:WindowWidth>
  <x:WindowTopX>480</x:WindowTopX>
  <x:WindowTopY>120</x:WindowTopY>
  <x:AcceptLabelsInFormulas/>
  <x:ProtectStructure>False</x:ProtectStructure>
  <x:ProtectWindows>False</x:ProtectWindows>
 </x:ExcelWorkbook>
</xml><![endif]-->
</head>
';
$html.="<body link=blue vlink=purple>
<table x:str border=0 cellpadding=0 cellspacing=0 width=1136 style='border-collapse:
 collapse;table-layout:fixed;width:852pt'>
 <col width=180 style='mso-width-source:userset;mso-width-alt:5760;width:135pt'>
 <col width=371 style='mso-width-source:userset;mso-width-alt:11872;width:278pt'>
 <col width=202 style='mso-width-source:userset;mso-width-alt:6464;width:152pt'>
 <col width=383 style='mso-width-source:userset;mso-width-alt:12256;width:287pt'>
 <tr height=80 style='mso-height-source:userset;height:60.0pt'>
  <td colspan=4 height=80 class=xl32 width=1136 style='height:60.0pt;
  width:852pt'>".$work['title']."</td>
 </tr>
 <tr height=46 style='mso-height-source:userset;height:35.1pt'>
  <td colspan=2 height=46 class=xl33 width=551 style='height:35.1pt;width:413pt'>No:".$work['number']."</td>
  <td colspan=2 class=xl34 width=585 style='width:439pt'>拟稿日期:".$work['date']."</td>
 </tr>";
$html.="<tr height=46 style='mso-height-source:userset;height:35.1pt'>";
$query = $db->query("SELECT fromname,inputname FROM ".DB_TABLEPRE.DB_JT."app_from where tplid='".$work['tplid']."' and inputtype!='7' and inputtype1!='2' ORDER BY fromid Asc");
	$n=0;
	while ($row = $db->fetch_array($query)) {
	$n++;
		$values=public_value($row['inputname'],DB_JT.'apps_'.$work['tplid'],'appid='.$appid);
		$html.="<td height=46 class=xl24 width=180 style='height:35.1pt;width:135pt'>".$row["fromname"]."</td>
			<td class=xl28 width=371 style='border-left:none;width:278pt'>".$values."　</td>";
	if($n%2==0){
		$html.= "</tr><tr height=46 style='mso-height-source:userset;height:35.1pt'>";
	}
  }
$html.="</tr>";
$query = $db->query("SELECT fromname,inputname FROM ".DB_TABLEPRE.DB_JT."app_from where tplid='".$work['tplid']."' and inputtype!='7' and inputtype1='2' ORDER BY fromid Asc");
$n=0;
while ($row = $db->fetch_array($query)) {
	$values=public_value($row['inputname'],DB_JT.'apps_'.$work['tplid'],'appid='.$appid);
	$html.="<tr height=46 style='mso-height-source:userset;height:35.1pt'>
	  <td height=46 class=xl24 width=180 style='height:35.1pt;border-top:none;
  width:135pt'>".$row["fromname"]."</td>
	  <td colspan=3 class=xl29 width=956 style='border-right:.5pt solid black;
  border-left:none;width:717pt'>".$values."</td>
	 </tr>";
 }
$html.="
 <![if supportMisalignedColumns]>
 <tr height=0 style='display:none'>
  <td width=180 style='width:135pt'></td>
  <td width=371 style='width:278pt'></td>
  <td width=202 style='width:152pt'></td>
  <td width=383 style='width:287pt'></td>
 </tr>
 <![endif]>
</table>

</body>

</html>";
$html=str_replace("</tr><tr height=46 style='mso-height-source:userset;height:35.1pt'></tr>",'</tr>',$html);
$Path = $filepath;
$fp = fopen($Path,"w"); 
fwrite($fp,$html); 
fclose($fp);
?>