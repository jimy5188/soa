<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
		<title>流程审批</title>
        <link rel="stylesheet" type="text/css" href="template/style2015/content/css/bootstrap.min.css" />
		<link href="template/style2015/bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="template/style2015/content/css/bootstrap-modal.css" />
		        <link rel="stylesheet" type="text/css" href="template/style2015/content/css/bootstrap.css"> 
        <link rel="stylesheet" type="text/css" href="template/style2015/content/css/base.css">
		<link rel="stylesheet" type="text/css" href="template/style2015/content/css/style.css">
		<script type="text/javascript" src="template/style2015/content/js/jquery.min.js"></script>
		<script type="text/javascript" src="template/style2015/content/js/bootstrap.min.js"></script>
		<script type="text/javascript" src="template/style2015/content/js/bootstrap-modal.js"></script>
		<script type="text/javascript" src="template/style2015/content/js/bootstrap-modalmanager.js"></script>
<script type="text/javascript" src="<?php echo style2015;?>content/js/appsflow.js"></script>
<script type="text/javascript">
function FlowNext(fid,uid){
	if(fid!=''){
		<?php foreach ($nextflow as $nextfid) {?>
		document.getElementById(<?php echo $nextfid;?>).className = '';
		<?php }?>
		document.getElementById(fid).className = 'active';
		FlowNextUser(fid,uid);
	}
}
function flowformadd(){
	<?php if($per['flowkey']!='2' && $flowkey5!=2){?>
	if(!$('#user').val()){
		_MsgShow("下一步办理人员不能为空！");
		return (false);
	}
	<?php }?>
	document.flowform.submit();
	return true;
}
</script>
   </head>
	<body onLoad="FlowNext(<?php echo $nextflow[0];?>,<?php echo $row['uid']?>);">
<form name="flowform" id="flowform" method="post" action="admin.php?ac=workflow&do=personnel&fileurl=<?php echo $fileurl?>">
	<input type="hidden" name="view" value="personnel" />
	<input type="hidden" name="title" value="<?php echo $row['title']?>" />
	<input type="hidden" name="appid" value="<?php echo $row['id']?>" />
	<input type="hidden" name="tplid" value="<?php echo $row['tplid']?>" />
	
	<input type="hidden" name="tpltype" value="<?php echo $row['tpltype']?>" />
	<input type="hidden" name="perid" value="<?php echo $per['perid']?>" />
	<input type="hidden" name="flowid" value="<?php echo $per['fid']?>" />
	<input type="hidden" name="content" value="<?php echo $content?>" />
<div class="search_area">
	<table width="100%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
		<tr>
			<td width="76%" align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
				<?php echo $row['title'];?>
			</td>
			<td width="24%" align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
			</td>
		</tr>
	</table>
</div>

<div class="modal-body">
	<div class="container-fluid">
		<div class="row-fluid">
			<div class="span5" >
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title">
							当前步骤：<b>第<span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $per['flownum']?></span>步：<?php echo $per['flowname']?></b>
						</h4>
					</div>
					<div style="height:160px;overflow:auto; padding:15px;">
						<div class="panel-collapse collapse in">
							<span class="badge badge-important btn-small">主办人员：</span> 
							<?php echo $per['name']?><br>
							<?php if($per['entrust']!=''){?>
							<span class="badge badge-success btn-small" style="margin-top:5px;">委办人员：</span> 
							<?php echo get_realname($per['entrust']);}?><br>
							<?php if($per['countersign']!=''){?>
							<span class="badge badge-warning btn-small" style="margin-top:5px;">会签人员：</span> 
							<?php echo $per['countersign'];}?>
						</div>
					</div>
				</div>
			</div>
			<?php if($per['flowkey']!='2' && $flowkey5!=2){?>
			 <div class="span7">
				 <div class="panel panel-default">
					 <div class="panel-heading">
						 <h4 class="panel-title">
							 下一步流程设定：
						 </h4>
					 </div>
					 <div style="height:190px;overflow:auto;">
						 <div class="panel-collapse collapse in">
							 <table width="100%" border="0" cellspacing="0" cellpadding="0">
								 <tr>
									 <td width="240" height="40" valign="top">
										 <table width="100%" border="0" cellspacing="0" cellpadding="0" class="mytable">
											 <?php 
											 foreach ($nextflow as $nextfid) {
												 $sqlnext="SELECT fid,flowname,flownum FROM  
													  ".DB_TABLEPRE.DB_JT."app_flow WHERE
													  fid=".$nextfid;
												 $flownext = $db->fetch_one_array($sqlnext);	
											 ?>
											 <tr id="<?php echo $flownext['fid'];?>">
												 <td height="40" onClick="FlowNext(<?php echo $flownext['fid'];?>,<?php echo $row['uid']?>);">
													 第<?php echo $flownext['flownum'];?>步：<?php echo $flownext['flowname'];?>
												 </td>
											 </tr>
											 <?php }?>
										 </table>
									 </td>
									 <td height="40" valign="top" style="padding-left:50px;">
										<fieldset>
											<legend>办理人员</legend>
											<div id="FlowNextUser"></div>
										</fieldset>
									</td>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>
			<?php }?>
		</div>
	</div>
	<!--消息提示区 -->
	<div class="alert alert-success" style="width:92%; margin-left:20px;">
		<div class="controls">
			提醒相关人员：
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_user"  value="1" checked="checked">发起人</label>
			</div>
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_mana" value="1" checked="checked">当前步骤办理人员</label>
			</div>
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_next" value="1" checked="checked">下一步办理人员</label>
			</div>
			&nbsp;&nbsp;&nbsp;&nbsp;提醒方式：
			<?php if($_CONFIG->config_data('configinfo')=='1'){?>
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_box" value="1" checked="checked">短消息</label>
			</div>
			<?php }
			if($_CONFIG->config_data('configsms')=='1'){?>
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_phone" value="1" checked="checked">手机短信</label>
			</div>
			<?php }
			if($_CONFIG->config_data('configmail')=='1'){?>
			<div class="checkbox inline" style="color:#333333;">
				<label><input type="checkbox" name="sms_mail" value="1" checked="checked">邮件</label>
			</div>
			<?php }?>
		</div>
	</div>
	<div class="input-prepend" style="margin-left:20px;">
		<span class="add-on">消息内容</span>
		<input class="span8" name="sms_content" type="text" value="您有新的公文需要办理，No.：<?php echo $row['number'];?>，名称：<?php echo $row['title'];?>">
	</div>
</div>
<!--底部提交区域 -->
<div class="modal-footer" style="position:absolute; bottom:0px; width:97.5%;">
	<div class="control-group" style=" padding-right:60px;">
		<div class="controls">
			审批类型：
			<div class="radio inline">
				<label><input type="radio" name="pertype" value="1" checked="checked">通过</label>
			</div>
			<div class="radio inline">
				<label><input type="radio" name="pertype" value="2">拒绝</label>
			</div>
			<button type="button" onClick="flowformadd();" class="btn btn-primary btn-large" style=" margin-left:30px;">提交审批</button>
			<button type="button" onClick="window.location.href='admin.php?ac=add&fileurl=apps&appid=<?php echo $appid;?>&tplid=<?php echo $tplid;?>&tpltype=<?php echo $tpltype;?>'" class="btn btn-large" style="margin-left:15px;">返回</button>
		</div>
	</div>
</div>



</form>
<style type="text/css">
.mytable {
  width: 240px;
  padding: 0;
}
.mytable tr{
  border-bottom:1px solid #DDDDDD;
  border-right:1px solid #DDDDDD;
}
.mytable tr td{
	padding-left:20px;
	color:#333333;
	font-size:16px;
}
.mytable tr td:hover{
	padding-left:20px;
	background-color:#EEEEEE;
	font-size:16px;
}
.mytable .active{
	padding-left:20px;
	background-color:#EEEEEE;
	font-size:16px;
}
</style>
<div id="MsgShow" style="height:200px;min-width:500px !important;" class="modal hide fade">
		<div class="modal-header">
			<a class="close" data-dismiss="modal" onClick="js:$('#FileFolderPublic-form .files').empty();">×</a>
			<h4>消息提示</h4>
		</div>
		<div class="modal-body" id="MsgShowContent" style="font-size:22px; text-align:center; line-height:60px;color:#009933;"></div>
</div>
</body>
</html>
