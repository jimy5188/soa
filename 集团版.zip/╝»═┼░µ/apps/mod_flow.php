<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("apps_type");
if(getGP('tplid','G')!=''){
	$tplid=getGP('tplid','G');
}else{
	$tplid=getGP('tplid','P');
}
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
empty($do) && $do = 'list';
if ($do == 'list') {
	$flow = $db->fetch_one_array("SELECT flownum FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' ORDER BY fid asc LIMIT 1");
	if($flow['flownum']!='1'){
		$app_flow = array();
		$app_flow['flowname']='申请人提交申请';
		$app_flow['flownum']=1;
		$app_flow['flowkey']=1;
		$app_flow['flowkey1']=1;
		$app_flow['flowkey2']=2;
		$app_flow['flowkey3']=2;
		$app_flow['tplid']=$tplid;
		$app_flow['uid']=$_USER->id;
		$app_flow['flowtype']=0;
		insert_db(DB_JT.'app_flow',$app_flow);
	}
	//列表信息 
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' order by fid asc");
     $sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' order by fid asc";
	$result = $db->fetch_all($sql);
	include_once('mana/flow.php');

} elseif ($do == 'update') {
	$idarr = getGP('id','P','array');
	foreach ($idarr as $id) {
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE fid = '$id' ");	
	}
	$content=serialize($idarr);
	$title='删除审批流程';
	get_logadd($id,$content,$title,14,$_USER->id);
	show_msg('审批流程信息删除成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tplid='.$tplid.'&tpltype='.$tpltype.'');
}elseif ($do == 'pic') {
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' order by fid asc");
    $sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' order by fid asc";
	$result = $db->fetch_all($sql);
	include_once('mana/flowpic.php');
}elseif ($do == 'add') {
	if($_POST['view']!=''){
		$fid = getGP('fid','P','int');
		if($fid!=''){
			$flowname = check_str(getGP('flowname','P'));
			$flownum = check_str(getGP('flownum','P'));
			$flowusertype=getGP('flowusertype','P','int');
			if($flowusertype==1){
				$flowuser = check_str(getGP('flowuser1','P'));
			}elseif($flowusertype==2){
				$flowuser = check_str(getGP('flowuser2id','P'));
			}elseif($flowusertype==3){
				$flowuser = check_str(getGP('flowuser3id','P'));
			}elseif($flowusertype==4){
				$flowuser = '';
			}
			$flowkey = getGP('flowkey','P');
			$flowkey1 = getGP('flowkey1','P');
			$flowkey2 = getGP('flowkey2','P');
			$flowkey3 = getGP('flowkey3','P');
			$flowdate = getGP('flowdate','P');
			$flowdatetype = getGP('flowdatetype','P');
			if($flowkey3==''){
				$flowkey3='2';
			}
			$flowkey4post=getGP('flowkey4','P','array');
			foreach ($flowkey4post as $arr4) {
				$flowkey4.=$arr4.',';
			}
			$formkey=serialize(getGP('formkey','P','array'));
			$flowkey6post=getGP('flowkey6','P','array');
			foreach ($flowkey6post as $arr6) {
				$flowkey6.=$arr6.',';
			}
			$flowkey7 = getGP('flowkey7','P');
			$flowkey5_from = getGP('flowkey5_from','P');
			if(trim($flowkey5_from)!='0'){
				$flowkey5=$flowkey5_from.'|'.getGP('flowkey5_if','P').'|'.getGP('flowkey5_value','P').'|'.getGP('flowkey5_end','P');
			}else{
				$flowkey5='0|0|0|0';
			}
			$flowkey8='';
			for($i=1;$i<=4;$i++){
				if(getGP('flowkey8_'.$i,'P','int')!=''){
					$flowkey8.=getGP('flowkey8_'.$i,'P','int').'|';
				}else{
					$flowkey8.='0|';
				}
			}
			$flowtype = getGP('flowtype','P');
			$app_flow = array(
				'flowname' => $flowname,
				'flowusertype' => $flowusertype,
				'flowuser' => $flowuser,
				'flowkey' => $flowkey,
				'flowkey1' => $flowkey1,
				'flowkey2' => $flowkey2,
				'flowkey3' => $flowkey3,
				'flowkey4' => $flowkey4,
				'flowkey5' => $flowkey5,
				'flowkey6' => $flowkey6,
				'flowkey7' => $flowkey7,
				'flowkey8' => $flowkey8,
				'flowdate' => $flowdate,
				'flowtype' => $flowtype,
				'flowdatetype' => $flowdatetype,
				'formkey' => $formkey
			);
			update_db(DB_JT.'app_flow',$app_flow, array('fid' => $fid));
			$content='';
			$content=serialize($app_flow);
			$title='审批流程信息';
			get_logadd($id,$content,$title,14,$_USER->id);
			
		}else{
			$flowname = check_str(getGP('flowname','P'));
			$flownum = check_str(getGP('flownum','P'));
			$flowusertype=getGP('flowusertype','P','int');
			if($flowusertype==1){
				$flowuser = check_str(getGP('flowuser1','P'));
			}elseif($flowusertype==2){
				$flowuser = check_str(getGP('flowuser2id','P'));
			}elseif($flowusertype==3){
				$flowuser = check_str(getGP('flowuser3id','P'));
			}elseif($flowusertype==4){
				$flowuser = '';
			}
			$flowkey = getGP('flowkey','P');
			$flowkey1 = getGP('flowkey1','P');
			$flowkey2 = getGP('flowkey2','P');
			$flowkey3 = getGP('flowkey3','P');
			$flowdate = getGP('flowdate','P');
			$flowdatetype = getGP('flowdatetype','P');
			$flowkey4post=getGP('flowkey4','P','array');
			foreach ($flowkey4post as $arr4) {
				$flowkey4.=$arr4.',';
			}
			$formkey=serialize(getGP('formkey','P','array'));
			$flowkey6post=getGP('flowkey6','P','array');
			foreach ($flowkey6post as $arr6) {
				$flowkey6.=$arr6.',';
			}
			$flowkey7 = getGP('flowkey7','P');
			$flowkey5_from = getGP('flowkey5_from','P');
			if(trim($flowkey5_from)!='0'){
				$flowkey5=$flowkey5_from.'|'.getGP('flowkey5_if','P').'|'.getGP('flowkey5_value','P').'|'.getGP('flowkey5_end','P');
			}else{
				$flowkey5='0|0|0|0';
			}
			$flowkey8='';
			for($i=1;$i<=4;$i++){
				if(getGP('flowkey8_'.$i,'P','int')!=''){
					$flowkey8.=getGP('flowkey8_'.$i,'P','int').'|';
				}else{
					$flowkey8.='0|';
				}
			}
			$flowtype = getGP('flowtype','P');
			$app_flow = array(
				'flowname' => $flowname,
				'flownum' => $flownum,
				'flowusertype' => $flowusertype,
				'flowuser' => $flowuser,
				'uid' => $_USER->id,
				'tplid' => $tplid,
				'flowtype' => $flowtype,
				'flowkey' => $flowkey,
				'flowkey1' => $flowkey1,
				'flowkey2' => $flowkey2,
				'flowkey3' => $flowkey3,
				'flowkey4' => $flowkey4,
				'flowkey5' => $flowkey5,
				'flowkey6' => $flowkey6,
				'flowkey7' => $flowkey7,
				'flowkey8' => $flowkey8,
				'flowdate' => $flowdate,
				'flowdatetype' => $flowdatetype,
				'formkey' => $formkey
			);
			insert_db(DB_JT.'app_flow',$app_flow);
			$id=$db->insert_id();
			$content=serialize($app_flow);
			$title='审批流程信息';
			get_logadd($id,$content,$title,14,$_USER->id);
		}
		show_msg('审批流程信息操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tplid='.$tplid.'&tpltype='.$tpltype.'');
	}else{
		$fid = getGP('fid','G','int');
		if($fid!=''){
			$user = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '$fid'");
			$flownum=$user['flownum'];
			$_title['name']='编辑';
		}else{ 
			$apps = $db->fetch_one_array("SELECT flownum FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".$tplid."' ORDER BY fid desc LIMIT 1");
			$flownum=$apps["flownum"]+1;
			$user['flowkey']=1;
			$user['flowusertype']=1;
			$user['flowkey1']='1';
			$user['flowkey2']=2;
			$user['flowdatetype']=0;
			$user['flowdate']=30;
			$user['tplid'] = getGP('tplid','G','int');
			$user['typeid'] = getGP('typeid','G','int');
			$user['flowkey7']=0;
			$user['flowkey8']='1|1|1|1';
			$_title['name']='发布';
		}
		include_once('mana/flowadd.php');
	}
}
?>