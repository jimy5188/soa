<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
empty($do) && $do = 'list';
get_key("apps_delivery");
if(getGP('dtype','G')!=''){
	$dtype=getGP('dtype','G');
}else{
	$dtype=getGP('dtype','P');
}
if ($do == 'list') {
	//列表信息 
	$wheresqltype = '';
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&dtype='.$dtype.'';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($dtype!='') {
		$wheresql .= " AND dtype='".$dtype."'";
	}
	$vstartdate = getGP('vstartdate','G');
	$venddate = getGP('venddate','G');
	if ($vstartdate!='' && $venddate!='') {
		$wheresql .= " AND (startdate>='".$vstartdate."' and startdate<='".$venddate."')";
		$url .= '&vstartdate='.$vstartdate.'&venddate='.$venddate;
	}
	//获取部门数据
	$dread=public_value('departmentid','user','id='.$_USER->id);
	$dread=explode(',',$dread);
	$dreads='';
	for($i=0;$i<sizeof($dread);$i++){
		if(trim($dread[$i])!=''){
			$dreads.="'".$dread[$i]."',";
		}
	}
	$dreads=substr($dreads, 0, -1);
	if ($dreads!='') {
		$wheresql .= " AND dread in(".$dreads.")";
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_delivery WHERE 1 $wheresql  order by startdate desc");
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_delivery WHERE 1 $wheresql order by startdate desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/deliverylist.php');

}elseif ($do == 'view') {
	$did=getGP('did','G','int');
	if($did!=''){
		$row = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_delivery WHERE  did='".$did."' order by did asc");
		include_once('template/deliveryiew.php');
	}
}elseif ($do == 'update') {
	$idarr = getGP('id','P','array');
	foreach ($idarr as $id) {
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_delivery WHERE did = '$id' ");
	}
	show_msg('公文批量删除处理成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&dtype='.$dtype.'');

}
elseif ($do == 'viewsave') {
	if(getGP('did','G','int')!=''){
		$db->query("update ".DB_TABLEPRE.DB_JT."app_delivery set dtype='".getGP('dtype','G','int')."' WHERE did= '".getGP('did','G','int')."' ");	
		show_msg('签收文件处理成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&dtype='.getGP('dtype','G','int').'');
	}

}
?>