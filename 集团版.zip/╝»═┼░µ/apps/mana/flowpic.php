<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->

 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<link rel="stylesheet" href="template/jsPlumb/demo-all.css">     
        <link rel="stylesheet" href="template/jsPlumb/demo.css">
		<script type="text/javascript" src="template/jsPlumb/simpleyui-min.js"></script>
           <!-- JS -->
        <!-- support lib for bezier stuff -->
        <script src="template/jsPlumb/lib/jsBezier-0.6.js"></script>     
        <!-- jsplumb geom functions -->   
        <script src="template/jsPlumb/lib/jsplumb-geom-0.1.js"></script>
        <!-- jsplumb util -->
        <script src="template/jsPlumb/src/util.js"></script>
        <!-- base DOM adapter -->
        <script src="template/jsPlumb/src/dom-adapter.js"></script>        
        <!-- main jsplumb engine -->
        <script src="template/jsPlumb/src/jsPlumb.js"></script>
        <!-- endpoint -->
        <script src="template/jsPlumb/src/endpoint.js"></script>                
        <!-- connection -->
        <script src="template/jsPlumb/src/connection.js"></script>
        <!-- anchors -->
        <script src="template/jsPlumb/src/anchors.js"></script>        
        <!-- connectors, endpoint and overlays  -->
        <script src="template/jsPlumb/src/defaults.js"></script>
        <!-- bezier connectors -->
        <script src="template/jsPlumb/src/connectors-bezier.js"></script>
        <!-- state machine connectors -->
        <script src="template/jsPlumb/src/connectors-statemachine.js"></script>
        <!-- flowchart connectors -->
        <script src="template/jsPlumb/src/connectors-flowchart.js"></script>
        <script src="template/jsPlumb/src/connector-editors.js"></script>
        <!-- SVG renderer -->
        <script src="template/jsPlumb/src/renderers-svg.js"></script>
        <!-- canvas renderer -->
        <script src="template/jsPlumb/src/renderers-canvas.js"></script>
        <!-- vml renderer -->
        <script src="template/jsPlumb/src/renderers-vml.js"></script>
        
        <!-- yui jsPlumb adapter -->
        <script src="template/jsPlumb/src/yui.jsPlumb.js"></script>
        <!-- /JS -->  
		<script type="text/javascript">
		jsPlumb.ready(function() {
			var instance = jsPlumb.getInstance({
			// 默认拖动选项
			DragOptions : { cursor: 'pointer', zIndex:2000 },
			// 在覆盖装饰与每个连接。注意，该标签重叠使用一个函数来生成标签文字，在这种
			// 情况下，它返回'LabelText的'成员，我们在'初始化'下面的方法在每个连接上设置。
			ConnectionOverlays : [
				[ "Arrow", { location:0.993 } ],
				[ "Label", { 
					location:0.3,
					id:"label",
					cssClass:"aLabel"
				}]
			],
			Container:"flowchart-demo"
		});		

		// 这是油漆样式连接线..
		var connectorPaintStyle = {
			lineWidth:4,
			strokeStyle:"#61B7CF",
			joinstyle:"round",
			outlineColor:"white",
			outlineWidth:1
		},
		// ..这就是hover样式。
		connectorHoverStyle = {
			lineWidth:4,
			strokeStyle:"#216477",
			outlineWidth:1,
			outlineColor:"white"
		},
		endpointHoverStyle = {
			fillStyle:"#216477",
			strokeStyle:"#216477"
		},
		// 源端点（小蓝的）的定义
		sourceEndpoint = {
			endpoint:"Dot",
			paintStyle:{ 
				strokeStyle:"#7AB02C",
				fillStyle:"transparent",
				radius:0.1,
				lineWidth:0.1 
			},				
			isSource:true,
			connector:[ "Flowchart", { stub:[10, 25], gap:5, cornerRadius:5, alwaysRespectStubs:true } ],								                
			connectorStyle:connectorPaintStyle,
			hoverPaintStyle:endpointHoverStyle,
			connectorHoverStyle:connectorHoverStyle,
            dragOptions:{},
            overlays:[
            	[ "Label", { 
                	location:[0.5, 1.5], 
                	label:"",
                	cssClass:"endpointSourceLabel" 
                } ]
            ]
		},		
		// 目标端点的定义（当用户拖动一个连接会出现） 
		targetEndpoint = {
			endpoint:"Dot",					
			paintStyle:{ fillStyle:"#7AB02C",radius:1 },
			hoverPaintStyle:endpointHoverStyle,
			maxConnections:-1,
			dropOptions:{ hoverClass:"hover", activeClass:"active" },
			isTarget:true,			
            overlays:[
            	[ "Label", { location:[0.5, -0.5], label:"", cssClass:"endpointTargetLabel" } ]
            ]
		},			
		init = function(connection) {			
			connection.getOverlay("label").setLabel(connection.sourceId.substring(15) + "-" + connection.targetId.substring(15));
			connection.bind("editCompleted", function(o) {
				if (typeof console != "undefined")
					console.log("connection edited. path is now ", o.path);
			});
		};			

		var _addEndpoints = function(toId, sourceAnchors, targetAnchors) {
				for (var i = 0; i < sourceAnchors.length; i++) {
					var sourceUUID = toId + sourceAnchors[i];
					instance.addEndpoint("flowchart" + toId, sourceEndpoint, { anchor:sourceAnchors[i], uuid:sourceUUID });						
				}
				for (var j = 0; j < targetAnchors.length; j++) {
					var targetUUID = toId + targetAnchors[j];
					instance.addEndpoint("flowchart" + toId, targetEndpoint, { anchor:targetAnchors[j], uuid:targetUUID });						
				}
			};

		// 暂停绘画和初始化。
		instance.doWhileSuspended(function() {
		<?php
		$n=0;
		foreach ($result as $row) {
		$n++;
		?>
			_addEndpoints("Window<?php echo $n;?>", ["TopCenter", "BottomCenter"], ["LeftMiddle", "RightMiddle"]);			
		<?php }?>
						
			// 监听新的连接，初始化他们，我们在初始化启动时的连接方式相同。
			instance.bind("connection", function(connInfo, originalEvent) { 
				init(connInfo.connection);
			});			
						
			// 使所有的窗口可拖动的div						
			instance.draggable(jsPlumb.getSelector(".flowchart-demo .window"), { grid: [20, 20] });		

			// 连接数了
			<?php
			$n=0;
			foreach ($result as $row) {
			$n++;
				if($n<$num){
				?>
					instance.connect({uuids:["Window<?php echo $n;?>BottomCenter", "Window<?php echo $n+1;?>TopCenter"], editable:true});
				<?php
				}
					if($row['flowkey']==3){
						$flowkey4=explode(',',substr($row['flowkey4'], 0, -1));
						for($i=0;$i<sizeof($flowkey4);$i++){
						$user = $db->fetch_one_array("SELECT flownum FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '".$flowkey4[$i]."'");
					?>
						instance.connect({uuids:["Window<?php echo $n;?>LeftMiddle", "Window<?php echo $user['flownum'];?>RightMiddle"], editable:true});
					<?php
						}
					}
				//}
			}
			?>
		});
		
	});
		</script>
		<style type="text/css">
		<?php
		$n=0;
		$stytop=3;
		$styleft=5;
		foreach ($result as $row) {
		$n++;
		if($n>1) $stytop+=10;
		if($n%6==0){
			$stytop=3;
		}
		if($n%6==0){
			$styleft+=25;
		}
		if($n==1){
			$background=' background:#96dd7c;';
		}elseif($row['flowkey']==2){
			$background=' background:#f6b9ca;';
		}else{
			$background=' background:#f0f0f0;';
		}
		?>
		#flowchartWindow<?php echo $n;?> { top:<?php echo $stytop;?>em;left:<?php echo $styleft;?>em; <?php echo $background;?>}
		<?php }?>
		</style>
<script type="text/javascript">
	function active(type){
		if(type!=''){
			document.getElementById('from').className = '';
			document.getElementById('attchment').className = '';
			document.getElementById('remark').className = '';
			document.getElementById(type).className = 'active'; 
		}
	}
</script>

</head>

<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li class="active" id="from"><a href="#form" onClick="active('from');">流程图</a></li>
					<li id="attchment"><a href="#content-attchment" onClick="active('attchment');">流程走向表</a></li>
					<li id="remark"><a href="#content-remark" onClick="active('remark');">流程说明</a></li>
					
				</ul>
			</div>

<div class="search_area">
        <table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<?php echo public_value('title',DB_JT.'app_type','tplid='.getGP('tplid','G','int'));?>流程查看
	</td>
  </tr>
</table>
</div>

<div  style="position:absolute; height:82%; width:100%;overflow:auto; ">

<div  id='form'>
<div class="demo flowchart-demo" id="flowchart-demo">
<?php
$n=0;
foreach ($result as $row) {
$n++;
?>
<div class="window" id="flowchartWindow<?php echo $n;?>"><strong>第 <span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $row['flownum']?>	</span>步:</strong><?php echo $row['flowname']?></div>
<?php }?>
</div> 
</div>

<div id="attchment">
<div class="content-attchment" id="content-attchment" style="width:95%;">
			<div class="attchment-title-block">
				<span class="attchment-public">流程走向表</span>
			</div>
<?php

$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid='".getGP('tplid','G','int')."' order by flownum asc";
$result = $db->fetch_all($sql);
?>
<table class="TableList " align="center"  style="width:680px;">
		<tr class="TableLine1" style="line-height:30px;background:#fdfaf3;" >
		<td align='center'>步骤</td>
		<td align='center'>流程名称</td>
		<td align='center'>流程走向</td>
		</tr>
<?php foreach ($result as $row) {?>
<tr class="TableData" style="line-height:30px;">
		<td align='center'>第 <span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $row['flownum']?>	</span>步</td>
		<td align='center'><?php echo $row['flowname']?></td>
		<td align='center'>
		<?php
		if($row['flowkey']==2){
			echo '结束';
		}else{
			echo '-->'.($row['flownum']+1);
			if($row['flowkey4']!=''){
				echo '-->'.flowpic($row['flowkey4']);
			}
		}
		?>
		
		</td>
		</tr>
<?php }?>
</table>

	</div>
</div>
<div id="remark">
<div class="content-remark" id="content-remark" style="width:95%;">
			<div class="remark-block">
				<span class="remark-title">流程说明</span>
			</div>
<table  align="center"  style="width:680px;">
<tr  style="line-height:30px;">
		<td align='left'><?php
			if(public_value('content',DB_JT.'app_type','tplid='.getGP('tplid','G','int'))!=''){
			echo public_value('content',DB_JT.'app_type','tplid='.getGP('tplid','G','int'));
			}else{
			echo '暂无';
			}?>
		</td>
		</tr>

</table>
			
			
		</div>
	</div>



</div>
</body>
</html>

