<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->

 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="template/default/js/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="template/default/content/js/common.js"></script>
<link rel="stylesheet" href="template/jsPlumb/demo-all.css">     
        <link rel="stylesheet" href="template/jsPlumb/demo.css">
		<script type="text/javascript" src="template/jsPlumb/simpleyui-min.js"></script>
           <!-- JS -->
        <!-- support lib for bezier stuff -->
        <script src="template/jsPlumb/lib/jsBezier-0.6.js"></script>     
        <!-- jsplumb geom functions -->   
        <script src="template/jsPlumb/lib/jsplumb-geom-0.1.js"></script>
        <!-- jsplumb util -->
        <script src="template/jsPlumb/src/util.js"></script>
        <!-- base DOM adapter -->
        <script src="template/jsPlumb/src/dom-adapter.js"></script>        
        <!-- main jsplumb engine -->
        <script src="template/jsPlumb/src/jsPlumb.js"></script>
        <!-- endpoint -->
        <script src="template/jsPlumb/src/endpoint.js"></script>                
        <!-- connection -->
        <script src="template/jsPlumb/src/connection.js"></script>
        <!-- anchors -->
        <script src="template/jsPlumb/src/anchors.js"></script>        
        <!-- connectors, endpoint and overlays  -->
        <script src="template/jsPlumb/src/defaults.js"></script>
        <!-- bezier connectors -->
        <script src="template/jsPlumb/src/connectors-bezier.js"></script>
        <!-- state machine connectors -->
        <script src="template/jsPlumb/src/connectors-statemachine.js"></script>
        <!-- flowchart connectors -->
        <script src="template/jsPlumb/src/connectors-flowchart.js"></script>
        <script src="template/jsPlumb/src/connector-editors.js"></script>
        <!-- SVG renderer -->
        <script src="template/jsPlumb/src/renderers-svg.js"></script>
        <!-- canvas renderer -->
        <script src="template/jsPlumb/src/renderers-canvas.js"></script>
        <!-- vml renderer -->
        <script src="template/jsPlumb/src/renderers-vml.js"></script>
        
        <!-- yui jsPlumb adapter -->
        <script src="template/jsPlumb/src/yui.jsPlumb.js"></script>
        <!-- /JS -->  
		<script type="text/javascript">
		jsPlumb.ready(function() {
			var instance = jsPlumb.getInstance({
			// 默认拖动选项
			DragOptions : { cursor: 'pointer', zIndex:2000 },
			// 在覆盖装饰与每个连接。注意，该标签重叠使用一个函数来生成标签文字，在这种
			// 情况下，它返回'LabelText的'成员，我们在'初始化'下面的方法在每个连接上设置。
			ConnectionOverlays : [
				[ "Arrow", { location:0.993 } ],
				[ "Label", { 
					location:0.3,
					id:"label",
					cssClass:"aLabel"
				}]
			],
			Container:"flowchart-demo"
		});		

		// 这是油漆样式连接线..
		var connectorPaintStyle = {
			lineWidth:4,
			strokeStyle:"#61B7CF",
			joinstyle:"round",
			outlineColor:"white",
			outlineWidth:1
		},
		// ..这就是hover样式。
		connectorHoverStyle = {
			lineWidth:4,
			strokeStyle:"#216477",
			outlineWidth:1,
			outlineColor:"white"
		},
		endpointHoverStyle = {
			fillStyle:"#216477",
			strokeStyle:"#216477"
		},
		// 源端点（小蓝的）的定义
		sourceEndpoint = {
			endpoint:"Dot",
			paintStyle:{ 
				strokeStyle:"#7AB02C",
				fillStyle:"transparent",
				radius:0.1,
				lineWidth:0.1 
			},				
			isSource:true,
			connector:[ "Flowchart", { stub:[10, 25], gap:5, cornerRadius:5, alwaysRespectStubs:true } ],								                
			connectorStyle:connectorPaintStyle,
			hoverPaintStyle:endpointHoverStyle,
			connectorHoverStyle:connectorHoverStyle,
            dragOptions:{},
            overlays:[
            	[ "Label", { 
                	location:[0.5, 1.5], 
                	label:"",
                	cssClass:"endpointSourceLabel" 
                } ]
            ]
		},		
		// 目标端点的定义（当用户拖动一个连接会出现） 
		targetEndpoint = {
			endpoint:"Dot",					
			paintStyle:{ fillStyle:"#7AB02C",radius:1 },
			hoverPaintStyle:endpointHoverStyle,
			maxConnections:-1,
			dropOptions:{ hoverClass:"hover", activeClass:"active" },
			isTarget:true,			
            overlays:[
            	[ "Label", { location:[0.5, -0.5], label:"", cssClass:"endpointTargetLabel" } ]
            ]
		},			
		init = function(connection) {			
			connection.getOverlay("label").setLabel(connection.sourceId.substring(15) + "-" + connection.targetId.substring(15));
			connection.bind("editCompleted", function(o) {
				if (typeof console != "undefined")
					console.log("connection edited. path is now ", o.path);
			});
		};			

		var _addEndpoints = function(toId, sourceAnchors, targetAnchors) {
				for (var i = 0; i < sourceAnchors.length; i++) {
					var sourceUUID = toId + sourceAnchors[i];
					instance.addEndpoint("flowchart" + toId, sourceEndpoint, { anchor:sourceAnchors[i], uuid:sourceUUID });						
				}
				for (var j = 0; j < targetAnchors.length; j++) {
					var targetUUID = toId + targetAnchors[j];
					instance.addEndpoint("flowchart" + toId, targetEndpoint, { anchor:targetAnchors[j], uuid:targetUUID });						
				}
			};

		// 暂停绘画和初始化。
		instance.doWhileSuspended(function() {
		<?php
		$n=0;
		foreach ($result as $row) {
		$n++;
		?>
			_addEndpoints("Window<?php echo $n;?>", ["TopCenter", "BottomCenter"], ["LeftMiddle", "RightMiddle"]);			
		<?php }?>
						
			// 监听新的连接，初始化他们，我们在初始化启动时的连接方式相同。
			instance.bind("connection", function(connInfo, originalEvent) { 
				init(connInfo.connection);
			});			
						
			// 使所有的窗口可拖动的div						
			instance.draggable(jsPlumb.getSelector(".flowchart-demo .window"), { grid: [20, 20] });		

			// 连接数了
			<?php
			$n=0;
			foreach ($result as $row) {
			$n++;
				if($n<$num){
				?>
					instance.connect({uuids:["Window<?php echo $n;?>BottomCenter", "Window<?php echo $n+1;?>TopCenter"], editable:true});
				<?php
				}
					if($row['flowkey4']!=''){
						$flowkey4=explode(',',substr($row['flowkey4'], 0, -1));
						for($i=0;$i<sizeof($flowkey4);$i++){
						$user = $db->fetch_one_array("SELECT flownum FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '".$flowkey4[$i]."'");
					?>
						instance.connect({uuids:["Window<?php echo $n;?>LeftMiddle", "Window<?php echo $user['flownum'];?>LeftMiddle"], editable:true});
						//instance.connect({uuids:["Window<?php echo $n;?>RightMiddle", "Window7RightMiddle"], editable:true});

					<?php
						}
					}
					if($row['flowkey6']!=''){
						$flowkey6=explode(',',substr($row['flowkey6'], 0, -1));
						for($i=0;$i<sizeof($flowkey6);$i++){
						$user = $db->fetch_one_array("SELECT flownum FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '".$flowkey6[$i]."'");
					?>
						instance.connect({uuids:["Window<?php echo $n;?>RightMiddle", "Window<?php echo $user['flownum'];?>RightMiddle"], editable:true});
						//instance.connect({uuids:["Window<?php echo $n;?>RightMiddle", "Window7RightMiddle"], editable:true});

					<?php
						}
					}
				//}
			}
			?>
		});
		
	});
		</script>
		<style type="text/css">
		<?php
		$n=0;
		$stytop=3;
		$styleft=10;
		foreach ($result as $row) {
		$n++;
		if($n>1) $stytop+=10;
		if($n%6==0){
			$stytop=3;
		}
		if($n%6==0){
			$styleft+=30;
		}
		if($n==1){
			$background=' background:#96dd7c;';
		}elseif($row['flowkey']==2){
			$background=' background:#f6b9ca;';
		}else{
			$background=' background:#f0f0f0;';
		}
		?>
		#flowchartWindow<?php echo $n;?> { top:<?php echo $stytop;?>em;left:<?php echo $styleft;?>em; <?php echo $background;?>}
		<?php }?>
		</style>
<script type="text/javascript">
	function active(type){
		if(type!=''){
			document.getElementById('flow_pics').className = '';
			document.getElementById('flow_forms').className = '';
			document.getElementById(type).className = 'active'; 
		}
	}
</script>

</head>

<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li class="active" id="flow_forms"><a href="#flow_form" onClick="active('flow_forms');">流程设置</a></li>
					<li id="flow_pics"><a href="#flow_pic" onClick="active('flow_pics');">流程图显示</a></li>
					
				</ul>
</div>
			
<div class="search_area">
        <table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	公文流程管理
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">

	<button type="button" onClick="document:update.submit();" class="btn btn-danger">删除步骤</button>&nbsp;&nbsp;<button id="do_search" type="button" onClick="javascript:window.location='admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=add&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>'" class="btn btn-primary">新建步骤</button>&nbsp;&nbsp;&nbsp;&nbsp;<button id="do_search" type="button" onClick="javascript:window.location='admin.php?ac=tpl&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $tpltype;?>'" class="btn btn-success">返回类别管理</button>
	</td>
  </tr>
</table>
</div>

<div style="position:absolute;overflow:auto; left:0px;height:440px; width:100%;">
<div id='flow_form'>
<form name="update" method="post" action="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>">
  <input type="hidden" name="do" value="update"/>
<table class="TableBlock" border="0" width="98%" align="center">
 
   
	<tr>
      <td width="80" align="center" nowrap class="TableHeader"><input type="checkbox" class="checkbox" value="1" name="chkall" onClick="check_all(this)" /></td>
      <td  class="TableHeader">流程名称</td>
      <td width="120" align="center" class="TableHeader">流程步骤</td>
      <td width="120" align="center" class="TableHeader">类型</td>
      <td width="120" align="center" class="TableHeader">状态</td>
      <td width="220" align="center" class="TableHeader">流程走向</td>
	  <td width="80" align="center" class="TableHeader">发布人</td>
      <td width="60" align="center" class="TableHeader">操作</td>
    </tr>
<?php foreach ($result as $row) {?>
	<tr>
      <td width="5%" align="center" nowrap class="TableContent">
	  <?php
	  $anum=$db->result("SELECT COUNT(*) AS anum FROM ".DB_TABLEPRE.DB_JT."app_personnel where flowid='".$row['fid']."'");
	  ?>
	  <input type="checkbox" name="id[]" value="<?php echo $row['fid']?>" class="checkbox" <?php if($anum>0){?>disabled="disabled"<?php }?> /></td>
      <td class="TableData"><?php echo $row['flowname']?></td>
	  <td align="center" class="TableData">
	  第 <span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $row['flownum']?>	</span>步</td>
	  <td align="center" class="TableData">
	  <?php
	  if($row['flowkey']==1){
		  echo '转交下一步';
	  }elseif($row['flowkey']==2){
		   echo '<font color=#FF0000>流程结束</font>';
	  }?></td>
      
      <td align="center" class="TableData">
	  <?php
	  if($row['flowkey1']==1){
		  echo '可选';
	  }elseif($row['flowkey1']==2){
		  echo '条件内可选';
	  }elseif($row['flowkey1']==3){
		   echo '<font color=#FF0000>不可选</font>';
	  }?>	  </td>
      <td align="center" class="TableData">
	  <?php
	  if($row['flowkey']==2){
	  		if($row['flowkey4']!=''){
				echo '-->'.flowpic($row['flowkey4']).'-->';
			}
			echo '结束';
		}else{
			if($row['flowkey4']!=''){
				echo '-->'.flowpic($row['flowkey4']);
			}
			//echo '-->'.($row['flownum']+1);
			if($row['flowkey6']!=''){
				echo '-->'.flowpic($row['flowkey6']);
			}
		}
	  ?>	  </td>
	  <td align="center" class="TableData">
	  <?php echo get_realname($row['uid'])?></td>
      <td align="center" class="TableData">
	  
	  <a href="admin.php?ac=<?php echo $ac?>&do=add&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>&fid=<?php echo $row['fid']?>">编辑</a>	  </td>
    </tr>
	
<?php }?>	
  </table>
</form>
</div>




<div  id='flow_pic'>
	<div class="content-attchment" id="content-attchment" style="width:95%;">
		<div class="demo flowchart-demo" id="flowchart-demo">
			<?php
			$n=0;
			foreach ($result as $row) {
			$n++;
			?>
				<div class="window" id="flowchartWindow<?php echo $n;?>"><strong>第 <span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $row['flownum']?>	</span>步:</strong><?php echo $row['flowname']?></div>
			<?php }?>
		</div> 
	</div>
</div>


</div>
</body>
</html>

