<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html>
<head>
<meta content="text/html; charset=utf-8" http-equiv="Content-Type"/>
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script src="template/default/tree/js/admincp.js?SES" type="text/javascript"></script>
<script type="text/javascript" src="ckeditor/ckeditor.js"></script>

<title>Office 515158 2011 OA办公系统</title>
 
</head>
<body class="bodycolor">
<table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td class="Big"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3"> 公文类别创建</span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:12px; float:right; margin-right:20px;">
	
	<a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $tpltype?>" style="font-size:12px;"><<返回列表页</a></span>
    </td>
  </tr>
</table>
<script Language="JavaScript"> 
function CheckForm()
{
   if(document.save.title.value=="")
   { alert("名称不能为空！");
     document.save.title.focus();
     return (false);
   }
   return true;
}
function sendForm()
{
   if(CheckForm())
      document.save.submit();
}
window.onload = function (){
	<?php if($blog['tplusertype']==''){?>
		checkbox4(1);
	<?php }else{?>
		checkbox4(<?php echo trim($blog['tplusertype'])?>);
	<?php }?>
}

function checkbox4(value){
	div4.style.display="none";
	div5.style.display="none";
	div6.style.display="none";
	if(value==1){
		div4.style.display="block";
	}else if(value==2){
		div5.style.display="block";
	}else{
		div6.style.display="block";
	}
}

</script>


<form name="save" method="post" action="?ac=<?php echo $ac?>&do=addsave&fileurl=<?php echo $fileurl?>">
<input type="hidden" name="tpltype" value="<?php echo $tpltype?>" />
<table class="TableBlock" border="0" width="90%" align="center">
 
	<tr>
      <td nowrap class="TableContent" width="15%"> 名称：<? get_helps()?></td>
      <td class="TableData">
      <input type="text" name="title" class="BigInput" style="width:268px;" size="20" value="" /></td>
    </tr>
	<tr>
      <td nowrap class="TableContent" width="15%"> 状态：<? get_helps()?></td>
      <td class="TableData">
	  <input name="tplkey" type="radio" value="1" checked="checked" />正常模板
      <input name="tplkey" type="radio" value="2"  />模板停用
	  <br>
	  
	  正常模板:该模型可以正常使用，模通过可视化编辑器设计模板;	  <br>模板停用:该模型停止使用;
	 </td>
    </tr>
   <!--<tr>
      <td nowrap class="TableContent" width="15%"> 类程类型：<? get_helps()?></td>
      <td class="TableData">
	  <input name="tplflow" type="radio" value="1" checked="checked" />固定
      <input name="tplflow" type="radio" value="2"  />自由
	 </td>
    </tr> -->
	<input type="hidden" name="tplflow" value="1" />
	<tr>
      <td nowrap class="TableContent" width="15%"> 使用人员：</td>
      <td class="TableData">
      <input name="tplusertype" type="radio" style="border:0;" value="1" <? if($blog['tplusertype']=='1'){?>checked="checked"<? }?> onclick="checkbox4(1)" />
      按人员
			<input name="tplusertype" type="radio" style="border:0;" value="2" <? if($blog['tplusertype']=='2'){?>checked="checked"<? }?> onclick="checkbox4(2)" />
			按岗位
			<input name="tplusertype" type="radio" style="border:0;" value="3" <? if($blog['tplusertype']=='3'){?>checked="checked"<? }?> onclick="checkbox4(3)" />
			按部门<br>
	<div id="div4">
	  <?php
	  get_pubuser(2,"tpluser1",'0',"+选择审批人员",50,3)
	  ?><br><font color="#868788">注：是指允许使用此模型的人员，留空为全体人员使用</font>
	  </div>
	  <div id="div5">
	  <?php
	  get_positionbox(2,'tpluser2','0','+选择岗位',$width=50,$height=3);
	  ?><br><font color="#868788">注：是指允许使用此模型的人员，以岗位来设定成员，不可为空</font>
	  </div>
      <div id="div6">
	  <?php
	  get_depabox(2,'tpluser3','0','+选择部门',$width=50,$height=3);
	  ?><br><font color="#868788">注：是指允许使用此模型的人员，以部门来设定成员，不可为空</font>
	  </div></td>
    </tr>
	<tr>
      <td nowrap class="TableContent" width="15%"> 监控人员：<? get_helps()?></td>
      <td class="TableData">
      <?php
	  get_pubuser(2,"tpladmin","0","+选择监控人员",50,4)
	  ?><br>注：是指可以监控此类别下公文的用户	  </td>
    </tr>
	
	<tr>
      <td nowrap class="TableContent" width="15%"> 流程说明：</td>
      <td class="TableData">
      <textarea id="content" cols="20" rows="2" class="ckeditor"  name="content"></textarea>	  </td>
    </tr>
	
    <tr align="center" class="TableControl">
      <td colspan="2" nowrap height="35">

		<input type="button" value="保存" class="BigButtonBHover" onClick="sendForm();">      </td>
    </tr>
  </table>
</form>

 
</body>
</html>
