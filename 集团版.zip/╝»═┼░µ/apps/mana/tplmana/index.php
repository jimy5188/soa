<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css"><title>Office 515158 2011 OA办公系统</title>
    <link href="apps/mana/tplmana/css/site.css?2023" rel="stylesheet" type="text/css" />
    <script type="text/javascript">
        var _root='http://form/index.php?s=/',_controller = 'index';
    </script>
</head>
<body class="body-wrap">

<div class="search_area">
        <table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
  <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	<?php echo $tpl['title'];?>
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	
	<button type="button" onClick="leipiFormDesign.exec('button_template');" class="btn btn-info">导入模板</button>
	 <button id="do_search" type="button" onClick="leipiFormDesign.exec('button_preview');" class="btn btn-success">在线预览</button>
	<button type="button" onClick="leipiFormDesign.exec('button_save');" action="cancel_concern" class="btn btn-danger">保存模板</button>
	</td>
  </tr>
</table>

<table width="95%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" style="border-top:1px dashed #CCCCCC;">
  <tr>
    <td width="400" align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold; padding-top:15px;">
	<button type="button" onClick="leipiFormDesign.exec('text',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">输入框</button>
	<button type="button" onClick="leipiFormDesign.exec('textarea',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">输入区</button>
	<button type="button" onClick="leipiFormDesign.exec('select',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">下拉菜单</button>
	<button type="button" onClick="leipiFormDesign.exec('radios',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">单选按钮</button>
	<button type="button" onClick="leipiFormDesign.exec('checkboxs',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">复选按钮</button>
	<button type="button" onClick="leipiFormDesign.exec('macros',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-info">流程控件</button>
	
	<button type="button" onClick="leipiFormDesign.exec('date',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-primary">日期</button>
	<button type="button" onClick="leipiFormDesign.exec('department',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-primary">部门</button>
	<button type="button" onClick="leipiFormDesign.exec('user',<?php echo $tplid;?>,<?php echo $tpltype;?>);" class="btn btn-primary">成员</button>
	</td>
  </tr>
</table>

</div>
<div  style="position:absolute; height:82%; width:100%;overflow:auto; padding-top:10px;">
<form name="tplform" method="post" action="admin.php?ac=tplhtml&fileurl=<?php echo $fileurl?>&tpltype=<?php echo $tpltype?>&tplid=<?php echo $tplid?>">
	<input type="hidden" name="content" id="content" value="" />
	<input type="hidden" name="type" id="type" value="save" />
	<input type="hidden" name="tpltype" value="<?php echo $tpltype?>" />
	<input type="hidden" name="tplid" value="<?php echo $tplid?>" />
	<input type="hidden" name="do" value="tplsave" />
	<?php if($tpladdr!=''){?>
	<input type="hidden" name="dbdata" value="save" />
    <?php }?>
</form>
<table class="TableBlock" border="0" width="95%" align="center">
	
	<tr>
      <td  colspan="2" align="center" valign="top">
	 <script id="myFormDesign" type="text/plain" style="width:100%;">
	 <?php echo $tpladdr;?>
	 </script></td>
	</tr>


  </table>
</div>
<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/jquery-1.7.2.min.js?2023"></script>

<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/ueditor/ueditor.config.js?2023"></script>
<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/ueditor/ueditor.all.js?2023"> </script>
<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/ueditor/lang/zh-cn/zh-cn.js?2023"></script>
<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/ueditor/formdesign/leipi.formdesign.v4.js?2023"></script>
<!-- script start-->  
<script type="text/javascript">
var leipiEditor = UE.getEditor('myFormDesign',{
            //allowDivTransToP: false,//阻止转换div 为p
            toolleipi:true,//是否显示，设计器的 toolbars
            textarea: 'design_content',   
            //这里可以选择自己需要的工具按钮名称,此处仅选择如下五个
           toolbars:[[
            'fullscreen', 'source', '|','bold', 'italic', 'underline', 'fontborder', 'strikethrough',  'removeformat', '|', 'forecolor', 'backcolor', 'insertorderedlist', 'insertunorderedlist','|', 'fontfamily', 'fontsize', '|', 'indent', '|', 'justifyleft', 'justifycenter', 'justifyright', 'justifyjustify', '|',   'horizontal',  'spechars',  '|', 'inserttable', 'deletetable',  'mergecells',  'splittocells']],
            //focus时自动清空初始化时的内容
            //autoClearinitialContent:true,
            //关闭字数统计
            wordCount:false,
            //关闭elementPath
            elementPathEnabled:false,
            //默认的编辑区域高度
            initialFrameHeight:300
            ///,iframeCssUrl:"css/bootstrap/css/bootstrap.css" //引入自身 css使编辑器兼容你网站css
            //更多其他参数，请参考ueditor.config.js中的配置项
        });

 var leipiFormDesign = {
    /*执行控件*/
    exec : function (method,tplid,tpltype) {
        leipiEditor.execCommand(method,tplid,tpltype);
    },
    /*
        Javascript 解析表单
        template 表单设计器里的Html内容
        fields 字段总数
    */

    fnCheckForm : function ( type ) {
        if(leipiEditor.queryCommandState( 'source' ))
            leipiEditor.execCommand('source');//切换到编辑模式才提交，否则有bug
            
        if(leipiEditor.hasContents()){
            leipiEditor.sync();/*同步内容*/
            var type_value='',formid=0,fields=$("#fields").val(),formeditor='';
            if( typeof type!=='undefined' ){
                type_value = type;
            }
            //获取表单设计器里的内容
            formeditor=leipiEditor.getContent();
            document.getElementById("content").value=formeditor;
            document.tplform.submit(); //提交表单
			alert('模板保存成功！');
			return false;
        } else {
            alert('表单内容不能为空！')
            $('#submitbtn').button('reset');
            return false;
        }
    } ,
    /*预览表单*/
    fnReview : function (){
        if(leipiEditor.queryCommandState( 'source' ))
            leipiEditor.execCommand('source');/*切换到编辑模式才提交，否则部分浏览器有bug*/
            
        if(leipiEditor.hasContents()){
            leipiEditor.sync();       /*同步内容*/
			formeditor=leipiEditor.getContent();
			document.getElementById("content").value=formeditor;
			document.getElementById("type").value='show';
            document.tplform.target="mywin";
            window.open('','mywin',"menubar=0,toolbar=0,status=0,resizable=1,left=0,top=0,scrollbars=1,width=" +(screen.availWidth-10) + ",height=" + (screen.availHeight-50) + "\"");

            //document.saveform.action="/index.php?s=/index/preview.html";
            document.tplform.submit(); //提交表单
			return false;
        } else {
            alert('表单内容不能为空！');
            return false;
        }
    }
};

</script>
</body>
</html>
