<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>文本框</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" >
	<link rel="stylesheet" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/bootstrap.css">
    <!--[if lte IE 6]>
    <link rel="stylesheet" type="text/css" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/bootstrap-ie6.css">
    <![endif]-->
    <!--[if lte IE 7]>
    <link rel="stylesheet" type="text/css" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/ie.css">
    <![endif]-->
    <link rel="stylesheet" href="apps/mana/tplmana/js/ueditor/formdesign/leipi.style.css">
    <script type="text/javascript" src="apps/mana/tplmana/js/ueditor/dialogs/internal.js"></script>
	<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/jquery-1.7.2.min.js?2023"></script>
    <script type="text/javascript">
/* Thank you by  
http://www.alt-tag.com/blog/2006/02/ie-dom-bugs/ */
function createElement(type, name)
{     
    var element = null;     
    try {        
        element = document.createElement('<'+type+' name="'+name+'">');     
    } catch (e) {}   
    if(element==null) {     
        element = document.createElement(type);     
        element.name = name;     
    } 
    return element;     
}
    </script>
</head>
<body>
<div class="content">

    <table class="table table-bordered table-striped table-hover">
<tr>
        <th><span>表单名称</span> <? get_helps()?></th>
        <th><span>默认值</span> </th>
    </tr>
	
    <tr>
        <td><input type="text" id="fromname" name="fromname" value="<?php echo $row['fromname'];?>"></td>
        <td> <input type="text" id="inputvalue" name="inputvalue" value="<?php echo $row['inputvalue'];?>"></td>
    </tr>
    
    <tr>
        <th><span>表单宽高</span> </th>
        <th><span>验证方式</span> </th>
    </tr>
    <tr>
        <td>
           宽:<input type="text" name="w" id="w" style="width:40px;" onKeyUp="value=value.replace(/[^0-9]/g,'');" value="<?php echo $row['w'];?>" /> px;&nbsp;&nbsp;&nbsp;&nbsp;高:<input type="text" name="h" id="h" style="width:40px;"  value="<?php echo $row['h'];?>" onKeyUp="value=value.replace(/[^0-9]/g,'');"/> px;

        </td>
        <td>
           <input name="confirmation" id="confirmation" type="radio" value="1"  <?php if($row['confirmation']==1){?>checked="checked"<?php }?>/>
	  是
      <input name="confirmation" type="radio" id="confirmation" value="2"  <?php if($row['confirmation']==2){?>checked="checked"<?php }?>/>
      否
	  <br>注：选择"是"表示该项为必填项
        </td>
    </tr>
    </table>
</div>
<script type="text/javascript">          
var oNode = null,thePlugins = 'text';
window.onload = function() {
    if( UE.plugins[thePlugins].editdom ){
        oNode = UE.plugins[thePlugins].editdom;
    }
}
dialog.oncancel = function () {
    if( UE.plugins[thePlugins].editdom ) {
        delete UE.plugins[thePlugins].editdom;
    }
};
function radio(obj){
	for(var i=0; i<obj.length; i ++){
        if(obj[i].checked){
           // alert(obj[i].value);
			return obj[i].value;
        }
    }

}
dialog.onok = function (){
    if($G('fromname').value==''){
        alert('请输入控件名称');
        return false;
    }
	if($G('w').value==''){
        alert('请输入宽');
        return false;
    }
	if($G('h').value==''){
        alert('请输入高');
        return false;
    }
    var fromname=$G('fromname').value.replace(/\"/g,"&quot;");
	var inputvalue=$G('inputvalue').value;
	var confirmation=radio(document.getElementsByName("confirmation"));
	var w=$G('w').value;
	var h=$G('h').value;
    if( !oNode ) {
        try {
			jQuery.ajax({
			  type: 'GET',
			  url: 'admin.php?ac=tplhtml&fileurl=apps&tplid=<?php echo $tplid;?>&tpltype=<?php echo $tpltype;?>&fromid=<?php echo $fromid;?>&do=addsave&type=text&fromname='+encodeURI(fromname)+'&dbtype=1&inputvalue='+encodeURI(inputvalue)+'&confirmation='+confirmation+'&w='+w+'&h='+h+'&date='+new Date(),
			  success: function(data){
				  if(data!=''){
				  	//alert(data);
				  }
			  }
		   });
			//添加控件执行块
            oNode = createElement('input','leipiNewField');
            oNode.setAttribute('type','text');
            oNode.setAttribute('title',fromname);
            oNode.setAttribute('value',inputvalue);
            oNode.setAttribute('name','<?php echo $row['inputname'];?>');
			oNode.setAttribute('tplid','<?php echo $tplid;?>');
			oNode.setAttribute('tpltype','<?php echo $tpltype;?>');
            oNode.setAttribute('leipiPlugins',thePlugins);
			oNode.setAttribute('fromid',<?php echo $row['fromid'];?>);
			if(w!='' && h!=''){
				oNode.setAttribute('style','width:'+w+'px;height:'+h+'px;');
			}
            editor.execCommand('insertHtml',oNode.outerHTML);
        } catch (e) {
            try {
                editor.execCommand('error');
            } catch ( e ) {
                alert('控件异常！');
            }
            return false;
        }
    } else {
        //修改控件执行块
        jQuery.ajax({
			  type: 'GET',
			  url: 'admin.php?ac=tplhtml&fileurl=apps&tplid=<?php echo $tplid;?>&tpltype=<?php echo $tpltype;?>&fromid=<?php echo $fromid;?>&do=addsave&type=text&fromname='+encodeURI(fromname)+'&dbtype=1&inputvalue='+encodeURI(inputvalue)+'&confirmation='+confirmation+'&w='+w+'&h='+h+'&date='+new Date(),
			  success: function(data){
				  if(data!=''){
				  	//alert(data);
				  }
			  }
		   });
            oNode.setAttribute('type','text');
            oNode.setAttribute('title',fromname);
            oNode.setAttribute('value',inputvalue);
            oNode.setAttribute('name','<?php echo $row['inputname'];?>');
			oNode.setAttribute('tplid','<?php echo $tplid;?>');
			oNode.setAttribute('tpltype','<?php echo $tpltype;?>');
            oNode.setAttribute('leipiPlugins',thePlugins);
			oNode.setAttribute('fromid',<?php echo $row['fromid'];?>);
			if(w!='' && h!=''){
				oNode.setAttribute('style','width:'+w+'px;height:'+h+'px;');
			}
            delete UE.plugins[thePlugins].editdom;
    }
};
</script>
</body>
</html>