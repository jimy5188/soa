<!DOCTYPE HTML>
<html>
<head>
    <title>表单模板</title>
    <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" >
    <script type="text/javascript" src="../dialogs/internal.js"></script>
    <style type="text/css">
.wrap{ padding: 5px;font-size: 14px;}
.left{width:425px;float: left;}
.right{width:160px;border: 1px solid #ccc;float: right;padding: 5px;margin-right: 5px;}
.right .pre{height: 332px;overflow-y: auto;}
.right .preitem{border: white 1px solid;margin: 5px 0;padding: 2px 0;}
.right .preitem:hover{background-color: lemonChiffon;cursor: pointer;border: #ccc 1px solid;}
.right .preitem img{display: block;margin: 0 auto;width:100px;}
.clear{clear: both;}
.top{height:26px;line-height: 26px;padding: 5px;}
.bottom{height:320px;width:100%;margin: 0 auto;}
.transparent{ background: url("template/images/bg.gif") repeat;}
.bottom table tr td{border:1px dashed #ccc;}
#colorPicker{width: 17px;height: 17px;border: 1px solid #CCC;display: inline-block;border-radius: 3px;box-shadow: 2px 2px 5px #D3D6DA;}
.border_style1{padding:2px;border: 1px solid #ccc;border-radius: 5px;box-shadow:2px 2px 5px #d3d6da;}
p{margin: 5px 0}
table{clear:both;margin-bottom:10px;border-collapse:collapse;word-break:break-all;}
li{clear:both}
ol{padding-left:40px; }
    </style>

</head>
<body>
<?php
include_once('tpl/t1.php');
include_once('tpl/t2.php');
include_once('tpl/t3.php');
include_once('tpl/t4.php');
include_once('tpl/t5.php');
include_once('tpl/t6.php');
?>
    <div class="wrap">
        <div class="left">
            <div class="top">
                <label><var id="lang_template_clear">保留原有内容</var>：<input id="issave" type="checkbox"></label>
            </div>
            <div class="bottom border_style1" id="preview"></div>
        </div>
        <fieldset  class="right border_style1">
            <legend><var id="lang_template_select"></var></legend>
            <div class="pre" id="preitem"></div>
        </fieldset>
        <div class="clear"></div>
    </div>
    <script type="text/javascript">
/**
* Templates.
* 添加模板，以下面配置即可
*/
var templates = [
    {
        "pre":"pre0.png",//预览图
        'title':"市委办公室收文审批单",//标题
        //预览html
        'preHtml':'<img src="images/template/t0.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html1;?>'
    },{
        "pre":"pre1.png",//预览图
        'title':"市委办公室发文呈批单",//标题
        //预览html
        'preHtml':'<img src="images/template/t1.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html2;?>'
    },{
        "pre":"pre2.png",//预览图
        'title':"住房和城乡建设局文件处理笺",//标题
        //预览html
        'preHtml':'<img src="images/template/t2.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html3;?>'
    },{
        "pre":"pre3.png",//预览图
        'title':"教育局发文审批单",//标题
        //预览html
        'preHtml':'<img src="images/template/t3.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html4;?>'
    },{
        "pre":"pre4.png",//预览图
        'title':"市质量技术监督局发文（电）稿件",//标题
        //预览html
        'preHtml':'<img src="images/template/t4.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html5;?>'
    },{
        "pre":"pre5.png",//预览图
        'title':"市质量技术监督局文件处理单",//标题
        //预览html
        'preHtml':'<img src="images/template/t5.jpg" width="400" height="300" />',
        //确认后到编辑器的html
        "html":'<?php echo $html6;?>'
    }
];

/**
 *  Templates.
 */
(function () {
    var me = editor,
            preview = $G( "preview" ),
            preitem = $G( "preitem" ),
            tmps = templates,
            currentTmp;
    var initPre = function () {
        var str = "";
        for ( var i = 0, tmp; tmp = tmps[i++]; ) {
            str += '<div class="preitem" onclick="pre(' + i + ')"><img src="' + "images/template/" + tmp.pre + '" ' + (tmp.title ? "alt=" + tmp.title + " title=" + tmp.title + "" : "") + '></div>';
        }
        preitem.innerHTML = str;
    };
    var pre = function ( n ) {
        var tmp = tmps[n - 1];
        currentTmp = tmp;
        clearItem();
        domUtils.setStyles( preitem.childNodes[n - 1], {
            "background-color":"lemonChiffon",
            "border":"#ccc 1px solid"
        } );
        preview.innerHTML = tmp.preHtml ? tmp.preHtml : "";
    };
    var clearItem = function () {
        var items = preitem.children;
        for ( var i = 0, item; item = items[i++]; ) {
            domUtils.setStyles( item, {
                "background-color":"",
                "border":"white 1px solid"
            } );
        }
    };
    dialog.onok = function () {
        if ( !$G( "issave" ).checked ){
            me.execCommand( "cleardoc" );
        }
        var obj = {
            html:currentTmp && currentTmp.html
        };
        me.execCommand( "template", obj );
    };
    initPre();
    window.pre = pre;
    pre(2)

})();
    </script>
</body>
</html>
