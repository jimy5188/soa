<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
    <title>成员控件</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" >
    <link rel="stylesheet" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/bootstrap.css">
    <!--[if lte IE 6]>
    <link rel="stylesheet" type="text/css" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/bootstrap-ie6.css">
    <![endif]-->
    <!--[if lte IE 7]>
    <link rel="stylesheet" type="text/css" href="apps/mana/tplmana/js/ueditor/formdesign/bootstrap/css/ie.css">
    <![endif]-->
    <link rel="stylesheet" href="apps/mana/tplmana/js/ueditor/formdesign/leipi.style.css">
    <script type="text/javascript" src="apps/mana/tplmana/js/ueditor/dialogs/internal.js"></script>
	<script type="text/javascript" charset="utf-8" src="apps/mana/tplmana/js/jquery-1.7.2.min.js?2023"></script>
    <script type="text/javascript">
function createElement(type, name)
{     
    var element = null;     
    try {        
        element = document.createElement('<'+type+' name="'+name+'">');     
    } catch (e) {}   
    if(element==null) {     
        element = document.createElement(type);     
        element.name = name;     
    } 
    return element;     
}
    </script>
</head>
<body>
<div class="content">
    <table class="table table-bordered table-striped table-hover">
    <thead>
        <tr>
            <th><span>控件名称</span><span class="label label-important">*</span></th>
        </tr>
        <tr>
            <td>
                <input type="text" id="fromname" name="fromname" value="<?php echo $row['fromname'];?>">            </td>
        </tr>
    </thead>
    <tbody id='itemAttr'>
        <tr>
            <th><span>控件样式</span></th>
        </tr>
        <tr>
            <td>
                宽:<input type="text" name="w" id="w" style="width:40px;" onKeyUp="value=value.replace(/[^0-9]/g,'');" value="<?php echo $row['w'];?>" /> px;&nbsp;&nbsp;&nbsp;&nbsp;高:<input type="text" name="h" id="h" style="width:40px;"  value="<?php echo $row['h'];?>" onKeyUp="value=value.replace(/[^0-9]/g,'');"/> px;            </td>
        </tr>
    </tbody>
    </table>
</div>
<script type="text/javascript">
var oNode = null,thePlugins = 'user';
window.onload = function() {
    if( UE.plugins[thePlugins].editdom ) {
        oNode = UE.plugins[thePlugins].editdom;
	}
}

dialog.oncancel = function () {
    if( UE.plugins[thePlugins].editdom ) {
        delete UE.plugins[thePlugins].editdom;
    }
};
dialog.onok = function (){
    if ( $G('fromname').value == '' ) {
        alert('控件名称不能为空');
        return false;
    }
    var fromname=$G('fromname').value.replace(/\"/g,"&quot;");
	var w=$G('w').value;
	var h=$G('h').value;
    if( !oNode ) {
        try {
				jQuery.ajax({
				  type: 'GET',
				  url: 'admin.php?ac=tplhtml&fileurl=apps&tplid=<?php echo $tplid;?>&tpltype=<?php echo $tpltype;?>&fromid=<?php echo $fromid;?>&do=addsave&type=user&fromname='+encodeURI(fromname)+'&dbtype=1&confirmation=2&w='+w+'&h='+h+'&date='+new Date(),
				  success: function(data){
					  if(data!=''){
						//alert(data);
					  }
				  }
			   });
                oNode = createElement('input','leipiNewField');
                oNode.setAttribute('type','text');
                oNode.setAttribute('title',fromname);
                oNode.setAttribute('name','<?php echo $row['inputname'];?>');
                oNode.setAttribute('tplid','<?php echo $tplid;?>');
				oNode.setAttribute('tpltype','<?php echo $tpltype;?>');
				oNode.setAttribute('value','{成员控件<?php echo $row['inputname'];?>}');
				oNode.setAttribute('leipiPlugins',thePlugins);
				oNode.setAttribute('fromid',<?php echo $row['fromid'];?>);
				if(w!='' && h!=''){
					oNode.setAttribute('style','width:'+w+'px;height:'+h+'px;');
				}
                editor.execCommand('insertHtml',oNode.outerHTML);
                return true;
            } catch ( e ) {
                try {
                    editor.execCommand('error');
                } catch ( e ) {
                    alert('控件异常！');
                }
                return false;
            }
    } else {
        var oNewNode = null;
        domUtils.remove(oNode,false);  //删除当前控件，再创建一个新的
        jQuery.ajax({
				  type: 'GET',
				  url: 'admin.php?ac=tplhtml&fileurl=apps&tplid=<?php echo $tplid;?>&tpltype=<?php echo $tpltype;?>&fromid=<?php echo $fromid;?>&do=addsave&type=user&fromname='+encodeURI(fromname)+'&dbtype=1&confirmation=2&w='+w+'&h='+h+'&date='+new Date(),
				  success: function(data){
					  if(data!=''){
						//alert(data);
					  }
				  }
			   });
                oNewNode = createElement('input','leipiNewField');
                oNewNode.setAttribute('type','text');
                oNewNode.setAttribute('title',fromname);
                oNewNode.setAttribute('name','<?php echo $row['inputname'];?>');
                oNewNode.setAttribute('tplid','<?php echo $tplid;?>');
				oNewNode.setAttribute('tpltype','<?php echo $tpltype;?>');
				oNewNode.setAttribute('value','{成员控件<?php echo $row['inputname'];?>}');
				oNewNode.setAttribute('leipiPlugins',thePlugins);
				oNewNode.setAttribute('fromid',<?php echo $row['fromid'];?>);
				if(w!='' && h!=''){
					oNewNode.setAttribute('style','width:'+w+'px;height:'+h+'px;');
				}
        editor.execCommand('insertHtml',oNewNode.outerHTML);
        delete UE.plugins[thePlugins].editdom;
    }
};
</script>
</body>
</html>
