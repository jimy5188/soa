<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->

 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="template/default/js/jquery.min.js"></script>
<script language="javascript" type="text/javascript" src="template/default/content/js/common.js"></script>
<script type="text/javascript">
	function active(type){
		if(type!=''){
			for(var i=1;i<=5;i++){
				document.getElementById('flow_'+i).className = '';
			}
			document.getElementById(type).className = 'active'; 
		}
	}
	function checkbox(value,type){
		if(value=='0'){
			for(var i=1;i<=10;i++){
				$("#div"+i).hide();
			}
		}else{
			if(value>=4){
				$("#div4").hide();
				$("#div5").hide();
				$("#div6").hide();
				$("#div7").hide();
			}
			if(value==2){
				if(type==1){
					$("#div11").hide();
				}else{
					$("#div11").show();
				}
			}
			if(type==1){
				$("#div"+value).show();
			}else{
				$("#div"+value).hide();
			}
		}
	}
</script>

</head>

<body class="body-wrap">
<div class="tabbable work-nav"> 
				<ul id="myTab" class="nav nav-tabs">
					<li class="active" id="flow_1"><a href="#flow_1s" onClick="active('flow_1');">常规信息</a></li>
					<li id="flow_2"><a href="#flow_2s" onClick="active('flow_2');">表单权限</a></li>
					<li id="flow_3"><a href="#flow_3s" onClick="active('flow_3');">人员设定</a></li>
					<li id="flow_4"><a href="#flow_4s" onClick="active('flow_4');">流程转向</a></li>
					<li id="flow_5"><a href="#flow_5s" onClick="active('flow_5');">超时处理</a></li>
					
				</ul>
</div>
			
<div class="search_area">
        <table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small">
  <tr>
    <td align="left" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">
	 第<span style="font-size:18px; font-weight:bold; color:#FF0000;"><?php echo $flownum;?></span>步流程设置
	</td>
	<td align="right" class="Big" style="font-size:16px; color:#009900; font-weight:bold;">

	<button type="button" onClick="sendForm();" class="btn btn-danger">保存步骤</button>&nbsp;&nbsp;&nbsp;&nbsp;<button id="do_search" type="button" onClick="javascript:window.location='admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&tplid=<?php echo $tplid?>&tpltype=<?php echo $tpltype?>'" class="btn btn-success"><<返回</button>
	</td>
  </tr>
</table>
</div>
<script Language="JavaScript"> 
function CheckForm()
{	
   if(document.save.flowname.value=="")
   { alert("流程名称不能为空！");
     document.save.flowname.focus();
     return (false);
   }
   return true;
}
function sendForm()
{
   if(CheckForm())
      document.save.submit();
}

window.onload = function (){
	checkbox(0);
	<?php if($user['flowkey2']=='1'){?>
		$("#div2").show();
		$("#div11").hide();
	<?php }?>
	<?php if($user['flowdatetype']=='1'){?>
		$("#div3").show();
	<?php }?>
	<?php if($user['flowusertype']==''){?>
		$("#div4").show();
	<?php }else{?>
		$("#div<?php echo trim($user['flowusertype'])+3;?>").show();
	<?php }?>
}



</script>

<div  style="position:absolute; height:80%; width:100%;overflow:auto; ">
<form name="save" method="post" action="?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=add&tplid=<?php echo $tplid?>&typeid=<?php echo $typeid?>">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="fid" value="<?php echo $user['fid']?>" />
	<input type="hidden" name="modid" value="<?php echo $modid?>" />
<input type="hidden" name="flownum" value="<?php echo $flownum?>" />
<table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" id="flow_1s">
  <tr>
    <td class="Big" height="50"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">常规信息</span>
    </td>
  </tr>
</table>

<table class="TableBlock" border="0" width="70%" align="center" style="border-bottom:#4686c6 solid 0px;">
		<tr>
			<td nowrap class="TableContent" width="100">流程名称：<? get_helps()?></td>
			  <td class="TableData">
					<input type="text" class="BigInput" name="flowname" value="<?php echo $user['flowname']?>" size=30 >		  </td>  	  	
		</tr>
		
		
		<tr>
			<td nowrap class="TableContent" width="100">流程类型：</td>
		  <td class="TableData">
			
			<input name="flowkey" type="radio" style="border:0;" value="1" <? if($user['flowkey']=='1'){?>checked="checked"<? }?> />
			转交下一步
			<input name="flowkey" type="radio" style="border:0;" value="2" <? if($user['flowkey']=='2'){?>checked="checked"<? }?> />
			流程结束
			
        </td>  	  	
		</tr>
		
		<tr>
			<td nowrap class="TableContent" width="100">公文节点：</td>
		  <td class="TableData">
			
			<input name="flowtype" type="radio" style="border:0;" value="0" <? if($user['flowtype']=='0'){?>checked="checked"<? }?> />
      正常
	 <input name="flowtype" type="radio" style="border:0;" value="1" <? if($user['flowtype']=='1'){?>checked="checked"<? }?> />
      文件传阅
	  <input name="flowtype" type="radio" style="border:0;" value="2" <? if($user['flowtype']=='2'){?>checked="checked"<? }?> />
      文件分发
	  <input name="flowtype" type="radio" style="border:0;" value="3" <? if($user['flowtype']=='3'){?>checked="checked"<? }?> />
      归档
			
        </td>  	  	
		</tr>
		</table>
	   <div id="div11">
	   <table class="TableBlock" border="0" width="70%" align="center" style="border-top:#4686c6 solid 0px;">
		<tr>
			<td nowrap class="TableContent" width="100">流程控制：</td>
		  <td class="TableData">
		  	<?php
			$flowkey8=explode('|',$user['flowkey8']);
			?>
			<input name="flowkey8_1" type="checkbox" value="1" <?php if($flowkey8[0]==1){?>checked<?php }?> />
			允许会签
			<input type="checkbox" name="flowkey8_2" value="1" <?php if($flowkey8[1]==1){?>checked<?php }?> />允许委托
			<input type="checkbox" name="flowkey8_3" value="1" <?php if($flowkey8[2]==1){?>checked<?php }?> />允许挂起
			<!--<input type="checkbox" name="flowkey8_4" value="1" <?php if($flowkey8[3]==1){?>checked<?php }?> />允许收回 -->
        </td>  	  	
		</tr>
		</table>
	   
		</div>
		<table class="TableBlock" border="0" width="70%" align="center" style="border-top:#4686c6 solid 0px;">
		<?php if($flownum>1){?>
		
	    <tr>
			<td nowrap class="TableContent" width="100">审批状态：</td>
			  <td class="TableData">
	 <input name="flowkey2" type="radio" style="border:0;" onClick="checkbox(2,1);" value="1" <? if($user['flowkey2']=='1'){?>checked="checked"<? }?> />
      多人审批
			<input name="flowkey2" type="radio" onClick="checkbox(2,0);" style="border:0;" value="2" <? if($user['flowkey2']=='2'){?>checked="checked"<? }?> />
			单人审批
			
	  </td>  	  	
      </tr>
  </table>
	   <div id="div2">
	   <table class="TableBlock" border="0" width="70%" align="center" style="border-top:#4686c6 solid 0px;">
		<tr >
      <td nowrap class="TableContent" width="100"> 审批关系：</td>
      <td class="TableData">
	  <input name="flowkey3" type="radio" style="border:0;" value="1" <? if($user['flowkey3']=='1'){?>checked="checked"<? }?> />
      同时通过
			<input name="flowkey3" type="radio" style="border:0;" value="2" <? if($user['flowkey3']=='2'){?>checked="checked"<? }?> />
			一人通过
		<br><font color="#868788">
		同时通过：在多人审批时有效，选择此项表示多个同时同意后流程转到下一步<br>
		一人通过：只要其中一人通过，流程转向下一步；
		</font>
      </td>
    </tr>
	
	</table>
</div>
<?php }else{?>
</table>
<?php }?>	
<table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" id="flow_2s">
  <tr>
    <td class="Big" height="50"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">表单权限</span>
    </td>
  </tr>
</table>
  <table class="TableBlock" border="0" width="70%" align="center">
	<tr>
      <td nowrap class="TableHeader" width="80"><input type="checkbox" class="checkbox" value="1" name="chkall" onClick="check_allflow(this)" /></td>
      <td  class="TableHeader">表单名称</td>
      <td width="120" align="center" class="TableHeader">表单类型</td>
      
    </tr>
    <?php 
		  
		  $sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from WHERE tplid='".$user['tplid']."'  and inputtype<6 ORDER BY fromid asc";
		  $result = $db->fetch_all($sql);
		  foreach ($result as $form) {
		  if(sizeof(explode('"'.$form['inputname'].'"',$user['formkey']))>1){
			$html= ' checked="checked"';
		  }else{
		  	$html='';
		  }
		  ?>
	<tr>
      <td nowrap class="TableContent" width="5%">
	  
	  <input type="checkbox" class="checkbox" name="formkey[]" value="<?php echo $form['inputname']?>" <?php echo $html;?>/>
</td>
      <td class="TableData"><?php echo $form['fromname']?></td>
	  
	  <td align="center" class="TableData">
	  <?php
	  if($form['inputtype']==0){
		  if($form['inputtype1']==1){
			  echo '输入框';
		  }elseif($form['inputtype1']==2){
			  echo '输入区';
		  }elseif($form['inputtype1']==3){
			  echo '单选';
		  }elseif($form['inputtype1']==4){
			  echo '复选';
		  }elseif($form['inputtype1']==5){
			  echo '下拉';
		  }
	  }elseif($form['inputtype']==1){
		   echo '图片';
	  }elseif($form['inputtype']==2){
		   echo '附件';
	  }elseif($form['inputtype']==3){
		   echo '日期';
	  }elseif($form['inputtype']==4){
		   echo '部门';
	  }elseif($form['inputtype']==5){
		   echo '成员';
	  }elseif($form['inputtype']==7){
		   echo '宏控件';
	  }?></td>
      
    </tr>
	
	<?php }?>

  </table>
  
  
 
 <?php if($flownum>1){?>
 <table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" id="flow_3s">
  <tr>
    <td class="Big" height="50"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">人员设定</span>
    </td>
  </tr>
</table>
  <table class="TableBlock" border="0" width="70%" align="center" >
	<tr>
			<td nowrap class="TableContent" width="100">设定范围：<? get_helps()?></td>
			  <td class="TableData">
			  <input name="flowusertype" type="radio" style="border:0;" value="1" <? if($user['flowusertype']=='1'){?>checked="checked"<? }?> onClick="checkbox(4,1);" />
      指定人员
			<input name="flowusertype" type="radio" style="border:0;" value="2" <? if($user['flowusertype']=='2'){?>checked="checked"<? }?> onClick="checkbox(5,1);" />
			指定岗位
			<input name="flowusertype" type="radio" style="border:0;" value="3" <? if($user['flowusertype']=='3'){?>checked="checked"<? }?> onClick="checkbox(6,1);" />
			指定部门
			<input name="flowusertype" type="radio" style="border:0;" value="4" <? if($user['flowusertype']=='4'){?>checked="checked"<? }?> onClick="checkbox(7,1);" />
			办理人部门<br>
	<div id="div4">
	  <?php
	  if($user['flowusertype']=='1'){
		  $flowuser1=$user['flowuser'];
	  }elseif($user['flowusertype']=='2'){
	  	  $flowuser2=$user['flowuser'];
	  }elseif($user['flowusertype']=='3'){
	  	  $flowuser3=$user['flowuser'];
	  }
	  get_pubuser(2,"flowuser1",$flowuser1,"+选择审批人员",50,3)
	  ?><br><font color="#868788">注：在工作流审批时，有权限操作该节点的工作人员，不设定时请留空</font>
	  </div>
	  <div id="div5">
	  <?php
	  get_positionbox(2,'flowuser2',get_postname($flowuser2),'+选择岗位',$width=50,$height=3);
	  ?><br><font color="#868788">注：在工作流审批时，以岗位来设定成员，不可为空</font>
	  </div>
	  <div id="div6">
	  <?php
	  get_depabox(2,'flowuser3',get_realdepaname($flowuser3),'+选择部门',$width=50,$height=3);
	  ?><br><font color="#868788">注：是指允许使用此模型的人员，以部门来设定成员，不可为空</font>
	  </div>
	  <div id="div7">
	  	<font color="#868788">注：选择此项，节点人员为当前审批人的部门内人员</font>
	  </div>
	  <font color="red">注：当需要手动选人时，则设定范围生效</font>
	  </td>  	  	
	   </tr>
	   
	   <tr>
      <td nowrap class="TableContent"> 自动选人：</td>
      <td class="TableData">
	  <input name="flowkey7" type="radio" style="border:0;" value="0" <? if($user['flowkey7']=='0'){?>checked="checked"<? }?> />
      不自动选人<br>
	  <input name="flowkey7" type="radio" style="border:0;" value="1" <? if($user['flowkey7']=='1'){?>checked="checked"<? }?> />
      发起人
	  <input name="flowkey7" type="radio" style="border:0;" value="2" <? if($user['flowkey7']=='2'){?>checked="checked"<? }?> />
      发起人部门主管
	  <input name="flowkey7" type="radio" style="border:0;" value="3" <? if($user['flowkey7']=='3'){?>checked="checked"<? }?> />
      发起人部门助理
	  <input name="flowkey7" type="radio" style="border:0;" value="4" <? if($user['flowkey7']=='4'){?>checked="checked"<? }?> />
      发起人部门分管领导
	  <input name="flowkey7" type="radio" style="border:0;" value="5" <? if($user['flowkey7']=='5'){?>checked="checked"<? }?> />
      发起人部门主管领导<br>
	  <input name="flowkey7" type="radio" style="border:0;" value="6" <? if($user['flowkey7']=='6'){?>checked="checked"<? }?> />
      办理人
	  <input name="flowkey7" type="radio" style="border:0;" value="7" <? if($user['flowkey7']=='7'){?>checked="checked"<? }?> />
      办理人部门主管
	  <input name="flowkey7" type="radio" style="border:0;" value="8" <? if($user['flowkey7']=='8'){?>checked="checked"<? }?> />
      办理人部门助理
	  <input name="flowkey7" type="radio" style="border:0;" value="9" <? if($user['flowkey7']=='9'){?>checked="checked"<? }?> />
      办理人部门分管领导
	  <input name="flowkey7" type="radio" style="border:0;" value="10" <? if($user['flowkey7']=='10'){?>checked="checked"<? }?> />
      办理人部门主管领导
	  <br>
	  <input name="flowkey7" type="radio" style="border:0;" value="11" <? if($user['flowkey7']=='11'){?>checked="checked"<? }?> />
      指定部门主管
	  <input name="flowkey7" type="radio" style="border:0;" value="12" <? if($user['flowkey7']=='12'){?>checked="checked"<? }?> />
      指定部门助理
	  <input name="flowkey7" type="radio" style="border:0;" value="13" <? if($user['flowkey7']=='13'){?>checked="checked"<? }?> />
      指定部门分管领导
	  <input name="flowkey7" type="radio" style="border:0;" value="14" <? if($user['flowkey7']=='14'){?>checked="checked"<? }?> />
      指定部门主管领导<br>
	  <input name="flowkey7" type="radio" style="border:0;" value="15" <? if($user['flowkey7']=='15'){?>checked="checked"<? }?> />
      办理人上级部门主管
	  <input name="flowkey7" type="radio" style="border:0;" value="16" <? if($user['flowkey7']=='16'){?>checked="checked"<? }?> />
      办理人上级部门助理
	  <input name="flowkey7" type="radio" style="border:0;" value="17" <? if($user['flowkey7']=='17'){?>checked="checked"<? }?> />
      办理人上级部门分管领导
	  <input name="flowkey7" type="radio" style="border:0;" value="18" <? if($user['flowkey7']=='18'){?>checked="checked"<? }?> />
      办理人上级部门主管领导
	  <br>
	  <input name="flowkey7" type="radio" style="border:0;" value="19" <? if($user['flowkey7']=='19'){?>checked="checked"<? }?> />
      发起人部门所有领导
	  <input name="flowkey7" type="radio" style="border:0;" value="20" <? if($user['flowkey7']=='20'){?>checked="checked"<? }?> />
      办理人部门所有领导
	  <input name="flowkey7" type="radio" style="border:0;" value="21" <? if($user['flowkey7']=='21'){?>checked="checked"<? }?> />
      指定部门所有领导
	  <input name="flowkey7" type="radio" style="border:0;" value="22" <? if($user['flowkey7']=='22'){?>checked="checked"<? }?> />
      办理人上级部门所有领导
		<br><font color="#868788">预先设置自动选人，更方便转交工作</font>	
      </td>
    </tr>
	   
	   
		<tr>
      <td nowrap class="TableContent"> 选择方式：</td>
      <td class="TableData">
	  <input name="flowkey1" type="radio" style="border:0;" value="1" <? if($user['flowkey1']=='1'){?>checked="checked"<? }?> />
      可选所有人员
	  <input name="flowkey1" type="radio" style="border:0;" value="2" <? if($user['flowkey1']=='2'){?>checked="checked"<? }?> />
	 条件内人员可选
	 <input name="flowkey1" type="radio" style="border:0;" value="3" <? if($user['flowkey1']=='3'){?>checked="checked"<? }?> />
	 人员不可选
		<br><font color="red">注：<br>可选所有人员:指条件设定后，该节点可以再次从所有人中选人<br>条件内人员可选:指在满足条件情况设定下的人员可选<br>人员不可选:人员以条件设定为准，不可选择，单人审批自动截取首位人员，多人审批为所有条件设定人员</font>	
      </td>
    </tr>
	

	
</table>
<?php }?>

<table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" id="flow_4s">
  <tr>
    <td class="Big" height="50"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">流程转向</span>
    </td>
  </tr>
</table>
  <table class="TableBlock" border="0" width="70%" align="center" >
	<tr >
      <td nowrap class="TableContent" width=100> 流程回退：</td>
      <td class="TableData">
	  <?php
	  $sqlu = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid = '".$tplid."' and flownum<".$flownum." order by fid asc";
	  $results = $db->query($sqlu);
	  while ($upfid = $db->fetch_array($results)) {	
		  echo '<input name="flowkey4[]" type="checkbox" style="border:0;" value="'.$upfid['fid'].'"';
		  if(sizeof(explode($upfid['fid'].',',$user['flowkey4']))>1){
			  echo 'checked="checked" ';
		  }
		  echo ' />第'.$upfid['flownum'].'步:'.$upfid['flowname'];
	  }
	  ?>
	  
	  
		<br><font color="#868788">
		选择该流程可退回的步骤
		</font>
      </td>
    </tr>
	<tr >
      <td nowrap class="TableContent" width=100> 流程跳转：</td>
      <td class="TableData">
	  <?php
	  $sqlu = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid = '".$tplid."' and flownum!=1 and fid!='".$user['fid']."' order by fid asc";
	  $results = $db->query($sqlu);
	  while ($upfid = $db->fetch_array($results)) {	
		  echo '<input name="flowkey6[]" type="checkbox" style="border:0;" value="'.$upfid['fid'].'"';
		  if(sizeof(explode($upfid['fid'].',',$user['flowkey6']))>1){
			  echo 'checked="checked" ';
		  }
		  echo ' />第'.$upfid['flownum'].'步:'.$upfid['flowname'];
	  }
	  ?>
	  
	  
		<br><font color="#868788">
		选择该流程可跳转的步骤
		</font>
      </td>
    </tr>
	<?php if($flownum>1){?>
	<tr >
      <td nowrap class="TableContent" width=100> 条件流转：</td>
      <td class="TableData">
	  当<select name="flowkey5_from">
	  	<option value="0" selected="selected">不使用条件流</option>
	  <?php
	  $flowkey5=explode('|',$user['flowkey5']); 
	  $sqlu = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from WHERE tplid='".$user['tplid']."'  and (inputtype=3 or inputtype=4 or inputtype=5 or inputtype1=1 or inputtype1=3 or inputtype1=4 or inputtype1=5) ORDER BY fromid asc";
	  $results = $db->query($sqlu);
	  while ($upfid = $db->fetch_array($results)) {	
	  ?>
		<option value="<?php echo $upfid['inputname'];?>" <?php if(trim($flowkey5[0])==trim($upfid['inputname'])){?>selected="selected"<?php }?>><?php echo $upfid['fromname'];?></option>  
     <?php
	  }
	  ?>
	  </select>
	  <select name="flowkey5_if" style="width:120px;">
	  	<option value="0" selected="selected"></option>
		<option value=">=" <?php if(trim($flowkey5[1])=='>='){?>selected="selected"<?php }?>>(>=)大于等于</option>
		<option value="<=" <?php if(trim($flowkey5[1])=='<='){?>selected="selected"<?php }?>>(<=)小于等于</option>
		<option value="==" <?php if(trim($flowkey5[1])=='=='){?>selected="selected"<?php }?>>(==)等于</option>
		<option value="!=" <?php if(trim($flowkey5[1])=='!='){?>selected="selected"<?php }?>>(!=)不等于</option>
		<option value=">" <?php if(trim($flowkey5[1])=='>'){?>selected="selected"<?php }?>>(>)大于</option>
		<option value="<" <?php if(trim($flowkey5[1])=='<'){?>selected="selected"<?php }?>>(<)小于</option>
	  </select>
	  <input type="text" class="BigInput" name="flowkey5_value" value="<?php echo $flowkey5[2];?>" style="width:80px;">
		执行
		<select name="flowkey5_end" style="width:120px;">
	  	<option value="0" selected="selected"></option>
		<option value="1" <?php if(trim($flowkey5[3])=='1'){?>selected="selected"<?php }?>>跳过此步骤</option>
		<option value="2" <?php if(trim($flowkey5[3])=='2'){?>selected="selected"<?php }?>>强制结束流程</option>
	  </select>
      </td>
    </tr>
	<?php }?>
	
</table>



  
 <?php if($flownum>1){?> 
 <table width="70%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" id="flow_5s">
  <tr>
    <td class="Big" height="50"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">超时处理</span>
    </td>
  </tr>
</table>
  <table class="TableBlock" border="0" width="70%" align="center" >
	<tr>
      <td nowrap class="TableContent"> 超时处理：</td>
      <td class="TableData">
	  <table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="30%" style="border-right:0px;border-bottom:0px;"><input name="flowdatetype" type="radio" style="border:0;" value="0" <? if($user['flowdatetype']=='0'){?>checked="checked"<? }?> onClick="checkbox(3,0);" />
      不使用超时
			<input name="flowdatetype" type="radio" style="border:0;" value="1" <? if($user['flowdatetype']=='1'){?>checked="checked"<? }?> onClick="checkbox(3,1);" />
			开启超时处理</td>
    <td width="70%" style="border-right:0px;border-bottom:0px;">
	<div id="div3">
	  <select name="flowdate">
	    <option value="30" <? if($user['flowdate']=='30'){?>selected="selected"<? }?>>30分钟</option>
		<option value="60" <? if($user['flowdate']=='60'){?>selected="selected"<? }?>>1小时</option>
		<option value="180" <? if($user['flowdate']=='180'){?>selected="selected"<? }?>>3小时</option>
		<option value="360" <? if($user['flowdate']=='360'){?>selected="selected"<? }?>>6小时</option>
		<option value="720" <? if($user['flowdate']=='720'){?>selected="selected"<? }?>>12小时</option>
		<option value="1440" <? if($user['flowdate']=='1440'){?>selected="selected"<? }?>>24小时</option>
		<option value="2880" <? if($user['flowdate']=='2880'){?>selected="selected"<? }?>>48小时</option>
		<option value="4320" <? if($user['flowdate']=='4320'){?>selected="selected"<? }?>>72小时</option>
	    </select>
	</div>
	
	</td>
  </tr>
  <tr>
    <td colspan="2" style="border-right:0px;border-bottom:0px;"><font color="#868788">注：超时处理是指在指定的时间内,审批人员没有审批该流程时由系统自动处理通过并转向下一步审批人员</font><br>
	<font color="red">超时处理开启后,如果下一步的流程中"人员设定"为空时,将直接拒绝流程,否则为通过</font></td>
    </tr>
	
</table>

	  
			
      </td>
    </tr>
	

	
</table>


<?php }else{?>
	<input type="hidden" name="flowkey" value="<?php echo $user['flowkey'];?>" />
	<input type="hidden" name="flowkey1" value="<?php echo $user['flowkey1'];?>" />
	<input type="hidden" name="flowkey2" value="<?php echo $user['flowkey2'];?>" />
	<input type="hidden" name="flowkey3" value="<?php echo $user['flowkey3'];?>" />

<?php }?>
 
  
  
</form>

</div>

</body>
</html>

