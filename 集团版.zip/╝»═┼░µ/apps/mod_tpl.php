<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
empty($do) && $do = 'list';
get_key("apps_type");
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if($tpltype=='') $tpltype=1;

if ($do == 'list') {
	//列表信息 
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($tpltype!='') {
		$wheresql .= " AND tpltype ='".$tpltype."'";
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_type WHERE 1 $wheresql");
    $sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type WHERE 1 $wheresql ORDER BY tplid desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('mana/template.php');
}elseif ($do == 'addform') {
	$sql = "SELECT tplid FROM ".DB_TABLEPRE.DB_JT."app_type ORDER BY tplid asc";
	$result = $db->fetch_all($sql);
	foreach ($result as $row) {
		if(mysql_num_rows(mysql_query("SHOW TABLES LIKE '".DB_TABLEPRE.DB_JT."apps_".$row['tplid']."'"))==1){
			$db->query("DROP TABLE ".DB_TABLEPRE.DB_JT."apps_".$row['tplid']."");
			$sql='CREATE TABLE '.DB_TABLEPRE.DB_JT.'apps_'.$row['tplid'].' (';
				  $sql.='did int(11) NOT NULL AUTO_INCREMENT,';
				  $sql.='appid varchar(16) DEFAULT NULL,';
				  $sql.='tplid varchar(16) DEFAULT NULL,';
				  $sql.='tpltype varchar(2) DEFAULT NULL,';
				  $sql.='date datetime DEFAULT NULL,';
				  $query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from  where tplid='".$row['tplid']."' order by fromid asc");
				  while ($rows = $db->fetch_array($query)) {
				    if($rows['dbtype']==2){
						$sql.=trim($rows['inputname'])." INT( 11 ) NULL,";
					}elseif($rows['inputtype1']==2){
						$sql.=trim($rows['inputname'])." TEXT NULL,";
					}elseif($rows['inputtype']==3){
						$sql.=trim($rows['inputname'])." DATE NULL,";
					}else{
						$sql.=trim($rows['inputname'])." varchar(250) DEFAULT NULL,";
					}
				}
				  $sql.='PRIMARY KEY (did)';
			$sql.=') ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;';
			$db->query($sql);
		}else{
			$sql='CREATE TABLE '.DB_TABLEPRE.DB_JT.'apps_'.$row['tplid'].' (';
				  $sql.='did int(11) NOT NULL AUTO_INCREMENT,';
				  $sql.='appid varchar(16) DEFAULT NULL,';
				  $sql.='tplid varchar(16) DEFAULT NULL,';
				  $sql.='tpltype varchar(2) DEFAULT NULL,';
				  $sql.='date datetime DEFAULT NULL,';
				  $query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from  where tplid='".$row['tplid']."' order by fromid asc");
				  while ($rows = $db->fetch_array($query)) {
				    if($rows['dbtype']==2){
						$sql.=trim($rows['inputname'])." INT( 11 ) NULL,";
					}elseif($rows['inputtype1']==2){
						$sql.=trim($rows['inputname'])." TEXT NULL,";
					}elseif($rows['inputtype']==3){
						$sql.=trim($rows['inputname'])." DATE NULL,";
					}else{
						$sql.=trim($rows['inputname'])." varchar(250) DEFAULT NULL,";
					}
				}
				  $sql.='PRIMARY KEY (did)';
			$sql.=') ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;';
			$db->query($sql);	
		}
	}
	echo 'ok';
	//show_msg('您要处理的信息操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&modid='.$modid.'');
} elseif ($do == 'update') {
	$idarr = getGP('id','P','array');
	foreach ($idarr as $id) {
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_type WHERE tplid = '$id'");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_flow WHERE tplid= '$id'");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_from WHERE tplid= '$id'");	
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."apps WHERE tplid= '$id'");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_personnel WHERE tplid= '$id'");
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_personnel_log WHERE tplid= '$id'");
		//新业务
		$db->query("DROP TABLE ".DB_TABLEPRE.DB_JT."apps_".$id."");
	}
	$content=serialize($idarr);
	$title='删除公文类别';
	get_logadd($id,$content,$title,14,$_USER->id);
	show_msg('公文类别删除成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'');

}elseif ($do == 'add') {
	include_once('mana/template_add.php');
}elseif ($do == 'addsave') {
	$app_type = array();
	$app_type['title'] = getGP('title','P');
	$app_type['tplkey'] = getGP('tplkey','P');
	$app_type['tpltype'] = $tpltype;
	$app_type['tplflow'] = getGP('tplflow','P');
	$tplusertype=getGP('tplusertype','P','int');
	$app_type['tplusertype'] = $tplusertype;
	if($tplusertype==1){
		$app_type['tpluser'] = check_str(getGP('tpluser1','P'));
	}elseif($tplusertype==2){
		$app_type['tpluser'] = check_str(getGP('tpluser2id','P'));
	}elseif($tplusertype==3){
		$app_type['tpluser'] = check_str(getGP('tpluser3id','P'));
	}else{
		$app_type['tpluser'] = '0';
	}
	if($app_type['tpluser']==''){
		$app_type['tpluser'] = '0';
	}
	$app_type['tpladmin'] = getGP('tpladmin','P');
	$app_type['uid'] = $_USER->id;
	$app_type['content'] = getGP('content','P');
	//写入主表信息
	if(getGP('tplid','P')!=''){
		update_db(DB_JT.'app_type',$app_type, array('tplid' => getGP('tplid','P')));
		$id=getGP('tplid','P');
	}else{
		insert_db(DB_JT.'app_type',$app_type);
		$id=$db->insert_id();
		$tpladdr = 'Tscx'.DB_JT.$tpltype.$id.'.php';
		$db->query("update ".DB_TABLEPRE.DB_JT."app_type set tpladdr='".$tpladdr."' WHERE tplid= '".$id."'");
		//处理数据库
		$sql='CREATE TABLE toa_'.DB_JT.'apps_'.$id.' (';
			  $sql.='did int(11) NOT NULL AUTO_INCREMENT,';
			  $sql.='appid varchar(16) DEFAULT NULL,';
			  $sql.='tplid varchar(16) DEFAULT NULL,';
			  $sql.='tpltype varchar(16) DEFAULT NULL,';
			  $sql.='date datetime DEFAULT NULL,';
			  $sql.='PRIMARY KEY (did)';
		$sql.=') ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;';
		$db->query($sql);
	}
	$content=serialize($app_type);
	$title='操作公文类别';
	get_logadd($id,$content,$title,14,$_USER->id);
	show_msg('公文类别操作成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'');
}elseif ($do == 'edit') {
	$tplid = getGP('tplid','G','int');
	$blog = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '$tplid'");
	include_once('mana/template_edit.php');
}
?>