<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("apps_");
empty($do) && $do = 'list';
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if(getGP('tplid','G')!=''){
	$tplid=getGP('tplid','G');
}else{
	$tplid=getGP('tplid','P');
}
if ($do == 'list') {
	if($tplid==''){
		include_once('template/tpllist.php');
	}else{
		$appid=getGP('appid','G','int');
		if($appid!=''){
			$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
			$work = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."apps  WHERE id = '".$appid."'  ");
			//获取当前流程
			$sql = "SELECT perid,flowid,countersign,entrust,appkey,uid,hang,hangdate FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE appid = '".$appid."' and (pertype=0 or pertype=4) order by perid desc";
			$flow = $db->fetch_one_array($sql);
			$flowsql = "SELECT flowkey4,formkey,flowkey8,flownum,flowtype FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE fid = '".$flow['flowid']."' order by fid desc";
			$flows = $db->fetch_one_array($flowsql);
			if($tpl['tplkey']==1){
				$addr = fopen('apps/tpl/'.$tpl['tpladdr'], "r") or die("无法读取文件!");
				$tpladdr= fread($addr,filesize('apps/tpl/'.$tpl['tpladdr']));
				fclose($addr); 
				//获取表单信息
				$tpladdr=apps_adddb($tplid,$tpltype,$appid,$tpladdr,$flow['flowid']);
				$file = $db->fetch_one_array("SELECT fileid FROM ".DB_TABLEPRE.DB_JT."fileoffice  WHERE number = 'apps".$appid."' and officetype='1' and filetype='1'");
				if($file['fileid']==''){
					$file['fileid']='51515800000';
				}
				$openaddr='';
				$tpladdrs= str_replace('.php','.doc',$tpl['tpladdr']);
				$fileaddr='data/word/wordflow/';
				include_once('template/add.php');
			}
		}else{
			$apps = array();
			$apps_db = array();
			$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
			//写入主表信息
			$apps['number']=get_date('YmdHis',PHP_TIME);
			$apps['tpltype']=$tpltype;
			$apps['tplid']=$tplid;
			$apps['title']=trim($tpl["title"]).'(No:'.get_date('YmdHis',PHP_TIME).')'.get_realname($_USER->id);
			$apps['uid']=$_USER->id;
			$apps['type']=0;
			$apps['date']=get_date('Y-m-d H:i:s',PHP_TIME);
			insert_db(DB_JT.'apps',$apps);
			$appid=$db->insert_id();
			if($tpl['tplkey']!=4 && $tpl['tplkey']!=5){
				//写入数据表
				$apps_db = array(
						'appid' => $appid,
						'tplid' => $tplid,
						'tpltype' => $tpltype,
						'date'=>get_date('Y-m-d H:i:s',PHP_TIME)
					);
				insert_db(DB_JT.'apps_'.$tplid,$apps_db);
			}
			//处理流程
			$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_flow  WHERE tplid = '".$tplid."' and flownum=1 order by fid asc";
			$flow = $db->fetch_one_array($sql);
			$personnel1 = array(
				'name' => get_realname($_USER->id),
				'uid' =>$_USER->id,
				'designationdate' =>get_date('Y-m-d H:i:s',PHP_TIME),
				'pertype' =>0,
				'appid' => $appid,
				'tplid' =>$tplid,
				'flowid' => $flow['fid'],
				'appkey' => $flow['flowkey2'],
				'appkey1' => $flow['flowkey3'],
				'flowdatetype' => 0,
				'flowdate' => get_date('Y-m-d H:i:s',PHP_TIME),
				'usernum' => ','.get_realname($_USER->id).','
				);
			insert_db(DB_JT.'app_personnel',$personnel1);
			//更新LOG
			$content=serialize($apps);
			$title='新建公文';
			get_logadd($id,$content,$title,14,$_USER->id);
			header('Location: admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tplid='.$tplid.'&tpltype='.$tpltype.'&appid='.$appid.'');
		}
		
	}

}elseif ($do == 'add') {
	apps_update();
	appsform_update();
	//更新LOG
	$title='保存流程数据';
	get_logadd($id,'',$title,14,$_USER->id);
	show_msg('公文数据保存成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tplid='.$tplid.'&tpltype='.$tpltype.'&flowid='.getGP('flowid','P','int').'&perid='.getGP('perid','P','int').'&appid='.getGP('appid','P','int'));
}elseif ($do == 'tplshow') {
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
	$addr = fopen('apps/tpl/'.$tpl['tpladdr'], "r") or die("无法读取文件!");
	$tpladdr= fread($addr,filesize('apps/tpl/'.$tpl['tpladdr']));
	fclose($addr); 
	$tpladdr=str_replace('<!--{date}-->',get_date('Y-m-d H:i:s',PHP_TIME),$tpladdr);
	//获取表单信息
	$tpladdr=apps_adddb($tplid,$typeid,0,$tpladdr);
	echo $tpladdr;
}elseif ($do == 'actd') {
	$perid=getGP('perid','G','int');
	$appid=getGP('appid','G','int');
	$entrust=getGP('entrust','G','int');
	if($perid!='' && $appid!=''){
		if($entrust!=''){
			$sql = "SELECT perid,entrust,usernum FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE perid=".$perid." and appid = '".$appid."' and (uid='".$entrust."' or countersign LIKE '%,".get_realname($entrust).",%')";
			$user = $db->fetch_one_array($sql);
			if($user['perid']!=''){
				echo 'user';
				exit;
			}
			$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set entrust='".$entrust."',usernum=CONCAT_WS('',usernum,'".get_realname($entrust).",') WHERE perid=".$perid." and appid = '".$appid."' ");
		}else{
			$sql1 = "SELECT entrust,usernum FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE perid=".$perid." and appid = '".$appid."'";
			$user1 = $db->fetch_one_array($sql1);
			$usernum=str_replace(get_realname($user1['entrust']).',','',$user1['usernum']);
			$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set entrust='',usernum='".$usernum."' WHERE perid=".$perid." and appid = '".$appid."' ");
		}
		echo 'true';
		exit;
	}
	echo 'false';
	exit;
}elseif ($do == 'acte') {
	$perid=getGP('perid','G','int');
	$appid=getGP('appid','G','int');
	$hangdate=getGP('hangdate','G');
	if($perid!='' && $appid!=''){
		if($hangdate!=''){
			$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set hang='1',hangdate='".$hangdate."' WHERE perid=".$perid." and appid = '".$appid."' ");
		}else{
			$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set hang='',hangdate='' WHERE perid=".$perid." and appid = '".$appid."' ");
		}
		echo 'true';
		exit;
	}
	echo 'false';
	exit;
}elseif ($do == 'actf') {
	$perid=getGP('perid','G','int');
	$appid=getGP('appid','G','int');
	$tplid=getGP('tplid','G','int');
	$countersign=getGP('countersign','G');
	if($perid!='' && $appid!='' && $tplid!=''){
		if($countersign!=''){
			//检查人员是否重复
			$query = $db->query("SELECT uid FROM ".DB_TABLEPRE.DB_JT."app_personnel_log where perid='".$perid."' and appid='".$appid."' and tplid='".$tplid."' and type='1' ORDER BY lid Asc");
			$html='';
			while ($row = $db->fetch_array($query)) {
				if(sizeof(explode(','.$row['uid'].',',','.$countersign.','))>1){
					echo 'user1';
					exit;
				}
			}
			$sql = "SELECT entrust,uid FROM ".DB_TABLEPRE.DB_JT."app_personnel  WHERE perid=".$perid." and appid = '".$appid."'";
			$user = $db->fetch_one_array($sql);
			if(sizeof(explode(','.$user['uid'].',',','.$countersign.','))>1){
				echo 'user2';
				exit;
			}
			if(sizeof(explode(','.$user['entrust'].',',','.$countersign.','))>1){
				echo 'user3';
				exit;
			}
			//写入人员数据
			$db->query("UPDATE ".DB_TABLEPRE.DB_JT."app_personnel set countersign=',".get_realname($countersign).",',usernum=CONCAT_WS('',usernum,'".get_realname($countersign).",') WHERE perid=".$perid." and appid = '".$appid."' ");
			$countersigns=explode(',',$countersign);
			for($i=0;$i<sizeof($countersigns);$i++){
				if($countersigns[$i]!=''){
					$personnel_log = array(
					'name' => get_realname($countersigns[$i]),
					'uid' =>$countersigns[$i],
					'pertype' =>0,
					'perid' =>$perid,
					'appid' =>$appid,
					'tplid' =>$tplid,
					'type' =>1
					);
					insert_db(DB_JT.'app_personnel_log',$personnel_log);
				}
			}
		}
		echo 'true';
		exit;
	}
	echo 'false';
	exit;
}elseif ($do == 'fileadd') {
	$filetype=getGP('filetype','P');
	$filenumber=getGP('filenumber','P');
	$filename=getGP('filename','P');
	$appendix=getGP('fileappendix','P');
	$content=getGP('filecontent','P');
	$_row = $db->fetch_one_array("SELECT id FROM ".DB_TABLEPRE.DB_JT."file  WHERE filetype = '".$filetype."' and filenumber = '".$filenumber."' ");
	if($_row['id']){
		echo 2;
		exit;
	}
	$file = array(
		'filetype' => $filetype,
		'filenumber' => $filenumber,
		'filename' => $filename,
		'enddate' => '99',
		'position' => '电子档案',
		'appendix' => $appendix,
		'content' => $content,
		'type' => '0',
		'type1' => '1',
		'date' => get_date('Y-m-d H:i:s',PHP_TIME),
		'uid' => $_USER->id
	);
	insert_db(DB_JT.'file',$file);
	//$id=$db->insert_id();
	echo 1;
	exit;
}
function _B($type){
	echo '<button type="button" style="margin-left:15px;" onClick=_B("'.$type.'"); class="btn btn-primary">转交下一步</button>';
	echo chr(13).chr(10);
}
function _BT($flowkey4){
	if($flowkey4!=''){
		echo '<button type="button" onClick=_C("'.$type.'"); class="btn btn-success">流程退回</button>';
		echo chr(13).chr(10);
	}
}
?>