<?php
//自定义模板
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
empty($do) && $do = 'list';
get_key("apps_type");
if(getGP('tplid','G')!=''){
	$tplid=getGP('tplid','G');
}else{
	$tplid=getGP('tplid','P');
}
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if ($do == 'list') {
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
	if(file_exists('apps/tpl/'.str_replace('.php','_old.php',$tpl['tpladdr']))!=''){
		$addr = fopen('apps/tpl/'.str_replace('.php','_old.php',$tpl['tpladdr']), "r") or die("无法读取文件!");
		$tpladdr= fread($addr,filesize('apps/tpl/'.str_replace('.php','_old.php',$tpl['tpladdr'])));
		fclose($addr);
	}elseif(file_exists('apps/tpl/'.str_replace(DB_JT,'',str_replace('.php','_old.php',$tpl['tpladdr'])))!=''){
		$addr = fopen('apps/tpl/'.str_replace(DB_JT,'',str_replace('.php','_old.php',$tpl['tpladdr'])), "r") or die("无法读取文件!");
		$tpladdr= fread($addr,filesize('apps/tpl/'.str_replace(DB_JT,'',str_replace('.php','_old.php',$tpl['tpladdr']))));
		$tpladdr=str_replace('toa_','toa_'.DB_JT,$tpladdr);
		fclose($addr);
	}
	include_once('mana/tplmana/index.php');
}elseif ($do == 'add') {
	$type = $_GET['type'];
	$fromid=getGP('fromid','G');
	if($fromid!='undefined'){
		$row = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from  WHERE fromid = '".$fromid."'  ");
	}
	if($fromid=='undefined'){
		$fromid=tplhtml(tinputtype($type),tinputtype1($type),'',$tplid);
		$row = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from  WHERE fromid = '".$fromid."'  ");
		if($type=='textarea'){
			$row['w']=600;
			$row['h']=80;
		}else{
			$row['w']=200;
			$row['h']=20;
		}
	}
	include_once('mana/tplmana/js/ueditor/formdesign/'.$type.'.php');
}elseif ($do == 'addsave') {
		$type = $_GET['type'];
		$fromid=getGP('fromid','G');
		if($fromid!='undefined'){
			if($type=='listctrl'){
			}else{
				$fromid=tplhtml(tinputtype($type),tinputtype1($type),$fromid,$tplid);
			}
		}
	
}elseif ($do == 'tplsave') {
	$content=stripcslashes($_POST["content"]);
	$contents=stripcslashes($_POST["content"]);
	$contentold=stripcslashes($_POST["content"]);
	//清理多余表单并过滤
	$sql="SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from where tplid='".$tplid."' ORDER BY fromid Asc";
	$query = $db->query($sql);
	while ($row = $db->fetch_array($query)) {
		if(sizeof(explode(trim('name="'.$row['inputname'].'"'),$content))>1){
			//输入框
			if($row['inputtype']==6){//列表
				//preg_match('/<\s*input\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?\/?\s*>/i',$content,$addr);
				//$content=str_replace($addr[0],"<!--".$row['inputname']."s-->".tpl_listctrl($tplid,$row['fromname'],$row['fromid'],$row['inputname'])."<!--".$row['inputname']."e-->",$content);
			}else{//其它控件
				if($row['inputtype1']==2){
					preg_match('/<\s*textarea\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?><s*\/?\s*textarea>/i',$content,$addr);
					$content=str_replace($addr[0],"<!--".$row['inputname']."s-->".apps_db($tplid,$row["inputname"],$row["w"],$row["h"],'{'.$row["inputname"].'}')."<!--".$row['inputname']."e-->",$content);
					
				}elseif($row['inputtype1']==3 || $row['inputtype1']==4){
					preg_match('%<span\s+[^>]*?inputname\s*="'.trim($row['inputname']).'".*?>(.*?)</span>%si',$content,$addr);
					$content=str_replace($addr[1],"<!--".$row['inputname']."s-->".apps_db($tplid,$row["inputname"],$row["w"],$row["h"],'{'.$row["inputname"].'}')."<!--".$row['inputname']."e-->",$content);
				}elseif($row['inputtype1']==5){
					preg_match('%<select\s+[^>]*?name\s*="'.trim($row['inputname']).'".*?>(.*?)</select>%si',$content,$addr);
					$content=str_replace($addr[0],"<!--".$row['inputname']."s-->".apps_db($tplid,$row["inputname"],$row["w"],$row["h"],'{'.$row["inputname"].'}')."<!--".$row['inputname']."e-->",$content);
				}else{
					preg_match('/<\s*input\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?\/?\s*>/i',$content,$addr);
					$content=str_replace($addr[0],"<!--".$row['inputname']."s-->".apps_db($tplid,$row["inputname"],$row["w"],$row["h"],'{'.$row["inputname"].'}')."<!--".$row['inputname']."e-->",$content);
				}
			}
			
		}else{
			if($row['inputtype']==6){
				$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_from WHERE fromid = '".$row['fromid']."' ");
				//在这里可以做一次对表的删除操作
				$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_from_view WHERE fromid = '".$row['fromid']."' ");
				$db->query("ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." DROP  ".trim($row['inputname'])."");
				$db->query("DROP TABLE ".DB_TABLEPRE.DB_JT."apps_".$tplid."_".$row['fromid']."");
			}else{
				$db->query("ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." DROP  ".trim($row['inputname'])."");
				$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_from WHERE fromid = '".$row['fromid']."' ");
			}
		}
	}
	//处理查看页面
	$sql="SELECT * FROM ".DB_TABLEPRE.DB_JT."app_from where tplid='".$tplid."' ORDER BY fromid Asc";
	$query = $db->query($sql);
	while ($row = $db->fetch_array($query)) {
		if(sizeof(explode(trim('name="'.$row['inputname'].'"'),$contents))>1){
			if($row['inputtype']==6){//列表
				//preg_match('/<\s*input\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?\/?\s*>/i',$contents,$addr);
				//$contents=str_replace($addr[0],"<!--".$row['inputname']."s-->".tpl_listctrls($tplid,$typeid,$row['fromname'],$row['fromid'],$row['inputname'])."<!--".$row['inputname']."e-->",$contents);
			}else{//其它控件
				if($row['inputtype1']==2){
					preg_match('/<\s*textarea\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?><s*\/?\s*textarea>/i',$contents,$addr);
					$contents=str_replace($addr[0],"<!--{".$row['inputname']."}-->",$contents);
				}elseif($row['inputtype1']==3 || $row['inputtype1']==4){
					preg_match('%<span\s+[^>]*?inputname\s*="'.trim($row['inputname']).'".*?>(.*?)</span>%si',$contents,$addr);
					$contents=str_replace($addr[1],"<!--{".$row['inputname']."}-->",$contents);
				}elseif($row['inputtype1']==5){
					preg_match('%<select\s+[^>]*?name\s*="'.trim($row['inputname']).'".*?>(.*?)</select>%si',$contents,$addr);
					$contents=str_replace($addr[0],"<!--{".$row['inputname']."}-->",$contents);
				}else{
					preg_match('/<\s*input\s+[^>]*?name\s*="'.trim($row['inputname']).'"(.*?)\\1[^>]*?\/?\s*>/i',$contents,$addr);
					$contents=str_replace($addr[0],"<!--{".$row['inputname']."}-->",$contents);
				}
			}
			
		}
	}
	$style='';
	//$content=str_replace('<table','<table class="table table-bordered" ',$content);
	//$content=str_replace('<br/>','',$content);
	//$contents=str_replace('<table','<table class="table table-bordered" ',$contents);
	//$contents=str_replace('<br/>','',$contents);
	//生成文件
	$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$tplid."'  ");
	$Path='apps/tpl/'.$tpl["tpladdr"];//
	$Pathview='apps/tpl/'.str_replace('.php','_view.php',$tpl['tpladdr']);
	$fp = fopen($Path,"w"); 
	fwrite($fp,$style.$content); 
	fclose($fp);
	/////////////
	$fp = fopen($Pathview,"w"); 
	fwrite($fp,$style.$contents); 
	fclose($fp);
	//生成原始数据
	$Pathold='apps/tpl/'.str_replace('.php','_old.php',$tpl['tpladdr']);
	$fp = fopen($Pathold,"w"); 
	fwrite($fp,$contentold); 
	fclose($fp);
	if($_POST['type']=='show'){
		header('Location: admin.php?ac=add&fileurl=apps&do=tplshow&tplid='.$tplid.'&tpltype='.$tpltype.'');
	}
	//echo "模板保存成功，3秒后窗口自动关闭！";
	sleep(3);
	echo '<script language="JavaScript">window.close()</script>';
	//exit;
}
function tplhtml($inputtype,$inputtype1,$fromid,$tplid){
	global $db;
	global $_USER;
	$from = array();
	$filenumber=random(4,'0123456789').'_'.get_date('YmdHis',PHP_TIME);
	$inputname = 'toa_'.$filenumber;
	if(getGP('fromname','G')!=''){
		$from['fromname']=check_str(getGP('fromname','G'));
	}else{
		$from['fromname']='';
	}
	if($fromid==''){
		$from['inputname']=$inputname;
	}
	if(getGP('inputvalue','G')!=''){
		$from['inputvalue']=check_str(getGP('inputvalue','G'));
	}else{
		$from['inputvalue']='';
	}
	$from['inputtype']=$inputtype;
	$from['inputtype1']=$inputtype1;
	if(getGP('inputvaluenum','G')!=''){
		$from['inputvaluenum']=substr(check_str(getGP('inputvaluenum','G')), 0, -1);
	}else{
		$from['inputvaluenum']='';
	}
	if(getGP('confirmation','G')!=''){
		$from['confirmation']=check_str(getGP('confirmation','G'));
	}else{
		$from['confirmation']='2';
	}
	if(getGP('w','G')!=''){
		$from['w']=check_str(getGP('w','G'));
	}else{
		$from['w']='200';
	}
	if(getGP('h','G')!=''){
		$from['h']=check_str(getGP('h','G'));
	}else{
		$from['h']='20';
	}
	if(getGP('dbtype','G')!=''){
		$from['dbtype']=check_str(getGP('dbtype','G'));
	}else{
		$from['dbtype']='1';
	}
	if(getGP('magnificent','G')!=''){
		$from['magnificent']=check_str(getGP('magnificent','G'));
	}else{
		$from['magnificent']='';
	}
	$from['tplid']=$tplid;
	if($fromid==''){
		$from['uid']=$_USER->id;
	}
	if($fromid==''){
		insert_db(DB_JT.'app_from',$from);
		$fromid=$db->insert_id();
		//处理表
			if(getGP('dbtype','G')==2){
				$sql="ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." ADD  ".trim($inputname)." INT( 11 ) NULL ;";
			}elseif($inputtype1==2){
				$sql="ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." ADD  ".trim($inputname)." TEXT NULL ;";
			}elseif($inputtype==3){
				$sql="ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." ADD  ".trim($inputname)." DATE NULL ;";
			}else{
				$sql="ALTER TABLE  ".DB_TABLEPRE.DB_JT."apps_".$tplid." ADD  ".trim($inputname)." VARCHAR(255) NULL ;";
			}
			$db->query($sql);
	}else{
		update_db(DB_JT.'app_from',$from, array('fromid' => $fromid));
	}
	return $fromid;
}
function tinputtype($type){
	switch ($type)
	{
		case 'text':
		  return 0;
		  break;
		case 'textarea':
		  return 0;
		  break;
		case 'select':
		  return 0;
		  break;
		case 'radios':
		  return 0;
		  break;
		case 'checkboxs':
		  return 0;
		  break;
		case 'macros':
		  return 7;
		  break;
		case 'date':
		  return 3;
		  break;
		case 'department':
		  return 4;
		  break;
		case 'user':
		  return 5;
		  break;
		default:
		  return 0;
	}
}
function tinputtype1($type){
	switch ($type)
	{
		case 'text':
		  return 1;
		  break;
		case 'textarea':
		  return 2;
		  break;
		case 'select':
		  return 5;
		  break;
		case 'radios':
		  return 3;
		  break;
		case 'checkboxs':
		  return 4;
		  break;
		default:
		  return 1;
	}
}
?>