<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
require(TOA_ROOT.'include/function_charts.php');
empty($do) && $do = 'list';
get_key("apps_charts");
if(getGP('type','G')!=''){
	$type=getGP('type','G');
}else{
	$type=2;
}
$datesart=getGP('datesart','G');
$dateend=getGP('dateend','G');
if(getGP('flashtype','G')!=''){
	$flashtype=getGP('flashtype','G');
}else{
	$flashtype='Column3D';
}
//Column3D,Line,Pie3D,Area2D,Bar2D,Doughnut2D
$fw='100%';
$fh='350';
if ($do == 'list') {
	$wheresql = '';
	if ($datesart!='' && $dateend!='') {
		$wheresql .= " AND (date>='".$datesart."' and date<='".$dateend."')";
	}
	if($type==2){
		//工作流人员统计
		if($flashtype=='Bar2D'){
			$fw='100%';
			$fh='1250';
		}
		global $db;
		$uid='';
		if ($datesart!='' && $dateend!='') {
			$wheresqla .= " AND (designationdate>='".$datesart."' and designationdate<='".$dateend."')";
		}
		$sql = $db->query("SELECT uid,name FROM ".DB_TABLEPRE.DB_JT."app_personnel ORDER BY perid Asc");
		while ($row = $db->fetch_array($sql)) {
			$uid.=$row['uid'].',';
		}
		$user='';
		$uname='';
		if($uid!=''){
			$sql = $db->query("SELECT a.id,b.name FROM ".DB_TABLEPRE."user a,".DB_TABLEPRE."user_view b where a.id=b.uid and a.id in(".substr($uid, 0, -1).") ORDER BY a.numbers Asc");
			while ($row = $db->fetch_array($sql)) {
				$user.=$row['id'].',';
				$uname.=$row['name'].',';
			}
		}
		$uid=explode(',',substr($user, 0, -1)); 
		$name=explode(',',substr($uname, 0, -1)); 
		$strtype  = "<chart caption='' xAxisName='公文办理统计' yAxisName='成员统计' showValues='0' formatNumberScale='0' showBorder='1'>";
		for($i=0;$i<sizeof($uid);$i++){
			$numuser = $db->result("SELECT COUNT(*) AS numuser FROM ".DB_TABLEPRE.DB_JT."app_personnel WHERE name like '%".$name[$i]."%' ".$wheresqla."");
			$strtype .= "<set label='".$name[$i]."' value='".$numuser."' />";
		}
		$strtype .= "</chart>";
	}elseif($type==3){
	//工作流模型统计
		if($flashtype=='Bar2D' && $typeid==''){
			$fw='100%';
			$fh='1250';
		}
		$strtype  = "<chart caption='' xAxisName='公文类别统计' yAxisName='类别统计' showValues='0' formatNumberScale='0' showBorder='1'>";
		global $db;
		$sql = $db->query("SELECT tplid,title FROM ".DB_TABLEPRE.DB_JT."app_type  ORDER BY tplid Asc");
		while ($row = $db->fetch_array($sql)) {
			$numtpl = $db->result("SELECT COUNT(*) AS numtpl FROM ".DB_TABLEPRE.DB_JT."apps WHERE tplid='".$row['tplid']."' ".$wheresql."");
			$strtype .= "<set label='".$row['title']."' value='".$numtpl."' />";
		}
		$strtype .= "</chart>";
	}elseif($type==4){
		//工作流审批状态统计
		//0未审批
		//1审批；
		//2拒绝;
		//3退回
		//4等待审批
		//5结束
		if ($datesart!='' && $dateend!='') {
			$wheresqls = " AND (a.date>='".$datesart."' and a.date<='".$dateend."')";
		}
		$strtype  = "<chart caption='' xAxisName='公文办理状态统计' yAxisName='办理状态' showValues='0' formatNumberScale='0' showBorder='1'>";
		global $db;
		for($i=0;$i<=5;$i++){
			if($i!=3){
				$numkey = $db->result("SELECT COUNT(*) AS numkey FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_personnel b WHERE a.id=b.appid and pertype='".$i."'  ".$wheresqls." order by perid desc");
				if($i=='0'){
					$title='未审批';
				}elseif($i=='1'){
					$title='己审批';
				}elseif($i=='2'){
					$title='拒绝';
				}elseif($i=='3'){
					$title='退回';
				}elseif($i=='4'){
					$title='等待审批';
				}elseif($i=='5'){
					$title='结束';
				}
				$strtype .= "<set label='".$title."' value='".$numkey."' />";
			}
		}
		$numkeys = $db->result("SELECT COUNT(*) AS numkeys FROM ".DB_TABLEPRE.DB_JT."apps  WHERE type='1'  ".$wheresql." order by id desc");
		$strtype .= "<set label='撤消' value='".$numkeys."' />";
		$strtype .= "</chart>";
	}else{
	}
	include_once('charts/list.php');

}
?>