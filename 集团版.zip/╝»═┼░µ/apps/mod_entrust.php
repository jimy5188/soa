<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
get_key("apps_entrust");
empty($do) && $do = 'list';
if ($do == 'list') {
	//列表信息 
	$wheresqltype = '';
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'';
	if ($usersid = getGP('usersid','G')) {
		$wheresql .= " AND user='".$usersid."'";
		$url .= '&usersid='.rawurlencode($usersid);
	}
	if ($tplid = getGP('tplid','G')) {
		$wheresql .= " AND tplid='".$tplid."'";
		$url .= '&tplid='.rawurlencode($tplid);
	}
	//权限判断
	$un = getGP('un','G');
	$ui = getGP('ui','G');
	if(!is_superadmin() && $ui==''){
		$wheresql .= " and uid='".$_USER->id."'";
	}
	if ($ui!='') {
		$wheresql .= " and uid in(".$ui.")";
		$url .= '&ui='.$ui.'&un='.$un;
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_entrust WHERE 1 $wheresql  order by id desc");
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_entrust WHERE 1 $wheresql order by id desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/entrust.php');
}elseif ($do == 'entrustuser') {
	//列表信息 
	$wheresqltype = '';
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'';
	if ($userid = getGP('userid','G')) {
		$wheresql .= " AND uid='".$userid."'";
		$url .= '&userid='.rawurlencode($userid);
	}
	if ($tplid = getGP('tplid','G')) {
		$wheresql .= " AND tplid='".$tplid."'";
		$url .= '&tplid='.rawurlencode($tplid);
	}
	//权限判断
	$un = getGP('un','G');
	$ui = getGP('ui','G');
	if(!is_superadmin() && $ui==''){
		$wheresql .= " and user='".$_USER->id."'";
	}
	if ($ui!='') {
		$wheresql .= " and user in(".$ui.")";
		$url .= '&ui='.$ui.'&un='.$un;
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_entrust WHERE 1 $wheresql  order by id desc");
	$sql = "SELECT * FROM ".DB_TABLEPRE.DB_JT."app_entrust WHERE 1 $wheresql order by id desc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/entrustuser.php');
}elseif ($do == 'add') {
	$id=getGP('id','G','int');
	$entrust = array();
	$entrust['tplid']=getGP('tplid','G','int');
	$entrust['uid']=$_USER->id;
	$entrust['user']=getGP('user','G','int');
	$entrust['period']=getGP('period','G','int');
	if(getGP('startdata','G')!=''){
		$entrust['startdata']=getGP('startdata','G');
	}
	if(getGP('enddate','G')!=''){
		$entrust['enddate']=getGP('enddate','G');
	}
	$user = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_entrust  WHERE uid = '".$_USER->id."' and tplid = '".getGP('tplid','G','int')."' and id!=".$id."");
	if($user['id']!=''){
		echo 'false';
		exit;
	}
	if($id!=0){
		update_db(DB_JT.'app_entrust',$entrust, array('id' => $id));
		echo 'true';
	}else{
		insert_db(DB_JT.'app_entrust',$entrust);
		$id=$db->insert_id();
		//sms_box_add('user');
		$content=unescape(getGP('box_content_user','G'));
		$user=unescape(getGP('username','G'));
		$phone=getGP('userphone','G');
		$sms_box=getGP('sms_box_user','G','int');
		$sms_phone=getGP('sms_phone_user','G','int');
		sms_box_add($content,$user,$phone,'',$sms_box,$sms_phone,'');
		echo 'true';
	}
	exit;
}elseif($do=='ajax'){
	$id=getGP('id','G','int');
	$user = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_entrust  WHERE id = '$id'");
	if($user['id']==''){
		$user['tplid']=0;
		$user['id']=0;
		$user['startdata']=get_date('Y-m-d H:i:s',PHP_TIME);
		$user['enddate']=get_date('Y-m-d H:i:s',PHP_TIME);
	}
	echo '<form class="form-horizontal" name="save">';
	echo '<input type="hidden" name="tplid" id="tplid" value="'.$user['tplid'].'" />';
	echo '<input type="hidden" name="id" id="id" value="'.$user['id'].'" />';
	echo '<div class="alert alert-success" id="message-info"></div>';
	echo '<div class="control-group ">';
	echo '<label class="control-label required">公文类别 <span class="required">*</span>';
	echo '</label><div class="controls"><div class="btn-group">';
	if($user['tplid']==0){
		echo '<button type="button" class="btn btn-default" id="tplidname">全部公文类别</button>';
	}else{
		echo '<button type="button" class="btn btn-default" id="tplidname">'.public_value('title',DB_JT.'app_type','tplid='.$user['tplid']).'</button>';
	}
	echo '<button type="button" ';
	echo ' class="btn btn-default dropdown-toggle" data-toggle="dropdown">';
	echo '<span class="caret"></span><span class="sr-only"></span></button>';
	echo '<ul class="dropdown-menu" role="menu" ';
	echo 'style="position:absolute; height:200px; overflow:auto; ">';
	//foreach ( $_CACHE[DB_JT.'workclass_type'] as $row) {
		$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."app_type where  tplkey!='2' ORDER BY tplid Asc");
		if($num>0){
			$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type where  tplkey!='2'  ORDER BY tplid Asc");
			while ($trow = $db->fetch_array($query)){ 
				echo '<li><a href="javascript:;" onClick="tplmenu('.$trow['tplid'].',';
				echo "'".$trow['title']."');";
				echo '">'.$trow['title'].'</a></li>';
			}
			//echo '<li class="divider"></li>';
		}
	//}
	echo '</ul></div></div></div>';
	echo '<div class="control-group ">';
	echo '<label class="control-label required" for="AttachmentItem_file_name"';
	echo '>被委托人 <span class="required">*</span></label>';
	echo '<div class="controls">';
	get_pubuser(1,"user",get_realname($user['user']),"+选择被委托人",120,20);
	echo '</div></div>';
	echo get_newsmsbox('被委托人','user',"您于".get_date('Y-m-d H:i:s',PHP_TIME)."被".get_realname($_USER->id)."设为公文委托办理员！");
	echo  '<div class="control-group ">';
	echo '<label class="control-label" for="UserDelegate_status">周期</label>';
	echo '<div class="controls"><label class="checkbox inline">';
	if($user['period']==0){
		echo '<input name="period" id="period" value="1" type="checkbox"  />一直有效';
	}else{
		echo '<input name="period" id="period" value="1" type="checkbox" checked />一直有效';
	}
	echo '</label></div></div>';
	echo '<label class="control-label required" id="startdatas" ';
	echo 'for="UserDelegate_begin_time">起止时间 <span class="required">*</span></label>';
	echo '<div class="controls controls-row" id="enddates">';
	echo '<input id="startdata" size="16" type="text" value="'.$user['startdata'].'" ';
	echo 'readonly onFocus="';
	echo "WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})";
	echo '" class="span2">';
	echo '<input id="enddate" size="16" type="text" value="'.$user['enddate'].'" ';
	echo 'readonly onFocus="';
	echo "WdatePicker({dateFmt:'yyyy-MM-dd HH:mm:ss'})";
	echo '" class="span2" >';
	echo '</div>	</form> ';
} elseif ($do == 'update') {
	$idarr = getGP('id','G');
	$ids=explode(',',$idarr);
	for($i=0;$i<sizeof($ids);$i++){
		$db->query("DELETE FROM ".DB_TABLEPRE.DB_JT."app_entrust WHERE id = '".$ids[$i]."' ");	
	}
	$content=$idarr;
	$title='删除公文委托信息';
	get_logadd($idarr,$content,$title,14,$_USER->id);
	echo $idarr;
}
?>