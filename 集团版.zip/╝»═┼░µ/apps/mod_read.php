<?php
(!defined('IN_TOA') || !defined('IN_ADMIN')) && exit('Access Denied!');
empty($do) && $do = 'list';
get_key("apps_read");
if(getGP('tpltype','G')!=''){
	$tpltype=getGP('tpltype','G');
}else{
	$tpltype=getGP('tpltype','P');
}
if ($do == 'list') {
	//列表信息 
	$wheresqltype = '';
	$wheresql = '';
	$page = max(1, getGP('page','G','int'));
	$pagesize = $_CONFIG->config_data('pagenum');
	$offset = ($page - 1) * $pagesize;
	$url = 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'';
	if ($title = getGP('title','G')) {
		$wheresql .= " AND a.title LIKE '%$title%' ";
		$url .= '&title='.rawurlencode($title);
	}
	if ($number = getGP('number','G')) {
		$wheresql .= " AND a.number='".$number."'";
		$url .= '&number='.rawurlencode($number);
	}
	if ($tpltype=='1') {
		$wheresql .= " AND b.readdate!=''";
	}elseif($tpltype=='2') {
		$wheresql .= " AND b.readdate is Null";
	}
	$vstartdate = getGP('vstartdate','G');
	$venddate = getGP('venddate','G');
	if ($vstartdate!='' && $venddate!='') {
		$wheresql .= " AND (a.date>='".$vstartdate."' and a.date<='".$venddate."')";
		$url .= '&vstartdate='.$vstartdate.'&venddate='.$venddate;
	}
	$num = $db->result("SELECT COUNT(*) AS num FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_read b WHERE 1 $wheresql and a.id=b.appid and b.readuid='".$_USER->id."' order by b.readdate asc");
	$sql = "SELECT a.title,a.number,a.id as appid,b.* FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_read b WHERE 1 $wheresql and a.id=b.appid and b.readuid='".$_USER->id."' order by b.readdate asc LIMIT $offset, $pagesize";
	$result = $db->fetch_all($sql);
	include_once('template/readlist.php');

}elseif ($do == 'view') {
	$appid=getGP('appid','G','int');
	if(getGP('type','G','int')!=''){
		$db->query("update ".DB_TABLEPRE.DB_JT."app_read set readdate='".get_date('Y-m-d H:i:s',PHP_TIME)."' WHERE readuid='".$_USER->id."' and rid = '".getGP('rid','G','int')."' ");
	}
	if($appid!=''){
		$work = $db->fetch_one_array("SELECT a.*,b.content FROM ".DB_TABLEPRE.DB_JT."apps a,".DB_TABLEPRE.DB_JT."app_read b WHERE  a.id=b.appid and b.readuid='".$_USER->id."' and a.id='".$appid."' and b.rid='".getGP('rid','G','int')."' order by b.readdate asc");
		$tpl = $db->fetch_one_array("SELECT * FROM ".DB_TABLEPRE.DB_JT."app_type  WHERE tplid = '".$work['tplid']."'  ");
		$addr = fopen('apps/tpl/'.str_replace('.php','_view.php',$tpl['tpladdr']), "r") or die("无法读取文件!");
		$tpladdr= fread($addr,filesize('apps/tpl/'.$tpl['tpladdr']));
		fclose($addr); 
		//获取数据
		$tpladdr=apps_viewdb($work['tplid'],$work['tpltype'],$appid,$tpladdr);
		//获取表单信息
		$file = $db->fetch_one_array("SELECT fileid FROM ".DB_TABLEPRE.DB_JT."fileoffice  WHERE number = 'apps".$appid."' and officetype='1' and filetype='1'");
		if($file['fileid']==''){
			$file['fileid']='51515800000';
		}
		$openaddr='';
		$tpladdrs= str_replace('.php','.doc',$tpl['tpladdr']);
		$fileaddr='data/word/wordflow/';
		include_once('template/readview.php');
	}
}elseif ($do == 'update') {
	$idarr = getGP('id','P','array');
	foreach ($idarr as $id) {
		$db->query("update ".DB_TABLEPRE.DB_JT."app_read set readdate='".get_date('Y-m-d H:i:s',PHP_TIME)."',content='己阅' WHERE readuid='".$_USER->id."' and rid = '$id' ");	
	}
	show_msg('公文批量阅读处理成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.$tpltype.'');

}
elseif ($do == 'viewsave') {
	$content = getGP('content','P');
	if(getGP('rid','G','int')!=''){
		$db->query("update ".DB_TABLEPRE.DB_JT."app_read set content='".$content."' WHERE readuid='".$_USER->id."' and rid = '".getGP('rid','G','int')."' ");	
		show_msg('阅读意见处理成功！', 'admin.php?ac='.$ac.'&fileurl='.$fileurl.'&tpltype='.getGP('tpltype','G','int').'&tplid='.getGP('tplid','G','int').'&appid='.getGP('appid','G','int').'&do=view&rid='.getGP('rid','G','int').'');
	}

}
?>