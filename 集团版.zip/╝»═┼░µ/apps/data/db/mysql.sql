DROP TABLE IF EXISTS toa_app_type;
CREATE TABLE toa_app_type (
  tplid int(11) NOT NULL AUTO_INCREMENT,
  title varchar(64) DEFAULT NULL,
  tplkey varchar(2) DEFAULT NULL,
  tpltype varchar(2) DEFAULT NULL,
  tplflow varchar(2) DEFAULT NULL,
  tpluser text,
  tpladmin text,
  uid varchar(16) DEFAULT NULL,
  tpladdr varchar(64) DEFAULT NULL,
  content text,
  tplusertype varchar(2) DEFAULT NULL,
  PRIMARY KEY (tplid)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS toa_app_flow;
CREATE TABLE toa_app_flow (
  fid int(11) NOT NULL AUTO_INCREMENT,
  flowname varchar(64) DEFAULT NULL,
  flownum int(11) DEFAULT NULL,
  flowuser varchar(128) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  flowkey varchar(2) DEFAULT NULL,
  flowkey1 varchar(2) DEFAULT NULL,
  flowkey2 varchar(2) DEFAULT NULL,
  flowkey3 varchar(2) DEFAULT NULL,
  flowkey4 varchar(64) DEFAULT NULL,
  flowdate varchar(16) DEFAULT NULL,
  flowdatetype varchar(2) DEFAULT NULL,
  formkey text,
  flowtype varchar(2) DEFAULT NULL,
  flowusertype varchar(2) DEFAULT NULL,
  flowkey5 text,
  flowkey6 varchar(64) DEFAULT NULL,
  flowkey7 varchar(2) DEFAULT NULL,
  flowkey8 varchar(64) DEFAULT NULL,
  PRIMARY KEY (fid)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS toa_app_from;
CREATE TABLE toa_app_from (
  fromid int(11) NOT NULL AUTO_INCREMENT,
  fromname varchar(64) DEFAULT NULL,
  inputname varchar(64) DEFAULT NULL,
  inputvalue varchar(128) DEFAULT NULL,
  inputtype varchar(2) DEFAULT NULL,
  inputtype1 varchar(2) DEFAULT NULL,
  inputvaluenum tinytext,
  confirmation varchar(2) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  w varchar(16) DEFAULT NULL,
  h varchar(16) DEFAULT NULL,
  dbtype varchar(2) DEFAULT NULL,
  magnificent varchar(64) DEFAULT NULL,
  PRIMARY KEY (fromid)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS toa_apps;
CREATE TABLE toa_apps (
  id int(11) NOT NULL AUTO_INCREMENT,
  number varchar(64) DEFAULT NULL,
  tpltype varchar(2) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  title varchar(255) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  date datetime DEFAULT NULL,
  type varchar(2) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS toa_app_personnel;
CREATE TABLE toa_app_personnel (
  perid int(11) NOT NULL AUTO_INCREMENT,
  name varchar(32) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  designationdate datetime DEFAULT NULL,
  approvaldate datetime DEFAULT NULL,
  lnstructions varchar(255) DEFAULT NULL,
  pertype varchar(2) DEFAULT NULL,
  appid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  flowid varchar(16) DEFAULT NULL,
  appkey varchar(2) DEFAULT NULL,
  appkey1 varchar(2) DEFAULT NULL,
  flowdate varchar(64) DEFAULT NULL,
  flowdatetype varchar(2) DEFAULT NULL,
  flowkey8 varchar(32) DEFAULT NULL,
  countersign text DEFAULT NULL,
  entrust varchar(16) DEFAULT NULL,
  hang varchar(2) DEFAULT NULL,
  hangdate datetime DEFAULT NULL,
  arrivedate datetime DEFAULT NULL,
  usernum text DEFAULT NULL,
  userend text DEFAULT NULL,
  PRIMARY KEY (perid)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS toa_app_personnel_log;
CREATE TABLE toa_app_personnel_log (
  lid int(11) NOT NULL AUTO_INCREMENT,
  name varchar(32) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  approvaldate datetime DEFAULT NULL,
  lnstructions varchar(255) DEFAULT NULL,
  pertype varchar(2) DEFAULT NULL,
  perid varchar(16) DEFAULT NULL,
  appid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  type varchar(2) DEFAULT NULL,
  entrust varchar(16) DEFAULT NULL,
  PRIMARY KEY (lid)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS toa_app_read;
CREATE TABLE toa_app_read (
  rid int(11) NOT NULL AUTO_INCREMENT,
  appid varchar(16) DEFAULT NULL,
  tplid varchar(16) DEFAULT NULL,
  tpltype varchar(2) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  date datetime DEFAULT NULL,
  readdate datetime DEFAULT NULL,
  content text,
  readuid varchar(16) DEFAULT NULL,
  PRIMARY KEY (rid)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
DROP TABLE IF EXISTS toa_app_delivery;
CREATE TABLE toa_app_delivery (
  did int(11) NOT NULL AUTO_INCREMENT,
  title varchar(128) DEFAULT NULL,
  dstart varchar(16) DEFAULT NULL,
  dread varchar(16) DEFAULT NULL,
  appendix text,
  content varchar(255) DEFAULT NULL,
  dtype varchar(2) DEFAULT NULL,
  startdate datetime DEFAULT NULL,
  readdate datetime DEFAULT NULL,
  PRIMARY KEY (did)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1000;
DROP TABLE IF EXISTS toa_app_entrust;
CREATE TABLE toa_app_entrust (
  id int(11) NOT NULL AUTO_INCREMENT,
  tplid varchar(16) DEFAULT NULL,
  uid varchar(16) DEFAULT NULL,
  user varchar(16) DEFAULT NULL,
  period varchar(2) DEFAULT NULL,
  startdata datetime DEFAULT NULL,
  enddate datetime DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM AUTO_INCREMENT=1000 DEFAULT CHARSET=utf8;
INSERT INTO toa_keytable (id, name, inputname, inputvalue, inputchecked, type, number, fatherid) VALUES
(631, '公文管理', 'apps', '1', '1', '2', 4, '0'),
(632, '公文管理', 'apps_', '1', '1', '2', 1, '640'),
(633, '公文阅读', 'apps_read', '1', '1', '2', 2, '640'),
(634, '待收文件', 'apps_delivery', '1', '1', '2', 3, '640'),
(635, '公文监控', 'apps_mana', '1', '1', '2', 4, '640'),
(636, '报表与统计', 'apps_charts', '1', '1', '2', 5, '640'),
(637, '公文配置', 'apps_type', '1', '1', '2', 6, '640'),
(641, '公文委办', 'apps_entrust', '1', '1', '2', 6, '640'),
(638, '删除公文', 'apps_del', '1', '1', '2', 7, '640'),
(639, '导出报表', 'apps_excel', '1', '1', '2', 8, '640'),
(640, '公文权限', 'input_name', '0', '1', '1', 999, '631');
INSERT INTO toa_menu (menuid, menuname, menuurl, fatherid, menutype, menunum, menukey, keytable) VALUES
(410, '公文管理', 'home.php?mid=410', '0', '0', 6, '0', 'apps'),
(412, '公文拟稿', 'admin.php?ac=add&fileurl=apps', '410', '2', 1, '0', 'apps_'),
(413, '公文办理', 'admin.php?ac=list&fileurl=apps&do=listkey', '410', '2', 2, '0', ''),
(414, '公文阅读', 'admin.php?ac=read&fileurl=apps', '410', '0', 3, '0', 'apps_read'),
(415, '我的公文', 'admin.php?ac=list&fileurl=apps', '410', '2', 4, '0', 'apps_'),
(416, '待收文件', 'admin.php?ac=delivery&fileurl=apps', '410', '0', 5, '0', 'apps_delivery'),
(417, '公文监控', 'admin.php?ac=list&fileurl=apps&do=mana', '410', '2', 6, '0', 'apps_mana'),
(420, '公文委办', 'admin.php?ac=entrust&fileurl=apps', '410', '2', 7, '0', 'apps_entrust'),
(418, '报表与统计', 'admin.php?ac=charts&fileurl=apps', '410', '0',8, '0', 'apps_charts'),
(419, '公文配置', 'admin.php?ac=tpl&fileurl=apps', '410', '0',9, '0', 'apps_type');
