<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd"><html>
<head>
<title>信息添加编辑</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="template/default/content/css/style.css">
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script src="template/default/tree/js/admincp.js?SES" type="text/javascript"></script>
<script charset="utf-8" src="eweb/kindeditor.js"></script>
</head>
<body class="bodycolor">
<table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" style='margin-top:30px;'>
  <tr>
    <td class="Big"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3"> <?php echo $blog["subject"]?>&nbsp;&nbsp;<?php echo $_title['name']?></span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:12px; float:right; margin-right:20px;">
	<a href="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&type=<?php echo $_GET['type']?>" style="font-size:12px;"><<返回列表页</a></span>
    </td>
  </tr>
</table>

<form name="save" method="post" action="?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>&do=views">
	<input type="hidden" name="view" value="edit" />
	<input type="hidden" name="bbsid" value="<?php echo $blog['id']?>" />
	<input type="hidden" name="author" value="<?php echo get_realname($_USER->id)?>" />
<table class="TableBlock" border="0" width="90%" align="center" style="border-bottom:#4686c6 solid 0px;">
		<tr>
			<td nowrap class="TableContent" width="90">发布时间：</td>
			  <td class="TableData">
					<?php echo $blog['date']?>				</td>  	  	
		</tr>
		<tr>
			<td nowrap class="TableContent" width="90">主题：</td>
			  <td class="TableData">
					<?php echo $blog['subject']?>				</td>  	  	
		</tr>
		<tr>
      <td nowrap class="TableContent"> 附件：</td>
      <td class="TableData">
	  <? if($blog['appendix']!=''){?>
	  <a href="down.php?urls=<?php echo $blog['appendix']?>" target="_blank">下载附件</a>
	  <? }else{?> 
	  无附件
	  <? }?>
	   </td>
    </tr>
		<tr>
      <td nowrap class="TableContent"> 发布人：</td>
      <td class="TableData"><?php echo get_realname($blog['uid'])?>     </td>
    </tr>
	</table>	
	<table  width="90%" style="border-left:#4686c6 solid 1px;border-right:#4686c6 solid 1px;border-bottom:#4686c6 solid 1px;" align="center">
	<tr>
      <td colspan="2" bgcolor="#FFFFFF" style="padding:20px 20px 20px 20px;"><?php echo $blog['content']?> </td>
    </tr>
	</table>
	
	
	
	<table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" style='margin-top:30px;'>
  <tr>
    <td class="Big"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3">阅读记录</span>
    </td>
  </tr>
</table>
	
	<table class="TableBlock" border="0" width="90%" align="center" style="border-bottom:#4686c6 solid 0px;">
		<?php
		global $db;
		$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."news_read where newsid='".$blog["id"]."' and dkey='1'  ORDER BY rid Asc");
		while ($row = $db->fetch_array($query)) {
		?>
		<tr>
			<td nowrap class="TableContent" width="90"><?php echo get_realname($row['uid'])?></td>
			  <td class="TableData">
			  <?php 
			  if($row['dkey']==1){
				  echo '<font color=red>[己读]</font>';
			  }else{
				  echo '[未读]';
			  }
			  if($row['viewdate']!=''){
				  echo ' / 阅读时间：'.$row['viewdate'];
			  }
			  if($row['evaluation']!=''){
				  echo ' / 评语：'.$row['evaluation'];
			  }
			  ?>
			  
			  </td>  	  	
		</tr>
		<?php }?>
	</table>
	
		
	
	
	
<?php
$n=0;
global $db;
$query = $db->query("SELECT * FROM ".DB_TABLEPRE.DB_JT."bbs_log where bbsid='".$blog["id"]."' and type='3'  ORDER BY id Asc");
	while ($row = $db->fetch_array($query)) {
$n++;
?>
	
	<table width="90%" border="0" align="center" cellpadding="3" cellspacing="0" class="small" style='margin-top:10px;'>
  <tr>
    <td class="Big"><img src="template/default/content/images/notify_new.gif" align="absmiddle"><span class="big3"><?php echo $row['title']?></span>&nbsp;&nbsp;&nbsp;&nbsp;
	<span style="font-size:12px;">&nbsp;<span style="font-size:34px; font-weight:bold; color:#FF0000;"><?php echo $n?></span>&nbsp;楼&nbsp;&nbsp;
	<?php if($_USER->id==$row['uid']){?>
	<!--<a href="admin.php?ac=<?php echo $ac?>&fileurl=knowledge&do=views&view=del&id=<?php echo $row['id']?>&bbsid=<?php echo $blog['id']?>" style="font-size:12px;">删除</a> -->
	<? }?>
	</span>
    </td>
  </tr>
</table>
	
	<table class="TableBlock" border="0" width="90%" align="center" style="border-bottom:#4686c6 solid 0px;">
		<tr>
			<td nowrap class="TableContent" width="90">评论时间：</td>
			  <td class="TableData"><?php echo $row['enddate']?></td>  	  	
		</tr>
		<tr>
      <td nowrap class="TableContent"> 发布人：</td>
      <td class="TableData"><?php echo $row["author"]?></td>
    </tr>
	</table>	
	<table  width="90%" style="border-left:#4686c6 solid 1px;border-right:#4686c6 solid 1px;border-bottom:#4686c6 solid 1px;" align="center">
	<tr>
      <td colspan="2" bgcolor="#FFFFFF" style="padding:20px 20px 20px 20px;"><?php echo $row['content']?></td>
    </tr>
	</table>	
	
<?php
	}
?>

  
</form>

 
</body>
</html>
