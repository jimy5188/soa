<!DOCTYPE html>
<!--[if IE 6 ]> <html class="ie6 lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 6 ]> <html class="lte_ie6 lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 7 ]> <html class="lte_ie7 lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 8 ]> <html class="lte_ie8 lte_ie9"> <![endif]--> 
<!--[if lte IE 9 ]> <html class="lte_ie9"> <![endif]--> 
<!--[if (gte IE 10)|!(IE)]><!--><html><!--<![endif]-->
 <head>
    <title><?php echo $_CONFIG->config_data('name')?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=10,chrome=1" />
<link rel="stylesheet" type="text/css" href="template/default/content/css/style2014.css">
<script type="text/javascript" src="template/default/js/jquery-1.4.2.min.js"></script>
<script type="text/javascript" src="template/default/content/js/lockTableTitle.js"></script>
<script language="javascript" type="text/javascript" src="template/default/content/js/common.js"></script>
<script language="javascript" type="text/javascript" src="DatePicker/WdatePicker.js"></script>
<script type="text/javascript">
    
    var locktb;
    $(function(){
        locktb=new Kkctf.table.lockTableSingle({
            tMain:$('#lockTable'),            //table的层
            padWidth:15,                        //单元格左右的padding的值总和数值
            borWidth:2,                        //表格左右边框宽度总和值
            subtHeig:150,                    //表格高度减去多少
            dinamicDiv:$('#dynamicDiv'),      //动态层的高度.表格会根据动态层的显示或隐藏进行表格大小的动态调整(可选)
            autoHeight:true                 //表格窗口是否随着窗口的高度改变自动调整高度(可选)
        });
    });

    function formview(){
    
        if($('#dynamicDiv').is(':visible')){
            $('#dynamicDiv').hide();
        }else{
            $('#dynamicDiv').show();
        }
        
        locktb.autoHeightFn();
    }
    function sendForm(){
	   document.save.submit();
	}
	function updateform(type){
		if(type==1){
			document.getElementById("uptype").value='1';
		}
		document.update.submit();
	}
</script>
</head>
<body class="body-wrap">
<div class="tabbable work-nav"> <!-- Only required for left/right tabs -->
				<ul id="myTab" class="nav nav-tabs">
					<li><a href="admin.php?ac=indexsearch&fileurl=book" data-toggle="tab">图书借阅</a></li>
					<li <?php if($_GET[type]=='1'){?>class="active"<?php }?>><a href="admin.php?ac=file_read&fileurl=book&type=1" data-toggle="tab">等待借阅</a></li>
					<li <?php if($_GET[type]=='3'){?>class="active"<?php }?>><a href="admin.php?ac=file_read&fileurl=book&type=3" data-toggle="tab">已借图书</a></li>
					<li <?php if($_GET[type]=='4'){?>class="active"<?php }?>><a href="admin.php?ac=file_read&fileurl=book&type=4" data-toggle="tab">已归还图书</a></li>
					
				</ul>
			</div>


<div class="data-wrap">
	<div class="data-operation">
		<div class="button-operation">			
<button type="button" onClick="updateform(1);" action="cancel_concern" class="btn btn-danger">撤消申请</button>

				
				
		</div>

<div class="pager_operation">
	<?php echo newshowpage($num,$pagesize,$page,$url);?>
	
	
</div>
</div>		
</div>
<form name="update" method="post" action="admin.php?ac=<?php echo $ac?>&fileurl=<?php echo $fileurl?>">
		<input type="hidden" name="do" value="update" />
		<input type="hidden" name="uptype" id="uptype" value="2" />
		<input type="hidden" name="type" value="<?php echo $_GET['type']?>" />

<div class="data-list" >
<div  id="lockTable">
<table  class="table table-bordered table-hover" width="100%">
      <tr class="editThead" align="center">
      <td width="40"><input type="checkbox" value="1" name="chkall" onClick="check_all(this)" /></td>
      <td width="100">图书编号</td>
									<td>图书名称</td>
									<td width="100">申请人</td>
									<td width="120">申请日期</td>
									<td width="80">审批人</td>
									<td width="120">审批日期</td>
									<td width="80">当前状态</td>
   </tr>
<?php
foreach ($result as $row) {
?>
    <tr >
      <td width="40"><?php
get_boxlistkey("id[]",$row['id'],$row['appperson'],$_USER->id)
?></td>
<td><?php echo $row['booknumber']?></td>
<td><?php echo $row['bookname']?>
</td>
<td><?php echo get_realname($row['appperson'])?></td>
<td><?php echo $row['appdate']?></td>
<td><?php echo get_realname($row['examperson'])?></td>
<td><?php echo $row['examdate']?></td>
<td>
<?php
							if($row['type']=='1'){
							echo "待审";
							}elseif($row['type']=='2'){
							echo "未通过";
							}elseif($row['type']=='3'){
							echo "借阅中";
							}elseif($row['type']=='4'){
							echo "己归还";
							}
							
							
							?></td>	
    </tr>
<?php } ?>	       
    </table>
</div>
</div>
</form>
</body>
</html>