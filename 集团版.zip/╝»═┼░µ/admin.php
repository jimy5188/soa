<?php
/*
	[Office 515158] (C) 2009-2012 天生创想 Inc.
	$Id: admin.php 1209087 2012-01-08 08:58:28Z baiwei.jiang $
*/
define('IN_ADMIN',True);
require_once('include/common.php');
get_login($_USER->id);
if(!is_superadmin()){
	if ($_CONFIG->config_data('opendate')<=get_date('H',PHP_TIME) && $_CONFIG->config_data('enddate')<=get_date('H',PHP_TIME)){
		exit('对不起，系统被管理员关闭，开启时间为'.$_CONFIG->config_data('opendate').'点到'.$_CONFIG->config_data('enddate').'点');
	}else{
		if ($_CONFIG->config_data('configflag')=='0'){
			exit('对不起，系统被管理员关闭，请联系管理员！<br>关闭原因：'.$_CONFIG->config_data('closereason'));
		}
	}
}
if($_USER->jituanid!=0){
		global $db;
		$sql = "SELECT type2 FROM ".DB_TABLEPRE."union where id='".$_USER->jituanid."'";
		$rs = $db->fetch_one_array($sql);
		if($rs['type2']=='2'){
			exit('对不起，系统被管理员关闭，请联系管理员！<br>关闭原因：该分支机构暂不允许登录');
		}
}
if ($_GET[fileurl]!=""){
	$fileurl=$_GET[fileurl];
  }else{
	$fileurl="home";
  }
define('ADMIN_ROOT', TOA_ROOT.$fileurl.'/');
initGP(array('ac','do'));
empty($ac) && $ac = 'index';
if ( !eregi('[a-z_]', $ac) ) $ac = 'index';

//新框架转接
if($fileurl=="home"){
	$_hometype=public_value('hometype','user_view','uid='.$_USER->id);
	if($_hometype!=''){
		$_hometype=public_value('hometype','user_view','uid='.$_USER->id);
	}else{
		$_hometype=$_CONFIG->config_data('home');
	}
	if ($_hometype==1){
		echo '<script>location.href="desktop.php?'.get_date('YmdHis',PHP_TIME).'";</script>';
	}elseif ($_hometype==2){
		echo '<script>location.href="newstart.php?'.get_date('YmdHis',PHP_TIME).'";</script>';
	}else{
		echo '<script>location.href="newstart.php?'.get_date('YmdHis',PHP_TIME).'";</script>';
	}
	exit;
}
if ( file_exists('include/function_'.$fileurl.'.php') ) {
	require_once('include/function_'.$fileurl.'.php');
}
if ( file_exists(ADMIN_ROOT."mod_{$ac}.php") ) {
		require_once(ADMIN_ROOT.'./mod_'.$ac.'.php');
	} else {
		exit;
}

?>
